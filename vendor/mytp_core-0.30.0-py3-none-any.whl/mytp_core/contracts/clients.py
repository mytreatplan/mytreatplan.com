"""The client record events (0.11.0, architecture AD-2, AD-15, AD-18, interface I8): a
regional portal tells the admin site about each doctor (client) registered there.

- ``client.updated`` (`ClientUpdated`): the client's full current state, sent after
  every client write (signup, a change in the portal's Django admin) and on a re-sync::

    {"title": "dr", "first_name": "Ana", "middle_name": "", "last_name": "Ruiz",
     "email": "ana@example.com", "phone": "+34600000000", "country": "ES",
     "home_region": "eu", "active": true, "joined_at": "2026-11-05T10:00:00Z",
     "how_found": "linkedin", "city": "Madrid", "time_zone": "Europe/Madrid",
     "profession": "orthodontist", "landline": "+34910000000",
     "alternative_email": "clinic@example.com", "language": "es"}

  ``title`` and ``how_found`` are the portal's choice codes (or empty); ``phone`` is E.164
  or empty; ``country`` ISO 3166-1 alpha-2 (uppercase) or empty; ``home_region`` the
  region that created the account. The free text of "how found: others" is never sent.
  The fiscal entities and shipping addresses (0.28.0, epic-doctor-profile entry 9) are two
  optional lists, ``fiscal_entities`` and ``shipping_addresses`` (`FiscalEntityItem`,
  `ShippingAddressItem`): the doctor's active entries plus at most
  `MAX_ARCHIVED_SENT` of the most recently archived ones (each with its ``archived_at``).
  Absent (an older portal) means "not sent": the admin site leaves what it stores; an
  empty list means "none". Never a maker login, the photo or the VIES retry fields.
  The personal-data fields (0.26.0, epic-doctor-profile entry 2) are optional and empty
  when absent: ``city`` free text; ``time_zone`` an IANA zone name; ``profession`` the
  portal's choice code; ``landline`` E.164; ``alternative_email`` an email;
  ``language`` the preferred language code (``en``, ``es``). An event without them (a
  0.25.0 portal) still reads.
- ``client.erased`` (`ClientErased`): the tombstone, an empty payload. The region erased
  the account (AD-18): the admin site deletes its copy.

Both are aggregate kind ``client``: ``aggregate_id`` is the account's ``uid`` and
``aggregate_version`` the account's sync version, so a ``client.updated`` older than the
erasure is ``stale``. Sent in clear over the signed channel; the admin site encrypts the
personal fields with its own keys.

Writers build with `build_payload` (the closed `ClientUpdated` / `ClientErased`);
readers validate with `ClientUpdatedReader` / `ClientErasedReader` (the same rules,
unknown fields dropped: a later release adds fields, epic-doctor-profile).
"""
from typing import Annotated, Literal

from pydantic import (BaseModel, Field, StrictBool, StrictInt, StringConstraints,
                      model_serializer, model_validator)

from .base import ContractModel, WriterModel
from .events import REGION_PATTERN, UUID_PATTERN, UtcTime

CLIENT_UPDATED = 'client.updated'
CLIENT_ERASED = 'client.erased'

# A choice code of the portal (title, how found), or empty.
Code = Annotated[str, StringConstraints(max_length=30, pattern=r'^[a-z0-9_]*$')]
Name = Annotated[str, StringConstraints(max_length=150)]
# What the portal stores (Django's EmailValidator, quoted local parts included): 3 to 254
# characters with a non-empty domain after the last "@"; no other rule.
Email = Annotated[str, StringConstraints(min_length=3, max_length=254,
                                         pattern=r'^[\s\S]*@[^@]+$')]
# E.164: "+" and up to 15 digits, the first 1-9; or empty.
Phone = Annotated[str, StringConstraints(max_length=16, pattern=r'^(\+[1-9][0-9]{1,14})?$')]
Country = Annotated[str, StringConstraints(max_length=2, pattern=r'^([A-Z]{2})?$')]
RegionCode = Annotated[str, Field(pattern=REGION_PATTERN)]
# 0.26.0: the personal-data fields, each optional and empty when absent.
City = Annotated[str, StringConstraints(max_length=150)]
# An IANA time zone name ("Europe/Madrid", "America/Argentina/Buenos_Aires"), or empty.
TimeZone = Annotated[str, StringConstraints(
    max_length=64, pattern=r'^([A-Za-z0-9_+\-]+(/[A-Za-z0-9_+\-]+)*)?$')]
# An email (a domain after the last "@"), or empty.
OptionalEmail = Annotated[str, StringConstraints(max_length=254,
                                                 pattern=r'^([\s\S]+@[^@]+)?$')]
# A language code ("en", "es", "pt-br"), or empty.
Language = Annotated[str, StringConstraints(max_length=10,
                                            pattern=r'^([a-z]{2}(-[a-z0-9]{2,4})?)?$')]

# 0.28.0: the fiscal entities and shipping addresses of epic-doctor-profile entry 9.
MAX_ACTIVE_SENT = 10
MAX_ARCHIVED_SENT = 25
Uuid = Annotated[str, StringConstraints(pattern=UUID_PATTERN)]
Line = Annotated[str, StringConstraints(max_length=200)]
Short = Annotated[str, StringConstraints(max_length=150)]
PostalCode = Annotated[str, StringConstraints(max_length=30)]
TaxId = Annotated[str, StringConstraints(max_length=40)]
Version = Annotated[StrictInt, Field(ge=1)]


class _FiscalEntityFields(BaseModel):
    id: Uuid
    kind: Literal['person', 'company']
    first_name: Short
    last_name: Short
    legal_name: Line
    tax_id: TaxId
    vat_id: TaxId
    address_line1: Line
    address_line2: Line
    city: City
    postal_code: PostalCode
    province: Short
    country: Country
    billing_email: OptionalEmail
    is_default: StrictBool
    used_at: UtcTime | None
    archived_at: UtcTime | None
    version: Version
    vies_status: Literal['valid', 'invalid', 'pending', 'not_applicable']
    vies_checked_at: UtcTime | None


class _ShippingAddressFields(BaseModel):
    id: Uuid
    label: Annotated[str, StringConstraints(max_length=100)]
    recipient_name: Short
    clinic_name: Short
    contact_phone: Phone
    delivery_notes: Annotated[str, StringConstraints(max_length=300)]
    address_line1: Line
    address_line2: Line
    city: City
    postal_code: PostalCode
    province: Short
    country: Country
    is_default: StrictBool
    used_at: UtcTime | None
    archived_at: UtcTime | None
    version: Version


class FiscalEntityItem(_FiscalEntityFields, WriterModel):
    """One fiscal entity in ``client.updated`` (0.28.0), as a portal writes it (closed)."""


class FiscalEntityItemReader(_FiscalEntityFields, ContractModel):
    """One fiscal entity, as the admin site reads it (unknown fields dropped)."""


class ShippingAddressItem(_ShippingAddressFields, WriterModel):
    """One shipping address in ``client.updated`` (0.28.0), as a portal writes it."""


class ShippingAddressItemReader(_ShippingAddressFields, ContractModel):
    """One shipping address, as the admin site reads it (unknown fields dropped)."""


_MAX_SENT = MAX_ACTIVE_SENT + MAX_ARCHIVED_SENT
_LISTS = ('fiscal_entities', 'shipping_addresses')


def _without_absent(data, names):
    """A dumped payload without its optional lists that are None: absent stays absent
    (never ``null``), so an event without them dumps as before 0.28.0."""
    if isinstance(data, dict):
        for name in names:
            if name in data and data[name] is None:
                del data[name]
    return data


def _unique_ids(model):
    for name in _LISTS:
        items = getattr(model, name)
        if items is not None and len({item.id for item in items}) != len(items):
            raise ValueError(f'{name} lists an id twice')
    return model


class ClientUpdatedReader(ContractModel):
    """A client's full state, as the admin site reads it (unknown fields dropped)."""

    title: Code
    first_name: Name
    middle_name: Name
    last_name: Name
    email: Email
    phone: Phone
    country: Country
    home_region: RegionCode
    active: StrictBool
    joined_at: UtcTime
    how_found: Code
    city: City = ''
    time_zone: TimeZone = ''
    profession: Code = ''
    landline: Phone = ''
    alternative_email: OptionalEmail = ''
    language: Language = ''
    # 0.28.0: None = not sent (an older portal); [] = none.
    fiscal_entities: Annotated[list[FiscalEntityItemReader],
                               Field(max_length=_MAX_SENT)] | None = None
    shipping_addresses: Annotated[list[ShippingAddressItemReader],
                                  Field(max_length=_MAX_SENT)] | None = None

    @model_serializer(mode='wrap')
    def _without_absent_fields(self, handler):
        return _without_absent(handler(self), _LISTS)

    @model_validator(mode='after')
    def _unique_ids(self):
        return _unique_ids(self)


class ClientErasedReader(ContractModel):
    """The tombstone, as the admin site reads it (no field)."""


class ClientUpdated(WriterModel):
    """The payload of ``client.updated`` a portal writes (closed: the same fields and
    rules as `ClientUpdatedReader`, an unknown field refused)."""

    title: Code
    first_name: Name
    middle_name: Name
    last_name: Name
    email: Email
    phone: Phone
    country: Country
    home_region: RegionCode
    active: StrictBool
    joined_at: UtcTime
    how_found: Code
    city: City = ''
    time_zone: TimeZone = ''
    profession: Code = ''
    landline: Phone = ''
    alternative_email: OptionalEmail = ''
    language: Language = ''
    # 0.28.0: None = not sent; [] = none. Left out of the dump when None.
    fiscal_entities: Annotated[list[FiscalEntityItem],
                               Field(max_length=_MAX_SENT)] | None = None
    shipping_addresses: Annotated[list[ShippingAddressItem],
                                  Field(max_length=_MAX_SENT)] | None = None

    @model_serializer(mode='wrap')
    def _without_absent_fields(self, handler):
        return _without_absent(handler(self), _LISTS)

    @model_validator(mode='after')
    def _unique_ids(self):
        return _unique_ids(self)


class ClientErased(WriterModel):
    """The payload of ``client.erased`` a portal writes: empty."""


# The reader model of each client event type.
CLIENT_READERS = {CLIENT_UPDATED: ClientUpdatedReader, CLIENT_ERASED: ClientErasedReader}

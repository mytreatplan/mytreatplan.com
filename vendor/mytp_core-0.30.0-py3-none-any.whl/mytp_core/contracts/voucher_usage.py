"""The voucher usage events (0.30.0, architecture AD-20, S5; epic-subscriptions entry 4):
a regional portal tells the admin site how an order used a voucher.

- ``voucher.redeemed`` (`VoucherRedeemed`): a redemption is held by an order (state
  ``reserved``, ``aggregate_version`` 1) or its order is paid (state ``consumed``,
  ``aggregate_version`` 2).
- ``voucher.released`` (`VoucherReleased`): the order was cancelled or expired before it
  was paid, so the voucher can be used again (state ``released``, version 2).

The payload (the same fields for both)::

    {"redemption_id": "<uuid>", "voucher_id": "<uuid>", "voucher_type": "try_me",
     "client_uid": "<uuid>", "order_id": "<uuid>", "order_reference": "MT-2026-000123",
     "state": "reserved", "amount": {"amount": "50.00", "currency": "EUR"},
     "at": "2026-11-21T10:00:00Z"}

``amount`` is what the voucher took off the order. ``at`` is when the state was reached.
No patient data is in it. Aggregate kind ``voucher``: ``aggregate_id`` is the
``redemption_id``, so each redemption's versions rise on their own and a replay of an
older version is ``stale``; the admin site keeps the latest state.

Writers build with `build_payload` (the closed `VoucherRedeemed` / `VoucherReleased`);
readers validate with `VoucherRedeemedReader` / `VoucherReleasedReader` (the same rules,
unknown fields dropped).
"""
from typing import Annotated, Literal

from pydantic import Field, StringConstraints

from .amounts import CURRENCY_PATTERN, Amount, DecimalAmount
from .base import ContractModel, WriterModel
from .events import CanonicalUuid, UtcTime
from .vouchers import VoucherType

VOUCHER_REDEEMED = 'voucher.redeemed'
VOUCHER_RELEASED = 'voucher.released'

RESERVED, CONSUMED, RELEASED = 'reserved', 'consumed', 'released'
# The states each event type carries.
REDEEMED_STATES = (RESERVED, CONSUMED)
RELEASED_STATES = (RELEASED,)

# The order's human reference (the portal's ``Order.reference``).
OrderReference = Annotated[str, StringConstraints(min_length=1, max_length=64)]


class UsageAmount(WriterModel):
    """The closed form of `Amount` for a writer's payload (the same fields and rules; a
    nested payload model must refuse unknown fields)."""

    amount: DecimalAmount
    currency: str = Field(pattern=CURRENCY_PATTERN,
                          description='ISO 4217 code, e.g. EUR.')


class VoucherRedeemedReader(ContractModel):
    """A reserved or consumed redemption, as the admin site reads it (unknown fields
    dropped)."""

    redemption_id: CanonicalUuid
    voucher_id: CanonicalUuid
    voucher_type: VoucherType
    client_uid: CanonicalUuid
    order_id: CanonicalUuid
    order_reference: OrderReference
    state: Literal['reserved', 'consumed']
    amount: Amount
    at: UtcTime


class VoucherReleasedReader(ContractModel):
    """A released redemption, as the admin site reads it (unknown fields dropped)."""

    redemption_id: CanonicalUuid
    voucher_id: CanonicalUuid
    voucher_type: VoucherType
    client_uid: CanonicalUuid
    order_id: CanonicalUuid
    order_reference: OrderReference
    state: Literal['released']
    amount: Amount
    at: UtcTime


class VoucherRedeemed(WriterModel):
    """The payload of ``voucher.redeemed`` a portal writes (closed: the same fields and
    rules as `VoucherRedeemedReader`, an unknown field refused)."""

    redemption_id: CanonicalUuid
    voucher_id: CanonicalUuid
    voucher_type: VoucherType
    client_uid: CanonicalUuid
    order_id: CanonicalUuid
    order_reference: OrderReference
    state: Literal['reserved', 'consumed']
    amount: UsageAmount
    at: UtcTime


class VoucherReleased(WriterModel):
    """The payload of ``voucher.released`` a portal writes (closed)."""

    redemption_id: CanonicalUuid
    voucher_id: CanonicalUuid
    voucher_type: VoucherType
    client_uid: CanonicalUuid
    order_id: CanonicalUuid
    order_reference: OrderReference
    state: Literal['released']
    amount: UsageAmount
    at: UtcTime


# The reader model of each voucher usage event type.
VOUCHER_USAGE_READERS = {VOUCHER_REDEEMED: VoucherRedeemedReader,
                         VOUCHER_RELEASED: VoucherReleasedReader}

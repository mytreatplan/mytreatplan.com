"""The catalogue section of the configuration snapshot (0.12.0, architecture AD-3, AD-6,
AD-16, AD-22; epic-catalogue entry 2): the products, country groups and subscriptions the
admin site's Commercial Manager defines, which every regional portal prices from.

    {"country_groups": [{"id": "<uuid>", "name": "Iberia", "countries": ["ES", "PT"],
                         "catch_all": false, "active": true}],
     "products": [{"id": "<uuid>", "name": "TPS", "category": "tps",
                   "net_price": {"amount": "100.00", "currency": "EUR"}, "active": true}],
     "subscriptions": [{"id": "<uuid>", "tier": "basic", "country_group": "<uuid>",
                        "tps_discount_percent": "10.00", "active": true}]}

- Every row is listed, inactive ones too (``active: false``); ids are UUID strings, each
  once per list.
- A country group lists ISO 3166-1 alpha-2 codes (uppercase), each once; ``catch_all``
  marks the group of every country in no other active group ("Rest of world"). Among the
  active groups a country is in at most one, and at most one is the catch-all.
- A product's ``category`` and a subscription's ``tier`` are lowercase codes (``tps`` /
  ``other`` until 0.20.0, whose codes are listed below; ``basic`` / ``advanced`` /
  ``premium``), not a closed list: a later release adds codes, and a reader skips what it
  does not know.
- ``net_price`` is a net amount (the `Amount` contract; VAT is added at checkout), never
  negative. The admin site writes only the currencies of `mytp_core.money.CURRENCIES`
  (EUR, AED, USD); the contract takes any ISO 4217 form, and a reader skips a product in a
  currency it does not know (a later release may add one). ``tps_discount_percent`` is a
  decimal string with exactly 2 places from ``"0.00"`` to ``"100.00"``.
- A subscription's ``country_group`` is the id of a listed group; at most one active
  subscription per (tier, country group).

Since 0.20.0 (epic-catalogue entry 5) a product may also carry, each optional:

    {"texts": {"en": {"name": "TPS", "description": "A plan.\\nIn two lines."},
               "es": {"name": "TPS", "description": ""}},
     "code": "TPS-BR-01", "valid_from": "2026-01-01", "valid_to": "2026-12-31"}

- ``texts``: the public texts per language (a lowercase language tag: two or three
  letters, then optional ``-`` subtags of letters or digits, as ``es``, ``pt-br``; a
  reader falls back to English for a language it does not show): a ``name`` (at
  most 150 characters) and a short ``description`` (at most 1000; plain text, line breaks
  as ``\\n``; may be empty). English (``en``) is always there with a name that is not
  blank and equals the product's ``name``; any other
  language, or an empty text of one, falls back to English (`CatalogueProduct.name_in`,
  `description_in`). ``name`` stays the English public name, for readers before 0.20.0.
- ``code``: the internal code, unique among the products that have one (a section where
  two products share a code is refused): 1 to 64 uppercase letters,
  digits and ``. _ / -``. Readers identify a product by its id, never by its code.
- ``valid_from`` / ``valid_to``: ISO dates (``YYYY-MM-DD``), each optional, both
  inclusive, in Madrid time; ``valid_to`` never before ``valid_from``. Outside them the
  product is not offered for new orders (`CatalogueProduct.offered_on`) but stays listed.
- The internal notes of a product never leave the admin site: they are not in the contract.
- The category codes of 0.20.0's admin site are ``tps_branded``, ``tps_in_house``,
  ``initial_case_evaluation``, ``virtuaortho_one``, ``virtuaortho_digitaltwin``, ``odb``,
  ``retainers``, ``spark_on_demand``, ``subscription``, ``education`` and
  ``uncategorised`` (a product not yet given one of them); ``tps`` and ``other`` are the
  codes of an admin site before it, which a reader takes as ``tps_branded`` and
  ``uncategorised``. The list stays open, as above.

and a subscription ``tps_in_house_discount_percent`` (optional; a percentage as
``tps_discount_percent``): the discount on ``tps_in_house`` products, while
``tps_discount_percent`` is the discount on ``tps_branded`` ones. Absent (an admin site
before 0.20.0) it reads as 0 (`CatalogueSubscription.in_house_discount_percent`). No
other category is discounted.

Since 0.21.0 (epic-catalogue entry 6) a product may also carry, each optional:

    {"size": "medium", "per_unit": {"min_quantity": 4, "max_quantity": 9},
     "calls": {"count": 3, "minutes": 25},
     "cost_links": [{"provider_product": "<uuid>", "quantity": 2, "monthly": false}]}

- ``size``: a lowercase code (``short``, ``medium``, ``long`` on the admin site of
  0.21.0; an open list, as the categories), given to TPS products only.
- ``per_unit``: the product is priced per unit (``net_price`` is the price of one), for
  a whole quantity from ``min_quantity`` (at least 1) to ``max_quantity`` (never below
  it), both inclusive. Absent: the product is sold once per line (quantity 1).
- ``calls``: the calls the product grants: ``count`` calls of ``minutes`` minutes each,
  whole numbers above 0.
- ``cost_links``: the provider products (ids of the snapshot's ``provider_costs``
  section) the product is made of, each at most once, with a whole ``quantity`` (at
  least 1) and whether the cost is ``monthly``. The product's cost on a date is the sum
  of its links that are not monthly (a product without any has no cost to show:
  `ProductCost.empty`), each the provider product's cost on that date ×
  the quantity (`CatalogueProduct.cost_at`, `sum_costs`); a monthly link is never in the
  sum: it is listed apart with its monthly cost. A link whose provider product has no
  cost on the date (a gap; not listed; another currency than the product's, or one this
  release does not know) leaves the sum partial: it is then marked incomplete and names
  what is missing, and is never to be shown as a complete cost. Only the links in force
  are sent (an ended one is left out).

and the section an optional ``add_ons`` list (0.21.0), what a buyer may choose next to a
product:

    {"add_ons": [{"id": "<uuid>", "code": "BYTE-SYNC",
                  "texts": {"en": {"name": "Byte Sync", "description": ""}},
                  "amount": {"amount": "120.00", "currency": "EUR"},
                  "categories": ["tps_branded", "tps_in_house",
                                 "initial_case_evaluation", "virtuaortho_one",
                                 "virtuaortho_digitaltwin", "odb"], "active": true},
                 {"id": "<uuid>", "code": "ONE-ARCH",
                  "texts": {"en": {"name": "One arch", "description": ""}},
                  "percent": "-25.00", "categories": ["tps_in_house"],
                  "active": true},
                 {"id": "<uuid>", "code": "JUNIOR-1",
                  "texts": {"en": {"name": "Junior I", "description": ""}},
                  "amount": {"amount": "0.00", "currency": "EUR"},
                  "categories": ["tps_branded", "tps_in_house"],
                  "sizes": ["medium"], "active": true}]}

- Every add-on is listed, inactive ones too; ids once, codes once (a code as a product's:
  uppercase letters, digits and ``. _ / -``). ``texts`` as a product's: English always,
  with a name that is not blank.
- Exactly one of ``amount`` (a fixed net amount in one currency, never negative; ``0.00``
  for an add-on that only marks the order) and ``percent`` (a signed percentage with
  exactly 2 places from ``"-100.00"`` to ``"100.00"``, never ``"-0.00"``, applied to the
  product's net price: ``"-25.00"`` takes a quarter off).
- ``categories``: the product categories it is offered on, each once. ``sizes``
  (optional): the product sizes it is offered on, each once; absent, the size does not
  matter. An add-on with an ``amount`` is offered only on products of that currency
  (`CatalogueAddOn.applies_to`, `CatalogueSection.add_ons_for`).
- A line's price (`CatalogueProduct.line_price`, `line_price`): ``net price × quantity ×
  (1 + percent / 100) for each percentage add-on × (1 − subscription discount / 100)``,
  plus the fixed amounts, once per line whatever the quantity; computed exactly and
  rounded half up to cents once, at the end. The subscription discount therefore never
  applies to a fixed add-on.

Since 0.22.0 (epic-catalogue entry 8) a subscription may also carry, each optional:

    {"code": "ADV-IB",
     "texts": {"en": {"name": "Advanced", "description": ""}},
     "products": ["<product uuid>"],
     "discounts": {"tps_branded": "6.00"},
     "price": {"currency": "EUR", "monthly": "60.00", "upfront": "600.00"},
     "call_extras": {"virtuaortho_one": {"extra_calls": 1, "minutes": 35}}}

- ``code`` and ``texts``: as a product's (the code is unique among the subscriptions of
  both lists that have one; English always, with a name that is not blank:
  `CatalogueSubscription.name_in`, `description_in`). The internal notes of a
  subscription never leave the admin site.
- ``products``: the ids of the products the subscription gives access to, each once: a
  doctor is offered only these (`CatalogueSubscription.offers`). An empty list offers
  nothing. Absent (an admin site before 0.22.0): every product is offered, as before.
  An id that is not among the section's products is ignored.
- ``discounts``: the discount (a percentage as ``tps_discount_percent``) per product
  category; a category that is not in the map is not discounted
  (`CatalogueSubscription.discount_for`). ``tps_discount_percent`` and
  ``tps_in_house_discount_percent`` stay, for readers before 0.22.0, and equal the
  map's ``tps_branded`` and ``tps_in_house`` values (0 for one that is not in the map): a
  subscription where they differ is refused. Absent: the two former fields are the
  discounts, and no other category is discounted.
- ``price``: what the subscription itself costs, in one ``currency``: a ``monthly``
  amount and an ``upfront`` amount for a year, at least one of them, never negative
  (amounts as the `Amount` contract's: strings with exactly 2 places). Absent: the
  subscription is free; a ``price`` with neither amount is refused (a writer leaves
  ``price`` out for a free subscription). A reader skips a subscription whose price is in a currency it does not know
  (never reading it as free).
- ``call_extras``: per product category, what the subscription adds to the calls of a
  product of that category: ``extra_calls`` more calls (0 or more) and, when given,
  ``minutes``: the length of each call (at least 1), which replaces the product's. A
  product that grants no calls gets none (`CatalogueSubscription.calls_for`,
  `calls_under`).

and the section an optional ``manual_subscriptions`` list (0.22.0): the subscriptions an
administrator assigns to a doctor by hand, in the same shape. ``subscriptions`` lists
the standard ones: the standard subscription of a tier and country group is their
default, and what a doctor of that group and tier gets (at most one active per tier and
group, as before). A manual one has a tier and a country group too, but any number may
be active for them, and none is ever the answer for a country and a tier: it is read by
its id. An id is in at most one of the two lists.

Since 0.23.0 (epic-catalogue entry 9, AD-6, AD-7, AD-16) the section may also carry two
optional lists, the billing companies and the billing rules:

    {"billing_companies": [{"id": "<uuid>", "code": "ES",
                            "legal_name": "MyTPDSO Spain S.L.",
                            "address": "Avda. Labradores, 1\\n28760 Tres Cantos",
                            "country": "ES", "time_zone": "Europe/Madrid",
                            "vat_number": "B93858371", "active": true}],
     "billing_rules": [{"id": "<uuid>", "country_group": "<uuid>",
                        "category": "tps_branded", "company": "<uuid>",
                        "vat_percent": "0.00", "exemption_text": "Exempt (art. 20).",
                        "gateways": ["redsys", "bank_transfer"], "currency": "EUR",
                        "available": true, "active": true}]}

- ``billing_companies``: the companies that bill (every one listed, inactive ones too;
  ids once). ``code``: the short code (``ES``, ``IE``, ``AE``: 1 to 16 uppercase
  letters and digits), unique in the list. ``legal_name`` (at most 200 characters) and
  ``address`` (at most 500; plain text, line breaks as ``\\n``), never blank;
  ``country`` (ISO 3166-1 alpha-2); ``time_zone``: the company's legal time zone (an
  IANA name). Three identifiers, each optional and left out when the company has none:
  ``company_number`` (the company number or license), ``vat_number`` (the VAT
  registration) and ``tax_number`` (the TAX registration). No bank details and no
  invoice series: they come with epic-payments.
- ``billing_rules``: one rule per country group and product category (every one listed,
  inactive ones too; ids once): the ``company`` that bills (the id of a listed billing
  company), the VAT rate (``vat_percent``, a percentage as ``tps_discount_percent``),
  the ``exemption_text`` shown when the rate is 0 (at most 1000 characters; a rule
  whose rate is 0 always has one, never blank: a rule without it is refused), an
  optional ``reverse_charge_text`` (the text for a buyer with a valid VIES number in
  another country than the company's, who is then charged a rate of 0; deciding that is
  the reader's, not the contract's), the payment ``gateways`` in order of preference
  (lowercase codes, each once; ``redsys``, ``revolut`` and ``bank_transfer`` on the
  admin site of 0.23.0, `BILLING_GATEWAYS`; an open list: a reader skips a gateway it
  does not know; may be empty), the ``currency`` the pair is sold in (ISO 4217 form; a
  reader offers only the products in that currency, and nothing for a rule in a
  currency it does not know) and whether the category is ``available`` in that group.
- A rule's ``country_group`` is the id of a listed group and its ``company`` the id of
  a listed billing company; at most one active rule per (country group, category),
  ``tps`` counting as ``tps_branded``; an active rule names an active company. An
  identifier or a reverse-charge text is left out, never blank.
- Which rule applies (`CatalogueSection.billing_rule`): the active rule of the country
  group and the product's category. Whether a pair is offered
  (`CatalogueSection.billing_offered`, `billing_offers`): without rules (no
  ``billing_rules``: an admin site before 0.23.0, or one where no rule was typed yet;
  before 0.25.0 an empty list too, see below) every pair is offered, as before; once the
  section has rules, in
  any state (deactivated ones count: rules are never deleted, so this does not go
  back), a pair is offered only when it has an active rule that is ``available``, and then only
  the products in the rule's currency.

Since 0.25.0 (epic-catalogue entry 16, AD-3, AD-14) a country group, a product and a
billing company may carry a ``region`` (a region code, ``eu``, ``ae``; optional): the
region whose portal receives it. A subscription and a billing rule have their group's
region. Absent (an admin site before 0.25.0), the record is every region's.

- The admin site stores one body with every region's records; `contracts.regions.for_region`
  gives each portal its own: its groups, the subscriptions (both lists) and rules of
  those groups, its companies, its products, every add-on (add-ons are shared) and
  records without a region. A rule whose company is not kept is left out too, and a
  subscription's ``products`` keeps only the ids of products kept.
- The rules across groups hold per region: among the active groups of a region a
  country is in at most one, and at most one is the catch-all (each region has its own
  "Rest of world"). A group without a region counts in every region's check, so the
  body filtered for a region (`for_region`) keeps the rules of before 0.25.0.
- Why this relaxing needs no `min_reader` bump: a reader is one region's, and it must
  itself skip every record whose ``region`` is another one (with the subscriptions and
  rules of a skipped group, and a rule naming a skipped company: the portal's applier
  does). What it keeps is then one region's records and those without a region, which
  this release checks together: the rules of before hold for it. A reader that ends up
  holding regional rows of more than one region is applying an unfiltered body, which is
  a writer's error, not a form this contract serves. A reader before 0.25.0 cannot skip
  (it drops ``region``): it must be sent a filtered body.
- ``billing_rules`` present but empty: rules exist on the admin site, none of them this
  region's (`for_region` keeps the empty list). Nothing is offered then
  (`billing_offered`), while an absent list still means that no rule was typed (every
  pair offered). An admin site before 0.25.0 never sends an empty list. A reader before
  0.25.0 reads an empty list as no rules and would offer every pair, so the release
  order is mytp-core, then the readers (the portals), then the writer (the admin site).
  A 0.25.0 reader reads a 0.24.0 writer's body as before (no ``region``: every record is
  its own, one global check of the groups; never an empty rules list).

A field of these that is absent (or null) stays absent when the row is dumped, so a row
without them dumps, and a snapshot of an older admin site signs, exactly as in 0.19.0
(and, without the fields and the list of 0.21.0, as in 0.20.0; without those of 0.22.0,
as in 0.21.0; without the lists of 0.23.0, as in 0.22.0).

The rules across rows (a subscription's group is listed; at most one active subscription
per tier and group in ``subscriptions``; a country in at most one active group and at
most one active catch-all, both per region since 0.25.0, the catalogue being served per
region: see above and `contracts.regions`) are part of the reader contract: a snapshot
that breaks one is
refused whole (`invalid_body`), and the reader keeps its last good snapshot, which is the
safe failure. Relaxing any of them is a breaking change: it needs a `min_reader` bump, so
readers that still enforce it keep their snapshot instead of refusing every new one. That
is why the manual subscriptions of 0.22.0 are a list of their own: the rule on
``subscriptions`` is untouched, and a reader before 0.22.0 ignores the new list. The
rules of 0.23.0 (a rule's group and company are listed; at most one active rule per
group and category; a rate of 0 has its exemption text; a company code is unique) are
on the two new lists only, which a reader before 0.23.0 ignores.

The section is optional in the snapshot (`ConfigSnapshot.catalogue`): an admin site older
than 0.12.0 sends none, and a portal then holds an empty catalogue.
"""
import dataclasses
from decimal import (MAX_EMAX, MIN_EMIN, ROUND_HALF_UP, Context, Decimal, Inexact,
                     InvalidOperation)
from typing import Annotated

from pydantic import (BeforeValidator, Field, PlainSerializer, StrictBool, StrictInt,
                      StringConstraints, WithJsonSchema, model_serializer, model_validator)

from .amounts import CURRENCY_PATTERN, Amount, DecimalAmount, _decimal_amount
from .base import ContractModel
from .events import REGION_PATTERN, CanonicalUuid
from .provider_costs import IsoDate

Name = Annotated[str, StringConstraints(min_length=1, max_length=150)]
# A choice code: lowercase letters, digits and "_", starting with a letter.
Code = Annotated[str, StringConstraints(min_length=1, max_length=32,
                                        pattern=r'^[a-z][a-z0-9_]*$')]
CountryCode = Annotated[str, StringConstraints(pattern=r'^[A-Z]{2}$')]

PERCENT_PATTERN = r'^(100\.00|[1-9]?[0-9]\.[0-9]{2})$'
HUNDRED = Decimal('100')


def _decimal_percent(value):
    try:
        value = _decimal_amount(value)
    except ValueError:
        raise ValueError('a percentage is a decimal string with exactly 2 places, '
                         'e.g. "10.00"') from None
    if not Decimal(0) <= value <= HUNDRED:
        raise ValueError('a percentage is from "0.00" to "100.00"')
    return value


Percent = Annotated[
    Decimal,
    BeforeValidator(_decimal_percent),
    PlainSerializer(lambda value: format(value, 'f'), return_type=str, when_used='json'),
    WithJsonSchema({'type': 'string', 'pattern': PERCENT_PATTERN,
                    'description': 'A percentage with exactly 2 places, "0.00" to "100.00".'}),
]


# 0.21.0: an add-on's percentage, signed ("-25.00" takes a quarter off).
SIGNED_PERCENT_PATTERN = r'^(?!-0\.00$)-?(100\.00|[1-9]?[0-9]\.[0-9]{2})$'


def _decimal_signed_percent(value):
    try:
        value = _decimal_amount(value)
    except ValueError:
        raise ValueError('a signed percentage is a decimal string with exactly 2 places, '
                         'e.g. "-25.00"') from None
    if not -HUNDRED <= value <= HUNDRED:
        raise ValueError('a signed percentage is from "-100.00" to "100.00"')
    return value


SignedPercent = Annotated[
    Decimal,
    BeforeValidator(_decimal_signed_percent),
    PlainSerializer(lambda value: format(value, 'f'), return_type=str, when_used='json'),
    WithJsonSchema({'type': 'string', 'pattern': SIGNED_PERCENT_PATTERN,
                    'description': 'A signed percentage with exactly 2 places, "-100.00" '
                                   'to "100.00".'}),
]

# 0.21.0: a whole quantity (units of a product, calls, minutes, provider products of a
# link). The upper bound keeps it within every site's integer column.
MAX_QUANTITY = 1_000_000
Quantity = Annotated[StrictInt, Field(ge=1, le=MAX_QUANTITY)]


# 0.25.0: the region code (``eu``, ``ae``) a country group, a product or a billing company
# belongs to; absent (an admin site before 0.25.0): the record is every region's.
RegionCode = Annotated[str, StringConstraints(pattern=REGION_PATTERN)]


class CatalogueCountryGroup(ContractModel):
    """A group of countries a subscription applies to; since 0.25.0 with its optional
    region."""

    id: CanonicalUuid
    name: Name
    countries: list[CountryCode]
    catch_all: StrictBool = Field(
        description='The group of every country in no other active group of its region.')
    active: StrictBool
    # 0.25.0: optional, so the snapshot of an older admin site stays valid.
    region: RegionCode | None = None

    @model_serializer(mode='wrap')
    def _without_absent_fields(self, handler):
        return _without_absent(handler(self), ('region',))

    @model_validator(mode='after')
    def _unique_countries(self):
        if len(self.countries) != len(set(self.countries)):
            raise ValueError('a country group lists a country twice')
        return self


def _without_absent(data, names):
    """A dumped row without its optional fields that are None: an absent field stays
    absent (never ``"code": null``), so a row without them dumps as before they existed."""
    if isinstance(data, dict):
        for name in names:
            if name in data and data[name] is None:
                del data[name]
    return data


# 0.20.0: a product's public texts, per language.
ENGLISH = 'en'
# A lowercase language tag: two or three letters, then optional "-" subtags of letters or
# digits ("es", "pt-br", "zh-hans"). Wide on purpose: a reader falls back to English for
# a language it does not show, and a reader rule cannot be relaxed later.
LanguageCode = Annotated[str, StringConstraints(
    max_length=35, pattern=r'^[a-z]{2,3}(-[a-z0-9]{1,8})*$')]
PRODUCT_CODE_PATTERN = r'^[A-Z0-9._/-]{1,64}$'
ProductCode = Annotated[str, StringConstraints(pattern=PRODUCT_CODE_PATTERN)]


class ProductText(ContractModel):
    """A product's public texts in one language (0.20.0): plain text, the description
    with line breaks. An empty one falls back to English."""

    name: str = Field(default='', max_length=150)
    description: str = Field(default='', max_length=1000)


def _check_texts(texts, what):
    if not (ENGLISH in texts and texts[ENGLISH].name.strip()):
        raise ValueError(f"{what}'s texts have an English name")


def _text_in(texts, language, field):
    """The text `field` in `language`, else in English, else ''."""
    texts = texts or {}
    for code in (language, ENGLISH):
        value = getattr(texts.get(code), field, '')
        if value:
            return value
    return ''


def _each_once(values, message):
    if len(values) != len(set(values)):
        raise ValueError(message)


# --- Pricing and costs (0.21.0) -----------------------------------------------------------

class QuantityRefused(ValueError):
    """A quantity a product is not sold in: outside its per-unit range, or other than 1
    for a product that is not priced per unit."""


class AddOnRefused(ValueError):
    """An add-on that cannot be chosen with a product: inactive, not offered on it (its
    category, size or currency), or chosen twice."""


# Exact arithmetic for a line: a result that would need rounding before the end is an
# error, never a silent rounding (and the thread's context never changes a price).
_EXACT = Context(prec=120, rounding=ROUND_HALF_UP, Emax=MAX_EMAX, Emin=MIN_EMIN,
                 traps=[InvalidOperation, Inexact])
_ONE = Decimal(1)


def _is_quantity(value):
    return isinstance(value, int) and not isinstance(value, bool)


def check_quantity(quantity, min_quantity=None, max_quantity=None):
    """`QuantityRefused` unless `quantity` is one the product is sold in: a whole number
    from `min_quantity` to `max_quantity` (both inclusive) for a product priced per unit;
    exactly 1 for any other product (both None)."""
    if not _is_quantity(quantity):
        raise QuantityRefused('a quantity is a whole number')
    if min_quantity is None and max_quantity is None:
        if quantity != 1:
            raise QuantityRefused('this product is not priced per unit: its quantity is 1')
        return
    if min_quantity is None or max_quantity is None:
        raise ValueError('a per-unit range has a minimum and a maximum quantity')
    if not min_quantity <= quantity <= max_quantity:
        raise QuantityRefused(f'the quantity is from {min_quantity} to {max_quantity}')


def add_on_applies(*, categories, sizes, currency, product_category, product_size,
                   product_currency):
    """Whether an add-on is offered on a product: the product's category is among the
    add-on's `categories`; its size among the add-on's `sizes` (None: the size does not
    matter; a product without a size is then never among them); and an add-on with a
    fixed amount (`currency`; None for a percentage) is in the product's currency."""
    if product_category not in categories:
        return False
    if sizes is not None and product_size not in sizes:
        return False
    return currency is None or currency == product_currency


def _percentage(value, low, what):
    if (isinstance(value, bool) or not isinstance(value, (int, Decimal))
            or not Decimal(value).is_finite() or not low <= Decimal(value) <= HUNDRED):
        raise ValueError(f'{what} is a Decimal from {low} to 100')
    return Decimal(value)


def line_price(net_price, *, quantity=1, discount_percent=Decimal(0), percents=(),
               amounts=()):
    """The price of one line, as `mytp_core.money.Money`:

        net_price × quantity × (1 + p / 100) for each p of `percents`
                  × (1 − discount_percent / 100)  +  the `amounts`

    `net_price` and each of `amounts` (the fixed add-ons, once per line) are `Money` of
    one currency (`CurrencyMismatch` otherwise); `percents` are the percentage add-ons
    (Decimals from −100 to 100); `discount_percent` is the subscription's discount on the
    product (0 to 100), which never applies to a fixed amount. A negative net price or
    fixed amount is a ValueError: the rule of the contract models holds here too, for
    the sites that price from their own rows. Computed exactly, then rounded half up to
    cents once. It checks neither the quantity's range nor whether an
    add-on is offered on the product: `check_quantity`, `add_on_applies`."""
    # Imported here: mytp_core.money imports this package (contracts.amounts).
    from ..money import CurrencyMismatch, Money
    if not isinstance(net_price, Money):
        raise TypeError('a net price is Money')
    if net_price.amount < 0:
        raise ValueError('a net price is never negative')
    if not _is_quantity(quantity) or quantity < 1:
        raise QuantityRefused('a quantity is a whole number above 0')
    discount = _percentage(discount_percent, Decimal(0), 'a discount')
    try:
        factor = Decimal(quantity)
        for percent in percents:
            percent = _percentage(percent, -HUNDRED, 'an add-on percentage')
            factor = _EXACT.multiply(factor, _EXACT.add(_ONE, _EXACT.scaleb(percent, -2)))
        factor = _EXACT.multiply(factor,
                                 _EXACT.subtract(_ONE, _EXACT.scaleb(discount, -2)))
        total = _EXACT.multiply(net_price.amount, factor)
        for amount in amounts:
            if not isinstance(amount, Money):
                raise TypeError('a fixed add-on amount is Money')
            if amount.currency != net_price.currency:
                raise CurrencyMismatch(
                    f'cannot add {amount.currency} to a line in {net_price.currency}')
            if amount.amount < 0:
                raise ValueError("an add-on's amount is never negative")
            total = _EXACT.add(total, amount.amount)
    except Inexact:
        raise ValueError('too many percentages for an exact line price') from None
    return Money(total, net_price.currency)


@dataclasses.dataclass(frozen=True)
class MonthlyCost:
    """A monthly cost link of a product: `label` (the provider product's code, with its
    id when another link of the product has the same code: `link_labels`), the link's
    `quantity` and `cost`, the monthly cost of the link (the provider product's
    cost on the date × the quantity, `Money`), or None when there is none on the date."""

    label: str
    quantity: int
    cost: object


@dataclasses.dataclass(frozen=True)
class ProductCost:
    """A product's cost on a date (`sum_costs`): `total` is the sum of its links that are
    not monthly and have a cost on the date (`Money`). It is the product's cost only when
    `complete`; otherwise it is a partial sum, to be shown as such, with `missing`: the
    labels (provider product codes, with the id when two links share a code:
    `link_labels`) of the links without a cost. `monthly`: the monthly links
    (`MonthlyCost`), never in `total`. `links`: how many links are not monthly, summed
    or missing; with none (`empty`: no links, or only monthly ones) there is nothing to
    sum and the product has no cost to show: `total` is then 0.00, which is not a known
    cost of zero."""

    total: object
    complete: bool
    missing: tuple
    monthly: tuple
    links: int = 0

    @property
    def empty(self):
        """Whether no link is summed or missing: the product has no cost to show."""
        return self.links == 0

    @property
    def warning(self):
        """'' for a complete cost; otherwise the warning to show with the partial sum."""
        if self.complete:
            return ''
        return ('Incomplete cost: no cost on this date for ' + ', '.join(self.missing)
                + '.')


def link_labels(links):
    """The labels of a product's cost links, in order, from ``(code, id)`` pairs: the
    provider product's code (not unique across providers; None when it is not known:
    the label is then the id), followed by its id in brackets when another link of the
    product has the same code, so a warning always tells two provider products apart."""
    links = [(code, str(id_)) for code, id_ in links]
    codes = [code for code, _id in links if code is not None]
    return [id_ if code is None else code if codes.count(code) == 1 else f'{code} ({id_})'
            for code, id_ in links]


def sum_costs(entries, currency):
    """The `ProductCost` of a product of `currency` from its links' `entries`, each
    ``(label, quantity, monthly, cost)``: the link's label (`link_labels`), the link's
    quantity, whether the link is monthly, and what one unit of the provider product
    costs on the date (`Money`, or None: no cost on that date). A cost in another
    currency than `currency` counts as missing: it is never converted or summed."""
    from ..money import Money
    total, missing, monthly, links = Money.zero(currency), [], [], 0
    for label, quantity, is_monthly, cost in entries:
        if not _is_quantity(quantity) or quantity < 1:
            raise ValueError("a link's quantity is a whole number above 0")
        if cost is not None and cost.currency != currency:
            cost = None
        if is_monthly:
            monthly.append(MonthlyCost(label, quantity,
                                       None if cost is None else cost * quantity))
        else:
            links += 1
            if cost is None:
                missing.append(label)
            else:
                total = total + cost * quantity
    return ProductCost(total=total, complete=not missing, missing=tuple(missing),
                       monthly=tuple(monthly), links=links)


class PerUnit(ContractModel):
    """A product priced per unit (0.21.0): the quantities it is sold in, both
    inclusive."""

    min_quantity: Quantity
    max_quantity: Quantity

    @model_validator(mode='after')
    def _in_order(self):
        if self.max_quantity < self.min_quantity:
            raise ValueError('a maximum quantity is never below the minimum')
        return self


class ProductCalls(ContractModel):
    """The calls a product grants (0.21.0): `count` calls of `minutes` minutes each."""

    count: Quantity
    minutes: Quantity


class CostLink(ContractModel):
    """A provider product a product is made of (0.21.0): its id in the snapshot's
    ``provider_costs`` section, how many, and whether its cost is monthly (then listed
    apart, never in the product's cost)."""

    provider_product: CanonicalUuid
    quantity: Quantity
    monthly: StrictBool


# A product's optional fields (0.20.0; size, per_unit, calls and cost_links 0.21.0;
# region 0.25.0): left out of a dump when None.
PRODUCT_OPTIONAL = ('texts', 'code', 'valid_from', 'valid_to', 'size', 'per_unit', 'calls',
                    'cost_links', 'region')


class CatalogueProduct(ContractModel):
    """A product, at its net price; since 0.20.0 with its optional public texts per
    language, internal code and validity dates; since 0.21.0 with its optional size,
    per-unit quantity range, calls and cost links; since 0.25.0 with its optional
    region."""

    id: CanonicalUuid
    name: Name
    category: Code
    net_price: Amount
    active: StrictBool
    texts: dict[LanguageCode, ProductText] | None = None
    code: ProductCode | None = None
    valid_from: IsoDate | None = None
    valid_to: IsoDate | None = None
    size: Code | None = None
    per_unit: PerUnit | None = None
    calls: ProductCalls | None = None
    cost_links: list[CostLink] | None = None
    region: RegionCode | None = None

    @model_serializer(mode='wrap')
    def _without_absent_fields(self, handler):
        return _without_absent(handler(self), PRODUCT_OPTIONAL)

    @model_validator(mode='after')
    def _consistent(self):
        if self.net_price.amount < 0:
            raise ValueError('a net price is never negative')
        if self.texts is not None:
            _check_texts(self.texts, 'a product')
            if self.texts[ENGLISH].name != self.name:
                raise ValueError("a product's name is the English name of its texts")
        if (self.valid_from is not None and self.valid_to is not None
                and self.valid_to < self.valid_from):
            raise ValueError("a product's validity ends before it starts")
        if self.cost_links is not None:
            _each_once([link.provider_product for link in self.cost_links],
                       'a product links a provider product twice')
        return self

    def _text(self, language, field):
        return _text_in(self.texts, language, field)

    def name_in(self, language):
        """The public name in `language` ("es"), else in English, else ``name`` (a row
        without texts)."""
        return self._text(language, 'name') or self.name

    def description_in(self, language):
        """The short description in `language`, else in English, else ''."""
        return self._text(language, 'description')

    def offered_on(self, day):
        """Whether `day` (a date, in Madrid time) is within the validity dates, both
        inclusive; an absent date does not limit. It says nothing of ``active``."""
        return ((self.valid_from is None or self.valid_from <= day)
                and (self.valid_to is None or day <= self.valid_to))

    def check_quantity(self, quantity):
        """`QuantityRefused` unless the product is sold in `quantity`: within its
        ``per_unit`` range, or exactly 1 without one (0.21.0)."""
        if self.per_unit is None:
            check_quantity(quantity)
        else:
            check_quantity(quantity, self.per_unit.min_quantity, self.per_unit.max_quantity)

    def line_price(self, add_ons=(), quantity=1, discount_percent=Decimal(0)):
        """The price (`Money`) of a line of this product with the chosen `add_ons`
        (`CatalogueAddOn`) and `quantity`, under a subscription discount on the product
        (a Decimal percentage): see `line_price`. `QuantityRefused` for a quantity the
        product is not sold in; `AddOnRefused` for an add-on that is inactive, not
        offered on this product or chosen twice; a ValueError for a product in a
        currency outside `mytp_core.money.CURRENCIES`."""
        from ..money import Money
        self.check_quantity(quantity)
        add_ons = list(add_ons)
        _check_add_ons(add_ons, self.id, lambda add_on: add_on.id,
                       lambda add_on: add_on.active and add_on.applies_to(self))
        return line_price(
            Money.from_contract(self.net_price), quantity=quantity,
            discount_percent=discount_percent,
            percents=[add_on.percent for add_on in add_ons if add_on.percent is not None],
            amounts=[Money.from_contract(add_on.amount) for add_on in add_ons
                     if add_on.amount is not None])

    def cost_at(self, day, provider_costs):
        """The product's `ProductCost` on `day` (a date) from its ``cost_links`` and the
        snapshot's provider costs section (`ProviderCostsSection`, or None: then every
        link is missing): see `sum_costs`. A link is named by its provider product's
        code (with its id when two links share a code: `link_labels`), or by its id
        when the section does not list it. A ValueError for a product in a currency
        outside `mytp_core.money.CURRENCIES`."""
        links = list(self.cost_links or ())
        listed = [None if provider_costs is None else provider_costs.product(
            link.provider_product) for link in links]
        labels = link_labels([(item and item.code, link.provider_product)
                              for link, item in zip(links, listed)])
        return sum_costs(
            [(label, link.quantity, link.monthly,
              None if item is None else item.cost_money_at(day))
             for label, link, item in zip(labels, links, listed)],
            self.net_price.currency)


def _check_add_ons(add_ons, product_id, key, offered):
    """`AddOnRefused` when one of `add_ons` is chosen twice or is not `offered`."""
    keys = [key(add_on) for add_on in add_ons]
    if len(keys) != len(set(keys)):
        raise AddOnRefused('an add-on is chosen twice')
    for add_on in add_ons:
        if not offered(add_on):
            raise AddOnRefused(f'the add-on {add_on.code} is not offered on the product '
                               f'{product_id}')


# An add-on's optional fields: left out of a dump when None.
ADD_ON_OPTIONAL = ('amount', 'percent', 'sizes')


class CatalogueAddOn(ContractModel):
    """What a buyer may choose next to a product (0.21.0): a fixed net ``amount`` or a
    signed ``percent`` of the product's net price, offered on the listed product
    ``categories`` and, when ``sizes`` is given, only on products of those sizes."""

    id: CanonicalUuid
    code: ProductCode
    texts: dict[LanguageCode, ProductText]
    amount: Amount | None = None
    percent: SignedPercent | None = None
    categories: list[Code]
    sizes: list[Code] | None = None
    active: StrictBool

    @model_serializer(mode='wrap')
    def _without_absent_fields(self, handler):
        return _without_absent(handler(self), ADD_ON_OPTIONAL)

    @model_validator(mode='after')
    def _consistent(self):
        _check_texts(self.texts, 'an add-on')
        if (self.amount is None) == (self.percent is None):
            raise ValueError('an add-on has an amount or a percentage, never both')
        if self.amount is not None and self.amount.amount < 0:
            raise ValueError("an add-on's amount is never negative")
        _each_once(self.categories, 'an add-on lists a category twice')
        if self.sizes is not None:
            _each_once(self.sizes, 'an add-on lists a size twice')
        return self

    @property
    def name(self):
        """The English public name."""
        return self.texts[ENGLISH].name

    def name_in(self, language):
        """The public name in `language`, else in English."""
        return _text_in(self.texts, language, 'name')

    def description_in(self, language):
        """The short description in `language`, else in English, else ''."""
        return _text_in(self.texts, language, 'description')

    def applies_to(self, product):
        """Whether it is offered on `product` (a `CatalogueProduct`): its category, its
        size and, for a fixed amount, its currency (`add_on_applies`). It says nothing
        of ``active``."""
        return add_on_applies(
            categories=self.categories, sizes=self.sizes,
            currency=None if self.amount is None else self.amount.currency,
            product_category=product.category, product_size=product.size,
            product_currency=product.net_price.currency)


# 0.22.0: the product categories the two former discount fields of a subscription are
# the discounts of, and the category code of an admin site before 0.20.0 read as one.
TPS_BRANDED = 'tps_branded'
TPS_IN_HOUSE = 'tps_in_house'
_LEGACY_CATEGORIES = {'tps': TPS_BRANDED}
_ZERO_PERCENT = Decimal('0.00')
ExtraCalls = Annotated[StrictInt, Field(ge=0, le=MAX_QUANTITY)]


def subscription_discount(category, *, discounts=None, tps_branded=_ZERO_PERCENT,
                          tps_in_house=_ZERO_PERCENT):
    """A subscription's discount (a Decimal percentage) on a product of `category`
    (0.22.0): the value of `discounts` (the category → percentage map; None when the
    subscription has none) for that category; else, for a TPS branded or TPS in-house
    product, the former field (`tps_branded`: ``tps_discount_percent``; `tps_in_house`:
    ``tps_in_house_discount_percent``; None, an absent field, reads as 0); else 0.
    ``tps``, the code of an admin site before 0.20.0, is read as ``tps_branded``.

    The discount is re-checked, as `line_price` re-checks its inputs: a ValueError
    unless it is a Decimal (or a whole number) from 0 to 100. A site that reads its own
    rows converts a stored text to a Decimal first, and never passes a float."""
    category = _LEGACY_CATEGORIES.get(category, category)
    if discounts is not None and category in discounts:
        value = discounts[category]
    elif category in (TPS_BRANDED, TPS_IN_HOUSE):
        value = tps_branded if category == TPS_BRANDED else tps_in_house
        if value is None:
            return _ZERO_PERCENT
    else:
        return _ZERO_PERCENT
    return _percentage(value, Decimal(0), 'a discount')


def subscription_offers(product_id, products=None):
    """Whether a subscription gives access to the product `product_id` (0.22.0):
    whether it is among `products`, the subscription's linked product ids (compared as
    strings, so UUIDs and their texts both do); every product when `products` is None
    (a subscription without the list: an admin site before 0.22.0)."""
    if products is None:
        return True
    return str(product_id) in {str(linked) for linked in products}


def calls_under(count, minutes, extra_calls=0, extra_minutes=None):
    """The calls of a product under a subscription (0.22.0), as ``(count, minutes)``:
    the product's `count` calls plus the subscription's `extra_calls` for its category,
    each of `extra_minutes` when the subscription gives a length (it replaces the
    product's `minutes`, also for a product with a count and no `minutes`). None for a
    product that grants no calls (`count` None): the extras add to what a product
    grants, they grant nothing by themselves; None too when neither gives a length.

    Every argument is checked first, whatever the answer: a ValueError unless `count`,
    `minutes` and `extra_minutes` are None or whole numbers from 1 to `MAX_QUANTITY`
    and `extra_calls` is None (no extra call) or a whole number from 0 to
    `MAX_QUANTITY`; and a ValueError when the calls together are above `MAX_QUANTITY`
    (the bound of every site's integer column)."""
    for value, low, what in (
            (count, 1, "a product's calls are a whole number above 0"),
            (minutes, 1, 'the minutes of a call are a whole number above 0'),
            (extra_calls, 0, 'extra calls are a whole number, 0 or more'),
            (extra_minutes, 1, 'the minutes of a call are a whole number above 0')):
        if value is not None and (not _is_quantity(value)
                                  or not low <= value <= MAX_QUANTITY):
            raise ValueError(what)
    length = minutes if extra_minutes is None else extra_minutes
    if count is None or length is None:
        return None
    total = count + (extra_calls or 0)
    if total > MAX_QUANTITY:
        raise ValueError(f'the calls of a product are at most {MAX_QUANTITY}')
    return (total, length)


class SubscriptionPrice(ContractModel):
    """What a subscription itself costs (0.22.0), in one currency: a ``monthly`` amount
    and an ``upfront`` amount for a year, never negative; at least one of them (a free
    subscription has no ``price`` at all)."""

    currency: str = Field(pattern=CURRENCY_PATTERN, description='ISO 4217 code, e.g. EUR.')
    monthly: DecimalAmount | None = None
    upfront: DecimalAmount | None = None

    @model_serializer(mode='wrap')
    def _without_absent_fields(self, handler):
        return _without_absent(handler(self), ('monthly', 'upfront'))

    @model_validator(mode='after')
    def _not_negative(self):
        if self.monthly is None and self.upfront is None:
            raise ValueError("a subscription's price has a monthly or an upfront amount: "
                             'a free subscription has no price')
        for amount in (self.monthly, self.upfront):
            if amount is not None and amount < 0:
                raise ValueError("a subscription's price is never negative")
        return self


class CallExtras(ContractModel):
    """What a subscription adds to the calls of a product of one category (0.22.0):
    ``extra_calls`` more calls and, when given, ``minutes``: the length of each call,
    which replaces the product's."""

    extra_calls: ExtraCalls
    minutes: Quantity | None = None

    @model_serializer(mode='wrap')
    def _without_absent_fields(self, handler):
        return _without_absent(handler(self), ('minutes',))


# A subscription's optional fields (0.20.0: the in-house discount; the others 0.22.0):
# left out of a dump when None.
SUBSCRIPTION_OPTIONAL = ('tps_in_house_discount_percent', 'code', 'texts', 'products',
                         'discounts', 'price', 'call_extras')


class CatalogueSubscription(ContractModel):
    """A subscription tier in one country group, with its discounts: on TPS branded
    products (``tps_discount_percent``) and, since 0.20.0, on TPS in-house ones; since
    0.22.0 with its optional code, public texts, linked products, discounts per product
    category, own price and call extras per product category."""

    id: CanonicalUuid
    tier: Code
    country_group: CanonicalUuid
    tps_discount_percent: Percent
    # 0.20.0: optional, so the snapshot of an older admin site stays valid.
    tps_in_house_discount_percent: Percent | None = None
    active: StrictBool
    # 0.22.0: optional, as above.
    code: ProductCode | None = None
    texts: dict[LanguageCode, ProductText] | None = None
    products: list[CanonicalUuid] | None = None
    discounts: dict[Code, Percent] | None = None
    price: SubscriptionPrice | None = None
    call_extras: dict[Code, CallExtras] | None = None

    @model_serializer(mode='wrap')
    def _without_absent_fields(self, handler):
        return _without_absent(handler(self), SUBSCRIPTION_OPTIONAL)

    @model_validator(mode='after')
    def _consistent(self):
        if self.texts is not None:
            _check_texts(self.texts, 'a subscription')
        if self.products is not None:
            _each_once(self.products, 'a subscription links a product twice')
        if self.discounts is not None and (
                self.discounts.get(TPS_BRANDED, _ZERO_PERCENT) != self.tps_discount_percent
                or self.discounts.get(TPS_IN_HOUSE, _ZERO_PERCENT)
                != self.in_house_discount_percent):
            raise ValueError("a subscription's two TPS discount fields are the "
                             'tps_branded and tps_in_house values of its discounts')
        return self

    @property
    def in_house_discount_percent(self):
        """The discount on TPS in-house products: 0 when the snapshot has none."""
        if self.tps_in_house_discount_percent is None:
            return Decimal('0.00')
        return self.tps_in_house_discount_percent

    def discount_for(self, category):
        """The discount (a Decimal percentage) on a product of `category`: see
        `subscription_discount` (0.22.0)."""
        return subscription_discount(
            category, discounts=self.discounts, tps_branded=self.tps_discount_percent,
            tps_in_house=self.in_house_discount_percent)

    def offers(self, product):
        """Whether the subscription gives access to `product` (a `CatalogueProduct` or
        its id): whether it is among ``products``; every product when the subscription
        has no list (an admin site before 0.22.0). It says nothing of either's
        ``active`` or of the product's validity dates (0.22.0)."""
        return subscription_offers(getattr(product, 'id', product), self.products)

    def calls_for(self, product):
        """The calls of `product` (a `CatalogueProduct`) under the subscription, as
        ``(count, minutes)``, or None for a product that grants none: see `calls_under`
        (0.22.0)."""
        if product.calls is None:
            return None
        extras = (self.call_extras or {}).get(
            _LEGACY_CATEGORIES.get(product.category, product.category))
        return calls_under(product.calls.count, product.calls.minutes,
                           extras.extra_calls if extras else 0,
                           extras.minutes if extras else None)

    def name_in(self, language):
        """The public name in `language`, else in English, else '' (a subscription
        without texts: an admin site before 0.22.0)."""
        return _text_in(self.texts, language, 'name')

    def description_in(self, language):
        """The short description in `language`, else in English, else ''."""
        return _text_in(self.texts, language, 'description')


def _unique(rows, label):
    ids = [row.id for row in rows]
    if len(ids) != len(set(ids)):
        raise ValueError(f'{label} lists an id twice')


# --- Billing companies and billing rules (0.23.0) -------------------------------------------

# The payment gateways the admin site of 0.23.0 offers for a rule, as written in
# ``gateways``. An open list in the contract: a later release adds one with its adapter
# (epic-payments), and a reader skips a gateway it does not know (`known_gateways`).
BILLING_GATEWAYS = ('redsys', 'revolut', 'bank_transfer')

COMPANY_CODE_PATTERN = r'^[A-Z0-9]{1,16}$'
CompanyCode = Annotated[str, StringConstraints(pattern=COMPANY_CODE_PATTERN)]
LEGAL_NAME_MAX_LENGTH, ADDRESS_MAX_LENGTH = 200, 500
IDENTIFIER_MAX_LENGTH, BILLING_TEXT_MAX_LENGTH = 64, 1000
Identifier = Annotated[str, StringConstraints(min_length=1,
                                              max_length=IDENTIFIER_MAX_LENGTH)]
# A company's optional fields (region 0.25.0): left out of a dump when None.
COMPANY_OPTIONAL = ('company_number', 'vat_number', 'tax_number', 'region')
# A rule's optional fields: left out of a dump when None.
RULE_OPTIONAL = ('exemption_text', 'reverse_charge_text')


def known_gateways(gateways, known=BILLING_GATEWAYS):
    """The `gateways` of a rule that this release knows, in the rule's order (0.23.0)."""
    return [gateway for gateway in gateways if gateway in known]


def billing_offers(rules_exist, rule_available=None, rule_currency=None,
                   product_currency=None):
    """Whether a product is offered to the doctors of a country group (0.23.0), from
    plain values, for a site that reads its own tables. `rules_exist`: whether the
    section had a ``billing_rules`` list (since 0.25.0 an empty one counts: rules exist,
    none of them this region's), so a catalogue whose rules are all deactivated, or all
    another region's, has rules and nothing without a rule is offered; without the list
    every product is offered, as before 0.23.0. With rules, the product is offered only when its group and category
    have an active rule (`rule_available` is that rule's ``available``; None when the
    pair has no active rule) that is available and whose currency (`rule_currency`) is
    the product's (`product_currency`)."""
    if not rules_exist:
        return True
    return bool(rule_available) and rule_currency == product_currency


class CatalogueBillingCompany(ContractModel):
    """A company that bills (0.23.0): its short code, legal name, address, country,
    legal time zone and its optional identifiers (company number or license, VAT
    registration, TAX registration); since 0.25.0 with its optional region."""

    id: CanonicalUuid
    code: CompanyCode
    legal_name: str = Field(min_length=1, max_length=LEGAL_NAME_MAX_LENGTH)
    address: str = Field(min_length=1, max_length=ADDRESS_MAX_LENGTH)
    country: CountryCode
    time_zone: str = Field(min_length=1, max_length=64)
    company_number: Identifier | None = None
    vat_number: Identifier | None = None
    tax_number: Identifier | None = None
    active: StrictBool
    region: RegionCode | None = None

    @model_serializer(mode='wrap')
    def _without_absent_fields(self, handler):
        return _without_absent(handler(self), COMPANY_OPTIONAL)

    @model_validator(mode='after')
    def _not_blank(self):
        if not self.legal_name.strip() or not self.address.strip():
            raise ValueError("a billing company's legal name and address are not blank")
        if any(value is not None and not value.strip()
               for value in (self.company_number, self.vat_number, self.tax_number)):
            raise ValueError("a billing company's identifier is left out, never blank")
        return self


class CatalogueBillingRule(ContractModel):
    """The billing rule of one country group and product category (0.23.0): the company
    that bills, the VAT rate, the exemption text of a rate of 0, an optional
    reverse-charge text, the payment gateways in order of preference, the currency the
    pair is sold in and whether the category is available there."""

    id: CanonicalUuid
    country_group: CanonicalUuid
    category: Code
    company: CanonicalUuid
    vat_percent: Percent
    exemption_text: str | None = Field(default=None, max_length=BILLING_TEXT_MAX_LENGTH)
    reverse_charge_text: str | None = Field(default=None,
                                            max_length=BILLING_TEXT_MAX_LENGTH)
    gateways: list[Code]
    currency: str = Field(pattern=CURRENCY_PATTERN, description='ISO 4217 code, e.g. EUR.')
    available: StrictBool
    active: StrictBool

    @model_serializer(mode='wrap')
    def _without_absent_fields(self, handler):
        return _without_absent(handler(self), RULE_OPTIONAL)

    @model_validator(mode='after')
    def _consistent(self):
        if self.vat_percent == 0 and not (self.exemption_text or '').strip():
            raise ValueError('a billing rule with a rate of 0 has its exemption text')
        if self.reverse_charge_text is not None and not self.reverse_charge_text.strip():
            raise ValueError("a billing rule's reverse-charge text is left out, never "
                             'blank')
        _each_once(self.gateways, 'a billing rule lists a gateway twice')
        return self

    @property
    def exempt(self):
        """Whether the rate is 0: the exemption text is then what an invoice shows."""
        return self.vat_percent == 0

    def offers(self, product):
        """Whether `product` (a `CatalogueProduct`) is offered under this rule: the rule
        is active and available and sells in the product's currency. It says nothing
        of the product's own state, and does not check the product's category."""
        return self.active and billing_offers(
            True, self.available, self.currency, product.net_price.currency)


class CatalogueSection(ContractModel):
    """The snapshot's ``catalogue``: see the module docstring."""

    country_groups: list[CatalogueCountryGroup]
    products: list[CatalogueProduct]
    subscriptions: list[CatalogueSubscription]
    # 0.21.0: optional, so the snapshot of an older admin site stays valid.
    add_ons: list[CatalogueAddOn] | None = None
    # 0.22.0: optional, as above. The subscriptions assigned by hand; `subscriptions`
    # are the standard ones.
    manual_subscriptions: list[CatalogueSubscription] | None = None
    # 0.23.0: optional, as above.
    billing_companies: list[CatalogueBillingCompany] | None = None
    billing_rules: list[CatalogueBillingRule] | None = None

    @model_serializer(mode='wrap')
    def _without_absent_fields(self, handler):
        return _without_absent(handler(self), ('add_ons', 'manual_subscriptions',
                                               'billing_companies', 'billing_rules'))

    def billing_company(self, company_id):
        """The billing company of this id, whatever its state, or None (0.23.0)."""
        company_id = str(company_id)
        return next((company for company in self.billing_companies or ()
                     if str(company.id) == company_id), None)

    def billing_rule(self, country_group, category):
        """The active billing rule of a country group (a `CatalogueCountryGroup` or its
        id) and a product category, or None (0.23.0). ``tps``, the code of an admin
        site before 0.20.0, is read as ``tps_branded``."""
        group_id = str(getattr(country_group, 'id', country_group))
        category = _LEGACY_CATEGORIES.get(category, category)
        return next((rule for rule in self.billing_rules or ()
                     if rule.active and str(rule.country_group) == group_id
                     and _LEGACY_CATEGORIES.get(rule.category, rule.category)
                     == category), None)

    def billing_offered(self, country_group, category):
        """Whether the products of `category` are offered to the doctors of a country
        group (0.23.0): always, in a section without a rules list (an admin site before
        0.23.0, or no rule typed yet); otherwise, an empty list included (0.25.0: rules
        exist, none of them this region's), only when the pair has an active rule that
        is available. A product is then offered only in the rule's currency
        (`CatalogueBillingRule.offers`)."""
        if self.billing_rules is None:
            return True
        rule = self.billing_rule(country_group, category)
        return rule is not None and rule.available

    def subscription(self, subscription_id):
        """The subscription of this id, standard or manual, whatever its state, or None
        (0.22.0)."""
        subscription_id = str(subscription_id)
        return next((subscription for subscription
                     in (*self.subscriptions, *(self.manual_subscriptions or ()))
                     if str(subscription.id) == subscription_id), None)

    def add_ons_for(self, product):
        """The active add-ons offered on `product` (a `CatalogueProduct`), as listed;
        none when the section has no ``add_ons`` (an admin site before 0.21.0)."""
        return [add_on for add_on in self.add_ons or ()
                if add_on.active and add_on.applies_to(product)]

    @model_validator(mode='after')
    def _consistent(self):
        _unique(self.country_groups, 'country_groups')
        _unique(self.products, 'products')
        _unique(self.subscriptions, 'subscriptions')
        if self.add_ons is not None:
            # 0.21.0: an add-on's id and code are each once.
            _unique(self.add_ons, 'add_ons')
            _each_once([add_on.code for add_on in self.add_ons],
                       'two add-ons have the same code')
        # 0.20.0: a code is unique among the products that have one.
        codes = [product.code for product in self.products if product.code is not None]
        if len(codes) != len(set(codes)):
            raise ValueError('two products have the same code')
        # 0.25.0: per region. A group without a region is every region's: it counts in
        # each region's check, so the body served to a region (`for_region`) keeps the
        # rules of before 0.25.0.
        active_groups = [group for group in self.country_groups if group.active]
        regions = {group.region for group in active_groups} - {None}
        for region in sorted(regions) or [None]:
            seen, catch_alls = set(), 0
            for group in active_groups:
                if group.region not in (None, region):
                    continue
                if seen & set(group.countries):
                    raise ValueError('a country is in two active country groups')
                seen |= set(group.countries)
                catch_alls += group.catch_all
            if catch_alls > 1:
                raise ValueError('two active country groups are the catch-all')
        groups = {group.id for group in self.country_groups}
        pairs = set()
        for subscription in self.subscriptions:
            if subscription.country_group not in groups:
                raise ValueError('a subscription names a country group not listed')
            if subscription.active:
                pair = (subscription.tier, subscription.country_group)
                if pair in pairs:
                    raise ValueError('two active subscriptions of one tier and country group')
                pairs.add(pair)
        # 0.22.0: the manual subscriptions. The rule above is not theirs: any number
        # may be active for a tier and group.
        manual = self.manual_subscriptions or ()
        _unique([*self.subscriptions, *manual], 'subscriptions and manual_subscriptions')
        for subscription in manual:
            if subscription.country_group not in groups:
                raise ValueError('a subscription names a country group not listed')
        _each_once([subscription.code for subscription in (*self.subscriptions, *manual)
                    if subscription.code is not None],
                   'two subscriptions have the same code')
        # 0.23.0: the billing companies and rules. Rules on the new lists only.
        companies = self.billing_companies or ()
        _unique(companies, 'billing_companies')
        _each_once([company.code for company in companies],
                   'two billing companies have the same code')
        rules = self.billing_rules or ()
        _unique(rules, 'billing_rules')
        company_ids = {company.id: company.active for company in companies}
        pairs = set()
        for rule in rules:
            if rule.country_group not in groups:
                raise ValueError('a billing rule names a country group not listed')
            if rule.company not in company_ids:
                raise ValueError('a billing rule names a billing company not listed')
            if rule.active:
                if not company_ids[rule.company]:
                    raise ValueError('an active billing rule names an inactive billing '
                                     'company')
                # ``tps`` is tps_branded (`billing_rule`): one pair.
                pair = (rule.country_group,
                        _LEGACY_CATEGORIES.get(rule.category, rule.category))
                if pair in pairs:
                    raise ValueError('two active billing rules of one country group and '
                                     'category')
                pairs.add(pair)
        return self

"""The per-region filter of a configuration snapshot body (0.25.0, architecture AD-3,
AD-14; epic-catalogue entry 16): the admin site stores one body with every region's
records and serves each portal only its own.

`for_region(body, region)` is the one function both sites use. It works on the JSON-ready
body (a dict), never changes it, and returns a shallow copy (the lists are new, the rows
are the body's own: shared, do not mutate them) holding:

- the vouchers of `region` (`contracts.vouchers.for_region`: the ``vouchers`` key is left
  out when none is left);
- in the ``catalogue`` section: the country groups, products and billing companies whose
  ``region`` is `region` or absent (a record without a region is every region's); the
  subscriptions of both lists and the billing rules whose group is kept; of those rules,
  only the ones whose company is kept; in each kept subscription's ``products``, only
  the ids of the products kept (an empty list stays empty: it offers nothing); every
  add-on (shared);
- every other key (the admin directory, the country map, the provider costs, unknown
  ones) as it is.

A list of the section that the body has stays in the result, empty when nothing of it is
left: in particular ``billing_rules`` (rules exist, none of them this region's: nothing is
offered; an absent list would mean "no rule typed": everything offered). A list the body
does not have stays absent.

The result keeps every rule of a reader before 0.25.0 when the body keeps those of 0.25.0
(`CatalogueSection`): the groups kept are one region's and those without a region, which
0.25.0 checks together; every reference (a subscription's or a rule's group, a rule's
company) is to a record kept; ids and codes are a subset of the body's. `region` None (a
peer without a region) keeps only the records without a region and no voucher.
"""
from .vouchers import for_region as vouchers_for_region

# The lists of the catalogue section whose rows carry a region.
REGIONAL_LISTS = ('country_groups', 'products', 'billing_companies')
# The lists whose rows have their group's region.
GROUP_LISTS = ('subscriptions', 'manual_subscriptions')


def _kept(row, region):
    return isinstance(row, dict) and row.get('region') in (None, region)


def _ids(rows):
    return {row.get('id') for row in rows}


def catalogue_for_region(catalogue, region):
    """A shallow copy of a JSON-ready catalogue section (a dict) with only what the
    portal of `region` is sent: see the module docstring. The rows are shared with the
    input: do not mutate them. Anything else (None, a value that is not a dict) comes
    back as it is."""
    if not isinstance(catalogue, dict):
        return catalogue
    result = dict(catalogue)
    for name in REGIONAL_LISTS:
        if isinstance(result.get(name), list):
            result[name] = [row for row in result[name] if _kept(row, region)]
    groups = _ids(result.get('country_groups') or ())
    products = _ids(result.get('products') or ())
    companies = _ids(result.get('billing_companies') or ())
    for name in GROUP_LISTS:
        if isinstance(result.get(name), list):
            result[name] = [_with_products(row, products) for row in result[name]
                            if isinstance(row, dict) and row.get('country_group') in groups]
    if isinstance(result.get('billing_rules'), list):
        result['billing_rules'] = [
            rule for rule in result['billing_rules']
            if isinstance(rule, dict) and rule.get('country_group') in groups
            and rule.get('company') in companies]
    return result


def _with_products(subscription, products):
    """The subscription with only the linked product ids among `products` (a copy when
    one is left out; absent stays absent: every product, an admin site before 0.22.0)."""
    linked = subscription.get('products')
    if not isinstance(linked, list):
        return subscription
    kept = [product for product in linked if product in products]
    if len(kept) == len(linked):
        return subscription
    return {**subscription, 'products': kept}


def for_region(body, region):
    """A shallow copy of a JSON-ready snapshot body (a dict) with only what the portal of
    `region` (a region code, or None) is sent: see the module docstring. The body is
    left as it is; the rows are shared with it: do not mutate them."""
    result = vouchers_for_region(body, region)
    if 'catalogue' in result:
        result['catalogue'] = catalogue_for_region(result['catalogue'], region)
    return result

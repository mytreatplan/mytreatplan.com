"""The vouchers section of the configuration snapshot (0.24.0, architecture AD-3, AD-6,
AD-20; epic-catalogue entry 10): the discount codes the admin site defines, each for one
region, which only that region's portal receives.

    {"vouchers": [{"id": "<uuid>", "code": "K7QM2XH9TR", "type": "try_me", "region": "eu",
                   "amount": {"amount": "50.00", "currency": "EUR"}, "client": null,
                   "valid_from": "2026-11-12", "valid_to": null, "active": true}]}

- ``vouchers`` is a top-level optional field of the snapshot (`ConfigSnapshot.vouchers`),
  a list. Every voucher of the region is listed, inactive ones too (``active: false``: a
  past order still reads it); ids are UUID strings, each once; codes are each once.
- ``code``: 4 to 32 uppercase letters and digits, stored without a hyphen. The admin site
  of 0.24.0 writes 10 characters of `CODE_ALPHABET` (no 0, O, 1, I, L: `new_code`); a
  person reads it as ``XXXXX-XXXXX`` (`display_code`) and may type it with or without the
  hyphen (or a typographic dash, U+2010 to U+2015, U+2212), in any case
  (`normalize_code`).
- ``type``: ``subscription`` or ``try_me`` (`VOUCHER_TYPES`). An open list: a type a
  reader does not know is kept as text (`Voucher.known_type` is False) and the reader
  treats the voucher as not usable.
- ``region``: the region code (``eu``, ``ae``) the voucher belongs to; a portal skips a
  voucher of another region (`for_region` keeps them out of what it is sent).
- ``amount``: a fixed amount (`contracts.Amount`), above zero. The admin site writes only
  `mytp_core.money.CURRENCIES`; `Voucher.money` gives None for a currency it does not
  know.
- ``client``: the client UUID of the one doctor the voucher is for, or null (any doctor).
- ``valid_from``, ``valid_to``: ISO dates, both included (Madrid days, as product
  validity is); ``valid_to`` null for no end, never before ``valid_from``.
  `Voucher.in_force_on(day)` says whether a day is inside them.

No use count, reservation or "already used" state is in it: redemption is
epic-subscriptions' (AD-20), which enforces the limits from the type.

The rules (ids and codes once; a code's form; the dates in order; the amount above zero)
are part of the reader contract: a snapshot that breaks one is refused whole
(`invalid_body`). Relaxing any of them is a breaking change and needs a `min_reader`
bump.

`for_region(body, region)` is the one filter both sites use: the admin site stores one
snapshot body and serves each portal only its region's vouchers.
"""
import re
import secrets
from typing import Annotated

from pydantic import (AfterValidator, Field, StrictBool, StringConstraints,
                      model_validator)

from .amounts import Amount
from .base import ContractModel
from .events import REGION_PATTERN, CanonicalUuid
from .provider_costs import IsoDate

# The voucher types the admin site of 0.24.0 writes: a subscription voucher discounts a
# subscription (used once in total), a try-me voucher any service order (once per
# doctor). An open list (`Voucher.known_type`).
SUBSCRIPTION, TRY_ME = 'subscription', 'try_me'
VOUCHER_TYPES = (SUBSCRIPTION, TRY_ME)
TYPE_PATTERN = r'^[a-z][a-z0-9_]{0,31}$'

# The characters of a generated code: uppercase letters and digits without the
# confusable 0, O, 1, I and L (31 characters).
CODE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'
CODE_LENGTH = 10
# Wide on purpose: a reader rule cannot be relaxed later.
CODE_PATTERN = r'^[A-Z0-9]{4,32}$'
CODE_RE = re.compile(CODE_PATTERN)
VoucherCode = Annotated[str, StringConstraints(pattern=CODE_PATTERN)]
VoucherType = Annotated[str, StringConstraints(pattern=TYPE_PATTERN)]
# What a person may type between the characters of a code: spaces, the hyphen and the
# typographic dashes a paste brings (U+2010 to U+2015, U+2212).
DASHES_RE = re.compile('[\\s\\-\u2010-\u2015\u2212]')


def new_code():
    """A new random code: `CODE_LENGTH` characters of `CODE_ALPHABET` (``secrets``).
    Unique across all regions is the admin site's check: it draws again on a
    collision."""
    return ''.join(secrets.choice(CODE_ALPHABET) for _ in range(CODE_LENGTH))


def normalize_code(text):
    """The stored form of a code as a person types it (``k7qm2-xh9tr``, `` K7QM2XH9TR ``,
    ``K7QM2–XH9TR``): uppercase, without spaces, hyphens and typographic dashes (U+2010 to
    U+2015, U+2212). None when what is left is not a code's form."""
    if not isinstance(text, str):
        return None
    code = DASHES_RE.sub('', text).upper()
    return code if CODE_RE.fullmatch(code) else None


def display_code(code):
    """How a person reads a code: ``XXXXX-XXXXX`` for a 10-character code, else as
    stored."""
    if len(code) == CODE_LENGTH:
        return f'{code[:5]}-{code[5:]}'
    return code


class Voucher(ContractModel):
    """One voucher definition: see the module docstring."""

    id: CanonicalUuid
    code: VoucherCode
    type: VoucherType
    region: str = Field(pattern=REGION_PATTERN)
    amount: Amount
    client: CanonicalUuid | None = None
    valid_from: IsoDate
    valid_to: IsoDate | None = None
    active: StrictBool

    @model_validator(mode='after')
    def _consistent(self):
        if self.valid_to is not None and self.valid_to < self.valid_from:
            raise ValueError('a voucher ends before it starts')
        if self.amount.amount <= 0:
            raise ValueError("a voucher's amount is above zero")
        return self

    @property
    def known_type(self):
        """Whether this release knows the type (`VOUCHER_TYPES`)."""
        return self.type in VOUCHER_TYPES

    def in_force_on(self, day):
        """Whether `day` (a date) is inside the validity dates, both included. Says
        nothing about ``active``."""
        return self.valid_from <= day and (self.valid_to is None or day <= self.valid_to)

    def money(self):
        """The amount as `mytp_core.money.Money`, or None for a currency outside
        `mytp_core.money.CURRENCIES`."""
        # Imported here: mytp_core.money imports this package (contracts.amounts).
        from ..money import CURRENCIES, Money
        if self.amount.currency not in CURRENCIES:
            return None
        return Money(self.amount.amount, self.amount.currency)


def _unique_vouchers(vouchers):
    ids = [voucher.id for voucher in vouchers]
    if len(ids) != len(set(ids)):
        raise ValueError('vouchers lists an id twice')
    codes = [voucher.code for voucher in vouchers]
    if len(codes) != len(set(codes)):
        raise ValueError('vouchers lists a code twice')
    return vouchers


VoucherList = Annotated[list[Voucher], AfterValidator(_unique_vouchers)]


def for_region(body, region):
    """A copy of a JSON-ready snapshot body (a dict) keeping only the vouchers of
    `region` (a region code, or None: none kept). The ``vouchers`` key is left out when
    no voucher is left, and every other key is the body's own (unknown ones included),
    so the result is signed and read like any snapshot. A body without vouchers comes back
    as an equal copy."""
    result = dict(body)
    vouchers = result.pop('vouchers', None)
    if isinstance(vouchers, list) and region is not None:
        kept = [voucher for voucher in vouchers
                if isinstance(voucher, dict) and voucher.get('region') == region]
        if kept:
            result['vouchers'] = kept
    return result

"""The configuration snapshot (0.10.0, architecture AD-3 item 1, AD-12, AD-22, interface
I5): the admin-owned configuration every regional portal pulls from the admin site
(``GET /api/v1/config``) and keeps applying while the admin site is down.

    {"version": 7, "min_reader": 1, "generated_at": "2026-11-05T10:00:00Z",
     "admin_directory": [{"id": "<uuid>", "display_name": "Ada Admin",
                          "title": "Sysadmin", "active": true,
                          "time_zone": "Europe/Madrid"}]}

- ``version``: an integer >= 1, higher for every change; a reader applies a snapshot only
  when its version is higher than the one it holds.
- ``min_reader``: the lowest snapshot reader format (`SNAPSHOT_READER`) that can apply
  it; a reader with a lower format keeps its current snapshot.
- ``generated_at``: ISO 8601 UTC ending in ``Z``.
- ``admin_directory``: every admin user, deleted ones included (``active`` false), so an
  admin actor UUID in a regional log still has a name (AD-22). Ids are unique.
- ``catalogue`` (0.12.0, optional): the products, country groups and subscriptions
  (`contracts.catalogue.CatalogueSection`). A snapshot without it (an admin site before
  0.12.0) is still valid, and a reader then holds an empty catalogue. Adding it changes
  neither `SNAPSHOT_READER` nor ``min_reader``: an older reader ignores it. Since 0.25.0
  it is served per region (`contracts.regions.for_region`: each portal gets its region's
  groups, companies and products), and the two group rules (a country in one active
  group, one active catch-all) hold per region.
- ``country_map`` (0.15.0, optional): the state of each country
  (`contracts.country_map.CountryMapSection`). A snapshot without it (an admin site
  before 0.15.0) is still valid, and a reader then keeps its current country rows. Like
  the catalogue, it changes neither `SNAPSHOT_READER` nor ``min_reader``.
- ``provider_costs`` (0.19.0, optional): each provider product's dated costs, without
  provider details (`contracts.provider_costs.ProviderCostsSection`). A snapshot without
  it (an admin site before 0.19.0) is still valid, and a reader then holds no costs. Like
  the others, it changes neither `SNAPSHOT_READER` nor ``min_reader``.
- ``vouchers`` (0.24.0, optional): the voucher definitions of the reader's region
  (`contracts.vouchers.Voucher`). The admin site stores one body for every region and
  serves each portal only its region's vouchers (`contracts.vouchers.for_region`), the
  key left out when there are none. A snapshot without it (an admin site before 0.24.0,
  or a region without vouchers) is still valid, and a reader then holds no vouchers.
  Like the others, it changes neither `SNAPSHOT_READER` nor ``min_reader``.
- Readers ignore unknown fields: later sections are added as new optional fields of the
  same version.

The answer to ``GET /api/v1/config`` (`ConfigResponse`) is ``{"snapshot": {...},
"signature": "<jwt>"}``; `mytp_core.snapshots` signs and verifies it. The signature
covers `snapshot_sha` of the snapshot object exactly as sent, unknown fields included.
"""
import hashlib
import json
from typing import Annotated, Any

from pydantic import (Field, StrictBool, StringConstraints, model_serializer,
                      model_validator)

from .base import ContractModel
from .catalogue import CatalogueSection
from .country_map import CountryMapSection
from .events import CanonicalUuid, Positive, UtcTime
from .provider_costs import ProviderCostsSection
from .vouchers import VoucherList

# The snapshot format this version of mytp-core reads. A snapshot whose `min_reader` is
# higher is kept out (the reader keeps its current one).
SNAPSHOT_READER = 1

Name = Annotated[str, StringConstraints(max_length=150)]

# The optional sections: left out of a dump when None.
OPTIONAL_SECTIONS = ('catalogue', 'country_map', 'provider_costs', 'vouchers')


class AdminDirectoryEntry(ContractModel):
    """One admin user: who an admin actor UUID is (AD-22)."""

    id: CanonicalUuid
    display_name: Name
    title: Name
    active: StrictBool
    time_zone: str = Field(min_length=1, max_length=64)


class ConfigSnapshot(ContractModel):
    version: Positive
    min_reader: Positive
    generated_at: UtcTime
    admin_directory: list[AdminDirectoryEntry]
    # 0.12.0: optional, so the snapshot of an older admin site stays valid.
    catalogue: CatalogueSection | None = None
    # 0.15.0: optional, so the snapshot of an older admin site stays valid.
    country_map: CountryMapSection | None = None
    # 0.19.0: optional, so the snapshot of an older admin site stays valid.
    provider_costs: ProviderCostsSection | None = None
    # 0.24.0: optional, so the snapshot of an older admin site (or one served to a
    # region without vouchers) stays valid.
    vouchers: VoucherList | None = None

    @model_serializer(mode='wrap')
    def _without_absent_sections(self, handler):
        # An absent section stays absent when dumped (never "catalogue": null), so a
        # snapshot without one dumps, and signs, exactly as before the section existed
        # (catalogue 0.12.0, country_map 0.15.0, provider_costs 0.19.0,
        # vouchers 0.24.0).
        data = handler(self)
        if isinstance(data, dict):
            for name in OPTIONAL_SECTIONS:
                if name in data and data[name] is None:
                    del data[name]
        return data

    @model_validator(mode='after')
    def _unique_ids(self):
        ids = [entry.id for entry in self.admin_directory]
        if len(ids) != len(set(ids)):
            raise ValueError('admin_directory lists an id twice')
        return self


class ConfigResponse(ContractModel):
    """The answer to ``GET /api/v1/config``."""

    snapshot: dict[str, Any] = Field(description='A ConfigSnapshot, as signed.')
    signature: str = Field(min_length=1, max_length=4096,
                           description='The snapshot token (mytp_core.snapshots).')


def canonical_json(data):
    """The canonical bytes of a JSON-ready object: sorted keys, no spaces, UTF-8. Raises
    ValueError for what is not JSON-ready (NaN, a set, a key that is not a string),
    without quoting it."""
    def keys_are_text(value):
        if isinstance(value, dict):
            return all(isinstance(key, str) and keys_are_text(item)
                       for key, item in value.items())
        if isinstance(value, (list, tuple)):
            return all(keys_are_text(item) for item in value)
        return True
    try:
        if not keys_are_text(data):
            raise TypeError
        return json.dumps(data, sort_keys=True, separators=(',', ':'), ensure_ascii=False,
                          allow_nan=False).encode('utf-8')
    except (TypeError, ValueError, RecursionError):
        raise ValueError('the snapshot is not JSON-ready') from None


def snapshot_sha(data):
    """SHA-256 hex of `canonical_json(data)`: what a snapshot token's ``sha`` claims."""
    return hashlib.sha256(canonical_json(data)).hexdigest()

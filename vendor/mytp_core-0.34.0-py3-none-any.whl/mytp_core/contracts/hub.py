"""Hub lookups (0.17.0, architecture AD-3 channel 4, AD-21, interface I10): a regional
portal reads admin-owned live data (specialist availability and slot holds, later), keeps
nothing of it, and when the admin site is down the lookup fails cleanly.

A lookup is a signed ``GET`` from a portal to the admin site under ``/api/v1/hub/``, with
the caller's region as the ``region`` query parameter (covered by the token's ``req``)::

    GET /api/v1/hub/sample-availability?region=eu

The admin site checks the signature (the portals' keyring), then that ``region`` is the
issuer's region (its `Region.site`), and answers with ``Cache-Control`` ``no-cache,
no-store`` (never cached). Refusals use the error body (`errors.hub_lookup_error`):
400 ``invalid_request`` (no or a malformed ``region``), 403 ``region_mismatch`` (the
issuer is not that region's site), 404 ``not_found`` (the lookup is not served here: the
staging sample with its setting off); the signature refusals stay 401.

Each lookup's answer is a closed model (a writer's model: an unknown field is refused,
so the portal reads exactly the agreed shape or nothing): `LOOKUP_READERS` by lookup
name. The only one so far is the staging-only ``sample_availability``
(`SampleAvailability`): a few made-up slots for the caller's region, at the admin site's
time, standing in for epic-appointments' availability; removed when real lookups exist::

    {"lookup": "sample_availability", "region": "eu",
     "generated_at": "2026-11-09T10:00:00Z",
     "slots": [{"starts_at": "2026-11-10T09:00:00Z", "ends_at": "2026-11-10T09:30:00Z",
                "specialist": "Sample specialist EU-1"}, ...]}

0.32.0 adds ``invoice_series_highest`` (`InvoiceSeriesHighestAnswer`, public: served on
every deploy): the highest number the admin site holds in each invoice and credit-note
series of the caller's region, which a portal reads once after a database restore to
raise its counters (architecture AD-7). Series keys and numbers only, no buyer data::

    GET /api/v1/hub/invoice-series-highest?region=eu

    {"lookup": "invoice_series_highest", "region": "eu",
     "generated_at": "2026-11-22T10:00:00Z",
     "series": [{"company_code": "TPS", "instance": "EU", "year": 2026,
                 "kind": "invoice", "highest": 7}, ...]}

Answers are small: a portal reads at most `MAX_LOOKUP_BYTES`.
"""
from datetime import UTC, datetime
from typing import Annotated, Literal

from pydantic import Field, StringConstraints, model_validator

from .base import WriterModel
from .events import REGION_PATTERN, UtcTime

HUB_PREFIX = '/api/v1/hub/'
SAMPLE_AVAILABILITY = 'sample_availability'
SAMPLE_AVAILABILITY_PATH = HUB_PREFIX + 'sample-availability'
INVOICE_SERIES_HIGHEST = 'invoice_series_highest'
INVOICE_SERIES_HIGHEST_PATH = HUB_PREFIX + 'invoice-series-highest'
# The largest lookup answer a portal reads (64 KB).
MAX_LOOKUP_BYTES = 64 * 1024
MAX_SLOTS = 20
# Most series one answer holds (a few companies x two kinds x a few years per region).
MAX_SERIES = 200
# An invoice number's sequence is six digits.
MAX_SERIES_NUMBER = 999999

# A made-up label, never a person's name: letters, digits, spaces, "-" and ".".
SampleLabel = Annotated[str, StringConstraints(min_length=1, max_length=64,
                                               pattern=r'^[A-Za-z0-9][A-Za-z0-9 .-]*$')]


class SampleSlot(WriterModel):
    """One made-up free slot: its start and end (UTC) and a sample specialist label."""

    starts_at: UtcTime
    ends_at: UtcTime
    specialist: SampleLabel

    @model_validator(mode='after')
    def _ends_after_start(self):
        if self.ends_at <= self.starts_at:
            raise ValueError('a slot ends after it starts')
        return self


class SampleAvailability(WriterModel):
    """The staging-only sample lookup's answer (closed): see the module docstring."""

    lookup: Literal['sample_availability']
    region: str = Field(pattern=REGION_PATTERN)
    generated_at: UtcTime
    slots: list[SampleSlot] = Field(max_length=MAX_SLOTS)

    @model_validator(mode='after')
    def _sorted_slots(self):
        starts = [slot.starts_at for slot in self.slots]
        if starts != sorted(starts):
            raise ValueError('slots are sorted by their start')
        return self


class InvoiceSeriesHighest(WriterModel):
    """The highest number held in one series: (company code, instance, year, kind), the
    kind being ``invoice`` or ``credit_note`` (the portal's `InvoiceSeries.kind`)."""

    company_code: Annotated[str, StringConstraints(min_length=1, max_length=16)]
    instance: Annotated[str, StringConstraints(min_length=1, max_length=8)]
    year: int = Field(ge=2000, le=2999)
    kind: Literal['invoice', 'credit_note']
    highest: int = Field(ge=0, le=MAX_SERIES_NUMBER)


class InvoiceSeriesHighestAnswer(WriterModel):
    """The ``invoice_series_highest`` lookup's answer (closed): see the module docstring.
    A series appears once."""

    lookup: Literal['invoice_series_highest']
    region: str = Field(pattern=REGION_PATTERN)
    generated_at: UtcTime
    series: list[InvoiceSeriesHighest] = Field(max_length=MAX_SERIES)

    @model_validator(mode='after')
    def _each_series_once(self):
        keys = [(s.company_code, s.instance, s.year, s.kind) for s in self.series]
        if len(keys) != len(set(keys)):
            raise ValueError('a series appears once')
        return self


def _in_utc(value):
    # An aware datetime in any zone is written in UTC; anything else (a naive datetime)
    # goes to the model as given, which refuses it.
    if isinstance(value, datetime) and value.utcoffset() is not None:
        return value.astimezone(UTC)
    return value


def sample_availability(region, generated_at, slots):
    """The JSON-ready answer of the sample lookup: `region` (a region code),
    `generated_at` (an aware datetime) and `slots`, an iterable of (start, end,
    specialist label) with aware datetimes. ValidationError when malformed (a naive
    datetime among them)."""
    answer = SampleAvailability(
        lookup=SAMPLE_AVAILABILITY, region=region, generated_at=_in_utc(generated_at),
        slots=[SampleSlot(starts_at=_in_utc(start), ends_at=_in_utc(end), specialist=label)
               for start, end, label in slots])
    return answer.model_dump(mode='json')


def invoice_series_highest(region, generated_at, series):
    """The JSON-ready answer of the invoice-series lookup: `region` (a region code),
    `generated_at` (an aware datetime) and `series`, an iterable of (company code,
    instance, year, kind, highest). ValidationError when malformed."""
    answer = InvoiceSeriesHighestAnswer(
        lookup=INVOICE_SERIES_HIGHEST, region=region, generated_at=_in_utc(generated_at),
        series=[InvoiceSeriesHighest(company_code=company, instance=instance, year=year,
                                     kind=kind, highest=highest)
                for company, instance, year, kind, highest in series])
    return answer.model_dump(mode='json')


LOOKUP_READERS = {SAMPLE_AVAILABILITY: SampleAvailability,
                  INVOICE_SERIES_HIGHEST: InvoiceSeriesHighestAnswer}

"""The answer to a remote read (0.13.0, architecture AD-4, AD-17, AD-23, interface I6): the
admin site reads one record of a regional portal live, and keeps nothing of it.

A portal serves each resource at its own route (the staging sample record:
``GET /api/v1/remote/sample-record``), signed by the admin site with the admin user's
access as extra claims (`mytp_core.interface.remote_actor`), answers 200 with
`RemoteRecord`, sent with ``Cache-Control: no-store``::

    {"resource": "sample_record", "region": "eu",
     "object_id": "1b4e28ba-2fa1-4d3b-a3f5-ef19b5a7633b",
     "fields": ["assignee_uuid", "note", "patient_name", "uuid"],
     "data": {"uuid": "1b4e28ba-...", "patient_name": "...", "assignee_uuid": null,
              "note": "..."}}

``fields`` lists, sorted, the names of the fields the region sent (its access log lists
the same names); ``data`` holds exactly those, and no float (amounts are `Amount`). A
field the role may not see (`mytp_core.access`) is absent, never null. Refusals use the
error body
(`errors.remote_read_error`): 403 ``forbidden``, 404 ``not_found``, 503
``access_log_unavailable``; the signature refusals stay 401.

Each resource's ``data`` has its reader model (`RESOURCE_READERS`): `SampleRecordData`
for ``sample_record`` (staging only; removed with it); `PendingTransferData` for
``pending_transfer`` (0.34.0).

Remote lists (0.34.0): a resource with many records (``pending_transfer``: the bank
transfer orders still waiting for their money, ``GET /api/v1/remote/pending-transfers``)
answers a read with `RemoteList` instead, signed and refused the same way::

    {"resource": "pending_transfer", "region": "eu",
     "fields": ["client_uid", "company_code", ...],
     "records": [{"object_id": "<uuid>", "version": 3, "data": {...}}, ...],
     "truncated": false}

Every record's ``data`` has exactly the sorted ``fields`` (those the role sees), no float;
each record is listed once, at most `MAX_LIST_RECORDS` (``truncated`` when there were
more). The region logs every listed record in its access log (one row per record, the
field names) before the answer leaves; if it cannot, 503 ``access_log_unavailable`` and
no data.

A versioned resource (0.16.0) adds the record's ``version`` (an integer from 1, one more
on each applied write) to the answer; an answer without it reads as before.

Remote writes (0.16.0, interface I7, AD-3, AD-15): the admin site POSTs to the same route,
signed the same way, a `RemoteWriteRequest`::

    {"idempotency_key": "<uuid4, one per form>", "expected_version": 1,
     "object_id": "<the record's id, optional>", "changes": {"note": "..."}}

``object_id`` (optional) names the record the change is for (the last read's): the region
changes that record or answers 404 ``not_found``, never another one (a real resource has
many records; the staging sample is replaced by a reseed).

``changes`` names only fields of the resource's closed changes model
(`RESOURCE_WRITERS`: `SampleRecordChanges` for ``sample_record``; 0.34.0
`PendingTransferChanges` for ``pending_transfer``: ``{"state": "paid"}`` confirms the
transfer arrived, for the order's own total, ``{"state": "cancelled"}`` cancels the
order; the region turns either into its one service call) and only the role's
writable fields (`mytp_core.access.decide_write`; another field: 403 ``forbidden``).
The region logs the write before applying it, applies it once under a row lock when the
record is still at ``expected_version``, and answers 200 with the `RemoteRecord` (new
``version``, the fields the role sees). The same admin user's same key with the same body
gets the same answer again, applied once; with another body 422
``idempotency_key_reused``. A record no longer at ``expected_version``: 409
``stale_version`` with ``current_version`` (`StaleVersion`). Refusal codes and statuses:
`errors.REMOTE_WRITE_STATUS`.
"""
from typing import Annotated, Literal, Optional

from pydantic import Field, JsonValue, StrictInt, StringConstraints, model_validator

from .amounts import Amount
from .base import ContractModel, WriterModel
from .errors import REMOTE_WRITE_MESSAGES, STALE_VERSION, ErrorDetail, error_body
from .events import REGION_PATTERN, CanonicalUuid, UtcTime

NAME_PATTERN = r'^[a-z][a-z0-9_]{0,63}$'
Name = Annotated[str, StringConstraints(pattern=NAME_PATTERN)]
# A record's version (0.16.0): 1, 2, ... (a PostgreSQL bigint at the region).
MAX_VERSION = 2 ** 63 - 1
Version = Annotated[StrictInt, Field(ge=1, le=MAX_VERSION)]


class RemoteRecord(ContractModel):
    """One record of a remote read, with only the fields the role may see."""

    resource: Name
    region: str = Field(pattern=REGION_PATTERN)
    object_id: CanonicalUuid
    fields: list[Name] = Field(max_length=200)
    data: dict[str, JsonValue]
    # 0.16.0: the record's version, for a versioned resource (absent otherwise).
    version: Optional[Version] = None

    @model_validator(mode='after')
    def _fields_name_the_data(self):
        if self.fields != sorted(set(self.fields)):
            raise ValueError('fields are sorted and distinct')
        if set(self.fields) != set(self.data):
            raise ValueError('fields name exactly the keys of data')
        if _has_float(self.data):
            raise ValueError('no float in data: amounts are Amount strings')
        return self


def _has_float(value):
    stack = [value]
    while stack:
        item = stack.pop()
        if isinstance(item, float):
            return True
        if isinstance(item, dict):
            stack.extend(item.values())
        elif isinstance(item, list):
            stack.extend(item)
    return False


def remote_record(resource, region, object_id, data, version=None):
    """The JSON-ready answer for one record: `data` (a dict already reduced to the fields
    the role sees, `mytp_core.access.visible`) with its sorted field names, and (0.16.0)
    the record's `version` when the resource has one (left out when None)."""
    record = RemoteRecord(resource=resource, region=region, object_id=object_id,
                          fields=sorted(data), data=data, version=version)
    return record.model_dump(mode='json', exclude={'version'} if version is None else None)


class SampleRecordData(ContractModel):
    """``data`` of the staging-only ``sample_record`` (every field optional: a role sees
    some of them)."""

    uuid: Optional[CanonicalUuid] = None
    patient_name: Optional[str] = Field(default=None, max_length=150)
    amount: Optional[Amount] = None
    assignee_uuid: Optional[CanonicalUuid] = None
    note: Optional[str] = Field(default=None, max_length=500)


class PendingTransferData(ContractModel):
    """``data`` of a ``pending_transfer`` (0.34.0): a bank transfer order still waiting
    for its money. The doctor is named by the client record's ``client_uid`` only (the
    admin site has the name); no patient data. ``last_reminder_at`` is null until the
    first reminder went. Every field optional: a role sees some of them."""

    reference: Optional[str] = Field(default=None, max_length=20)
    client_uid: Optional[CanonicalUuid] = None
    company_code: Optional[str] = Field(default=None, max_length=20)
    total: Optional[Amount] = None
    pending_at: Optional[UtcTime] = None
    last_reminder_at: Optional[UtcTime] = None
    state: Optional[str] = Field(default=None, max_length=16)


RESOURCE_READERS = {'sample_record': SampleRecordData,
                    'pending_transfer': PendingTransferData}


# --- Remote lists (0.34.0) --------------------------------------------------------------

# The most records one list answer carries; a region with more sends the first ones (its
# own order) and ``truncated``.
MAX_LIST_RECORDS = 500


class RemoteListItem(ContractModel):
    """One record of a `RemoteList`: its id, its version (a versioned resource) and
    ``data`` with exactly the list's ``fields``."""

    object_id: CanonicalUuid
    version: Optional[Version] = None
    data: dict[str, JsonValue]


class RemoteList(ContractModel):
    """The answer to a remote list read (0.34.0): the records of a resource the region
    holds, each with only the fields the role may see (``fields``, sorted: every
    record's ``data`` has exactly these keys). The region logs every listed record in its
    access log before the answer leaves. ``truncated``: there were more than
    `MAX_LIST_RECORDS`."""

    resource: Name
    region: str = Field(pattern=REGION_PATTERN)
    fields: list[Name] = Field(max_length=200)
    records: list[RemoteListItem] = Field(max_length=MAX_LIST_RECORDS)
    truncated: bool = False

    @model_validator(mode='after')
    def _records_have_the_fields(self):
        if self.fields != sorted(set(self.fields)):
            raise ValueError('fields are sorted and distinct')
        names = set(self.fields)
        ids = set()
        for record in self.records:
            if set(record.data) != names:
                raise ValueError('each record\'s data has exactly the fields')
            if record.object_id in ids:
                raise ValueError('each record is listed once')
            ids.add(record.object_id)
        if _has_float([record.data for record in self.records]):
            raise ValueError('no float in data: amounts are Amount strings')
        return self


def remote_list(resource, region, fields, records, truncated=False):
    """The JSON-ready answer of a list read: `fields` the names the role sees, `records`
    an iterable of ``(object_id, data, version)`` with `data` already reduced to those
    fields (`mytp_core.access.visible`) and `version` None for a resource without one
    (then left out)."""
    items = [RemoteListItem(object_id=object_id, data=data, version=version)
             for object_id, data, version in records]
    answer = RemoteList(resource=resource, region=region, fields=sorted(fields),
                        records=items, truncated=truncated)
    body = answer.model_dump(mode='json')
    for item in body['records']:
        if item['version'] is None:
            del item['version']
    return body


# --- Remote writes (0.16.0) -------------------------------------------------------------

MAX_CHANGES = 50


class RemoteWriteRequest(WriterModel):
    """The body of a remote write (closed: any other key is refused). `changes` maps
    field names to their new values; the resource's changes model checks them
    (`changes_for`)."""

    idempotency_key: CanonicalUuid = Field(
        description='A UUID the admin site makes once per form; a retry sends it again.')
    expected_version: Version = Field(
        description='The version the change is based on (the last read).')
    object_id: Optional[CanonicalUuid] = Field(
        default=None, description='The record the change is for (the last read\'s).')
    changes: dict[Name, JsonValue] = Field(min_length=1, max_length=MAX_CHANGES)


def remote_write_request(idempotency_key, expected_version, changes, object_id=None):
    """The JSON-ready body of a remote write (ValidationError when malformed);
    ``object_id`` is left out when None."""
    request = RemoteWriteRequest(idempotency_key=idempotency_key,
                                 expected_version=expected_version, object_id=object_id,
                                 changes=changes)
    return request.model_dump(mode='json',
                              exclude={'object_id'} if object_id is None else None)


class SampleRecordChanges(WriterModel):
    """``changes`` of the staging-only ``sample_record`` (decision 2026-11-09: the note
    only). Closed: a field it does not name is refused."""

    note: str = Field(default='', max_length=500)


TRANSFER_PAID = 'paid'
TRANSFER_CANCELLED = 'cancelled'


class PendingTransferChanges(WriterModel):
    """``changes`` of a ``pending_transfer`` (0.34.0): ``state`` ``paid`` (the transfer
    arrived: the region marks the order paid with the order's own total) or ``cancelled``
    (the region cancels the order). Closed: nothing else."""

    state: Literal['paid', 'cancelled']


RESOURCE_WRITERS = {'sample_record': SampleRecordChanges,
                    'pending_transfer': PendingTransferChanges}


def changes_for(resource, changes):
    """`changes` checked against the resource's closed changes model: a dict of exactly the
    names given, JSON-ready. KeyError for a resource without one; ValidationError for an
    unknown field or a bad value (its text may quote the value: never log it)."""
    model = RESOURCE_WRITERS[resource]
    checked = model.model_validate(changes)
    return checked.model_dump(mode='json', include=set(changes))


class StaleVersion(ContractModel):
    """The body of a 409 ``stale_version``: the error and the record's current
    version."""

    error: ErrorDetail
    current_version: Version


def stale_version_body(current_version):
    """The JSON-ready 409 body: the ``stale_version`` error with the record's
    `current_version` (the only way to build it: `errors.remote_write_error` refuses
    this code)."""
    body = error_body(STALE_VERSION, REMOTE_WRITE_MESSAGES[STALE_VERSION])
    return StaleVersion(error=body['error'],
                        current_version=current_version).model_dump(mode='json')

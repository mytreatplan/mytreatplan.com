"""The error body every interface answer uses (0.7.0, architecture conventions "Errors"):
``{"error": {"code": "<snake_case>", "message": "<text>"}}`` with the HTTP status. No
stack trace or detail beyond the message crosses sites."""
import re

from pydantic import Field

from .base import ContractModel

CODE_PATTERN = r'^[a-z][a-z0-9_]{0,63}$'
CODE_RE = re.compile(CODE_PATTERN)

# The 401 refusals of a signed request (0.6.0, mytp_core.interface.REASONS).
MISSING = 'missing'
SIGNATURE = 'signature'
UNKNOWN_KEY = 'unknown_key'
AUDIENCE = 'audience'
EXPIRED = 'expired'
REQUEST_HASH = 'request_hash'
REPLAYED = 'replayed'
REFUSAL_CODES = (MISSING, SIGNATURE, UNKNOWN_KEY, AUDIENCE, EXPIRED, REQUEST_HASH, REPLAYED)

# The 503 of a site whose interface is not configured (no signing key, bad settings).
UNAVAILABLE = 'unavailable'

# The refusals of a remote read (0.13.0, mytp_core.access, contracts.remote), apart from
# the 401s above: the token is good but the region does not give this admin user the
# record (403), the record is not there (404), or the region could not write its access
# log, so no data leaves (503). Status by code: REMOTE_READ_STATUS.
FORBIDDEN = 'forbidden'
NOT_FOUND = 'not_found'
ACCESS_LOG_UNAVAILABLE = 'access_log_unavailable'
REMOTE_READ_STATUS = {FORBIDDEN: 403, NOT_FOUND: 404, ACCESS_LOG_UNAVAILABLE: 503}
REMOTE_READ_MESSAGES = {
    FORBIDDEN: 'This region does not give you this record.',
    NOT_FOUND: 'No such record in this region.',
    ACCESS_LOG_UNAVAILABLE: 'The access could not be logged, so no data was returned.',
}


def remote_read_error(code):
    """(JSON-ready error body, HTTP status) of a remote read refusal code."""
    return error_body(code, REMOTE_READ_MESSAGES[code]), REMOTE_READ_STATUS[code]


# The refusals of a remote write (0.16.0, interface I7, contracts.remote): the remote read
# codes (403 ``forbidden`` also for a field outside the role's writable fields, 404, 503:
# nothing applied), plus the body is not a write request of the resource (400), the
# record is no longer at the expected version (409, the body carries the current version:
# `contracts.remote.StaleVersion`), and the idempotency key was used before by the same
# admin user with another body (422). Status by code: REMOTE_WRITE_STATUS.
INVALID_BODY = 'invalid_body'
STALE_VERSION = 'stale_version'
IDEMPOTENCY_KEY_REUSED = 'idempotency_key_reused'
REMOTE_WRITE_STATUS = {FORBIDDEN: 403, NOT_FOUND: 404, ACCESS_LOG_UNAVAILABLE: 503,
                       INVALID_BODY: 400, STALE_VERSION: 409, IDEMPOTENCY_KEY_REUSED: 422}
REMOTE_WRITE_MESSAGES = {
    FORBIDDEN: 'This region does not let you change this record or one of these fields.',
    NOT_FOUND: 'No such record in this region.',
    ACCESS_LOG_UNAVAILABLE: 'The access could not be logged, so nothing was changed.',
    INVALID_BODY: 'The body is not a write request for this record.',
    STALE_VERSION: 'The record was changed meanwhile; read it again.',
    IDEMPOTENCY_KEY_REUSED: 'This idempotency key was used for another request.',
}


def remote_write_error(code):
    """(JSON-ready error body, HTTP status) of a remote write refusal code (0.16.0).
    ValueError for ``stale_version``: its 409 always carries the current version, so it
    is built by `contracts.remote.stale_version_body` only."""
    if code == STALE_VERSION:
        raise ValueError('a stale_version answer carries the current version: use '
                         'contracts.remote.stale_version_body')
    return error_body(code, REMOTE_WRITE_MESSAGES[code]), REMOTE_WRITE_STATUS[code]


class ErrorDetail(ContractModel):
    code: str = Field(pattern=CODE_PATTERN, description='A short snake_case code.')
    message: str = Field(max_length=500, description='A short text, safe to show.')


class ErrorBody(ContractModel):
    error: ErrorDetail


def error_body(code, message):
    """The JSON-ready error body (a dict); ValidationError for a malformed code."""
    return ErrorBody(error=ErrorDetail(code=code, message=message)).model_dump(mode='json')

"""The catalogue section of the configuration snapshot (0.12.0, architecture AD-3, AD-6,
AD-16, AD-22; epic-catalogue entry 2): the products, country groups and subscriptions the
admin site's Commercial Manager defines, which every regional portal prices from.

    {"country_groups": [{"id": "<uuid>", "name": "Iberia", "countries": ["ES", "PT"],
                         "catch_all": false, "active": true}],
     "products": [{"id": "<uuid>", "name": "TPS", "category": "tps",
                   "net_price": {"amount": "100.00", "currency": "EUR"}, "active": true}],
     "subscriptions": [{"id": "<uuid>", "tier": "basic", "country_group": "<uuid>",
                        "tps_discount_percent": "10.00", "active": true}]}

- Every row is listed, inactive ones too (``active: false``); ids are UUID strings, each
  once per list.
- A country group lists ISO 3166-1 alpha-2 codes (uppercase), each once; ``catch_all``
  marks the group of every country in no other active group ("Rest of world"). Among the
  active groups a country is in at most one, and at most one is the catch-all.
- A product's ``category`` and a subscription's ``tier`` are lowercase codes (``tps`` /
  ``other``; ``basic`` / ``advanced`` / ``premium``), not a closed list: a later release
  adds codes, and a reader skips what it does not know.
- ``net_price`` is a net amount (the `Amount` contract; VAT is added at checkout), never
  negative. The admin site writes only the currencies of `mytp_core.money.CURRENCIES`
  (EUR, AED, USD); the contract takes any ISO 4217 form, and a reader skips a product in a
  currency it does not know (a later release may add one). ``tps_discount_percent`` is a
  decimal string with exactly 2 places from ``"0.00"`` to ``"100.00"``.
- A subscription's ``country_group`` is the id of a listed group; at most one active
  subscription per (tier, country group).

The rules across rows (a subscription's group is listed; at most one active subscription
per tier and group; a country in at most one active group; at most one active catch-all)
are part of the reader contract: a snapshot that breaks one is refused whole
(`invalid_body`), and the reader keeps its last good snapshot, which is the safe failure.
Relaxing any of them is a breaking change: it needs a `min_reader` bump, so readers that
still enforce it keep their snapshot instead of refusing every new one.

The section is optional in the snapshot (`ConfigSnapshot.catalogue`): an admin site older
than 0.12.0 sends none, and a portal then holds an empty catalogue.
"""
from decimal import Decimal
from typing import Annotated

from pydantic import (BeforeValidator, Field, PlainSerializer, StrictBool,
                      StringConstraints, WithJsonSchema, model_validator)

from .amounts import Amount, _decimal_amount
from .base import ContractModel
from .events import CanonicalUuid

Name = Annotated[str, StringConstraints(min_length=1, max_length=150)]
# A choice code: lowercase letters, digits and "_", starting with a letter.
Code = Annotated[str, StringConstraints(min_length=1, max_length=32,
                                        pattern=r'^[a-z][a-z0-9_]*$')]
CountryCode = Annotated[str, StringConstraints(pattern=r'^[A-Z]{2}$')]

PERCENT_PATTERN = r'^(100\.00|[1-9]?[0-9]\.[0-9]{2})$'
HUNDRED = Decimal('100')


def _decimal_percent(value):
    try:
        value = _decimal_amount(value)
    except ValueError:
        raise ValueError('a percentage is a decimal string with exactly 2 places, '
                         'e.g. "10.00"') from None
    if not Decimal(0) <= value <= HUNDRED:
        raise ValueError('a percentage is from "0.00" to "100.00"')
    return value


Percent = Annotated[
    Decimal,
    BeforeValidator(_decimal_percent),
    PlainSerializer(lambda value: format(value, 'f'), return_type=str, when_used='json'),
    WithJsonSchema({'type': 'string', 'pattern': PERCENT_PATTERN,
                    'description': 'A percentage with exactly 2 places, "0.00" to "100.00".'}),
]


class CatalogueCountryGroup(ContractModel):
    """A group of countries a subscription applies to."""

    id: CanonicalUuid
    name: Name
    countries: list[CountryCode]
    catch_all: StrictBool = Field(
        description='The group of every country in no other active group.')
    active: StrictBool

    @model_validator(mode='after')
    def _unique_countries(self):
        if len(self.countries) != len(set(self.countries)):
            raise ValueError('a country group lists a country twice')
        return self


class CatalogueProduct(ContractModel):
    """A product, at its net price."""

    id: CanonicalUuid
    name: Name
    category: Code
    net_price: Amount
    active: StrictBool

    @model_validator(mode='after')
    def _not_negative(self):
        if self.net_price.amount < 0:
            raise ValueError('a net price is never negative')
        return self


class CatalogueSubscription(ContractModel):
    """A subscription tier in one country group, with its discount on plain TPS."""

    id: CanonicalUuid
    tier: Code
    country_group: CanonicalUuid
    tps_discount_percent: Percent
    active: StrictBool


def _unique(rows, label):
    ids = [row.id for row in rows]
    if len(ids) != len(set(ids)):
        raise ValueError(f'{label} lists an id twice')


class CatalogueSection(ContractModel):
    """The snapshot's ``catalogue``: see the module docstring."""

    country_groups: list[CatalogueCountryGroup]
    products: list[CatalogueProduct]
    subscriptions: list[CatalogueSubscription]

    @model_validator(mode='after')
    def _consistent(self):
        _unique(self.country_groups, 'country_groups')
        _unique(self.products, 'products')
        _unique(self.subscriptions, 'subscriptions')
        active_groups = [group for group in self.country_groups if group.active]
        seen = set()
        for group in active_groups:
            if seen & set(group.countries):
                raise ValueError('a country is in two active country groups')
            seen |= set(group.countries)
        if sum(1 for group in active_groups if group.catch_all) > 1:
            raise ValueError('two active country groups are the catch-all')
        groups = {group.id for group in self.country_groups}
        pairs = set()
        for subscription in self.subscriptions:
            if subscription.country_group not in groups:
                raise ValueError('a subscription names a country group not listed')
            if subscription.active:
                pair = (subscription.tier, subscription.country_group)
                if pair in pairs:
                    raise ValueError('two active subscriptions of one tier and country group')
                pairs.add(pair)
        return self

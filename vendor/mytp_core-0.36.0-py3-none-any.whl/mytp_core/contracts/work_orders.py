"""The work-order events (0.35.0, architecture AD-2, AD-21, AD-23; epic-ordering 9.8): a
regional portal tells the admin site where each work order stands, so the admin site can
keep its workload figures. No patient data travels: no name, no patient code.

- ``work_order.created`` (`WorkOrderCreated`): a work order was created (``aggregate_version``
  1), e.g. in ``pending_assignment`` for a paid order line or in ``pending_payment`` for a
  line of an order waiting for a bank transfer.
- ``work_order.stage_changed`` (`WorkOrderStageChanged`): it moved to another stage
  (``aggregate_version`` = the work order's version after the move).

The payload (the same fields for both)::

    {"work_order_id": "<uuid>", "stage": "pending_assignment",
     "product_category": "tps_branded", "at": "2026-11-25T10:00:00Z"}

``stage`` is a stage of `mytp_core.stages` (a writer may send only those; a reader takes
any lowercase code, so a later stage still reads). ``product_category`` is the catalogue
category code of the work order's product, or ``''`` when it is not known (a work order
without an order line). ``at`` is when the stage was reached. Aggregate kind
``work_order``: ``aggregate_id`` is the ``work_order_id``, so each work order's versions
rise on their own and a replay of an older version is ``stale``; the admin site keeps the
latest stage.

Writers build with `build_payload` (the closed `WorkOrderCreated` /
`WorkOrderStageChanged`); readers validate with `WorkOrderCreatedReader` /
`WorkOrderStageChangedReader` (the same fields, unknown fields dropped).
"""
from typing import Annotated, Literal

from pydantic import StringConstraints

from ..stages import STAGES
from .base import ContractModel, WriterModel
from .events import CanonicalUuid, UtcTime

WORK_ORDER_CREATED = 'work_order.created'
WORK_ORDER_STAGE_CHANGED = 'work_order.stage_changed'

# What a writer may send: a stage of the stage machine.
WriterStage = Literal[STAGES]
# What a reader takes: any stage code (a later release may add stages, AD-12).
StageCode = Annotated[str, StringConstraints(min_length=1, max_length=32,
                                             pattern=r'^[a-z][a-z0-9_]*$')]
# A catalogue product category code, or '' when it is not known.
ProductCategory = Annotated[str, StringConstraints(max_length=32,
                                                   pattern=r'^([a-z][a-z0-9_]*)?$')]


class WorkOrderCreatedReader(ContractModel):
    """A created work order, as the admin site reads it (unknown fields dropped)."""

    work_order_id: CanonicalUuid
    stage: StageCode
    product_category: ProductCategory
    at: UtcTime


class WorkOrderStageChangedReader(ContractModel):
    """A work order's new stage, as the admin site reads it (unknown fields dropped)."""

    work_order_id: CanonicalUuid
    stage: StageCode
    product_category: ProductCategory
    at: UtcTime


class WorkOrderCreated(WriterModel):
    """The payload of ``work_order.created`` a portal writes (closed: an unknown field,
    such as a patient's code or name, is refused)."""

    work_order_id: CanonicalUuid
    stage: WriterStage
    product_category: ProductCategory
    at: UtcTime


class WorkOrderStageChanged(WriterModel):
    """The payload of ``work_order.stage_changed`` a portal writes (closed)."""

    work_order_id: CanonicalUuid
    stage: WriterStage
    product_category: ProductCategory
    at: UtcTime


# The reader model of each work-order event type.
WORK_ORDER_READERS = {WORK_ORDER_CREATED: WorkOrderCreatedReader,
                      WORK_ORDER_STAGE_CHANGED: WorkOrderStageChangedReader}

"""The case stage machine (0.33.0, AD-21): the stages of a work order, the allowed moves
and the check both sites share. The portal's `patients.service` enforces it; nothing here
touches a database.

Stages, in order: `pending_payment` (not live; a case ordered and not yet paid),
`pending_assignment`, `assigned`, `pending_registers_upload`, `processing_prescription`,
`prescription_done` (these three are optional and may be skipped), `pending_appointment`,
`in_development`, `pending_review`, `pending_approval` and the final `approved` and
`cancelled`, and (0.35.0) the final `closed`: a live ICE work order whose patient's
planning (TPS or VirtuaOrtho) was paid. `closed` is not a cancellation and not a finished
treatment.

Allowed moves (drafted for clinical ops to confirm):
- forward, one step at a time, skipping any optional stages in the way;
- from `pending_review` or `pending_approval` back to `in_development` (changes requested);
- to `cancelled` from any stage that is not final;
- to `closed` from any live stage (0.35.0); `closed` goes nowhere.
"""

PENDING_PAYMENT = 'pending_payment'
PENDING_ASSIGNMENT = 'pending_assignment'
ASSIGNED = 'assigned'
PENDING_REGISTERS_UPLOAD = 'pending_registers_upload'
PROCESSING_PRESCRIPTION = 'processing_prescription'
PRESCRIPTION_DONE = 'prescription_done'
PENDING_APPOINTMENT = 'pending_appointment'
IN_DEVELOPMENT = 'in_development'
PENDING_REVIEW = 'pending_review'
PENDING_APPROVAL = 'pending_approval'
APPROVED = 'approved'
CANCELLED = 'cancelled'
CLOSED = 'closed'

#: The stages in lifecycle order (`cancelled` and `closed` last: they are reached from
#: anywhere, `closed` from any live stage).
STAGES = (PENDING_PAYMENT, PENDING_ASSIGNMENT, ASSIGNED, PENDING_REGISTERS_UPLOAD,
          PROCESSING_PRESCRIPTION, PRESCRIPTION_DONE, PENDING_APPOINTMENT, IN_DEVELOPMENT,
          PENDING_REVIEW, PENDING_APPROVAL, APPROVED, CANCELLED, CLOSED)
OPTIONAL_STAGES = frozenset({PENDING_REGISTERS_UPLOAD, PROCESSING_PRESCRIPTION,
                             PRESCRIPTION_DONE})
FINAL_STAGES = frozenset({APPROVED, CANCELLED, CLOSED})
#: A patient has at most one work order in a live stage.
LIVE_STAGES = frozenset(STAGES) - FINAL_STAGES - {PENDING_PAYMENT}

_FORWARD = STAGES[:STAGES.index(APPROVED) + 1]


def _allowed():
    table = {}
    for index, stage in enumerate(_FORWARD):
        moves = set()
        for later in _FORWARD[index + 1:]:
            moves.add(later)
            if later not in OPTIONAL_STAGES:
                break
        if stage not in FINAL_STAGES:
            moves.add(CANCELLED)
        table[stage] = moves
    table[PENDING_REVIEW].add(IN_DEVELOPMENT)
    table[PENDING_APPROVAL].add(IN_DEVELOPMENT)
    for stage in LIVE_STAGES:
        table[stage].add(CLOSED)
    table[CANCELLED] = set()
    table[CLOSED] = set()
    return {stage: frozenset(moves) for stage, moves in table.items()}


#: from stage -> the set of stages it may move to.
ALLOWED = _allowed()


class InvalidStageTransition(ValueError):
    """A work order was to move between two stages the table does not allow."""


def check_transition(from_stage, to_stage):
    """Raise `InvalidStageTransition` unless `from_stage` -> `to_stage` is allowed (an
    unknown stage is refused too)."""
    if from_stage not in ALLOWED or to_stage not in ALLOWED:
        raise InvalidStageTransition(
            f'unknown stage in {from_stage!r} -> {to_stage!r}')
    if to_stage not in ALLOWED[from_stage]:
        raise InvalidStageTransition(f'a case cannot move from {from_stage} to {to_stage}')

"""The named case moves (0.36.0, AD-21): each way a work order changes stage on purpose,
with the actor allowed to make it. Built on `stages.ALLOWED`; every pair of every move
passes `stages.check_transition` (checked at import). The portal's
`patients.service.apply_move` enforces it; nothing here touches a database.

Staff moves (`STAFF_MOVES`, an admin user): `assign` (needs an assignee),
`request_records`, `prescription_done`, `request_appointment`, `start_development`,
`send_for_review`, `send_for_approval`, `request_changes`. Doctor moves (`DOCTOR_MOVES`):
`records_complete` and `approve`. Cancelling and closing are not named moves.
"""
from typing import NamedTuple

from . import stages

STAFF = 'staff'
DOCTOR = 'doctor'
ACTORS = (STAFF, DOCTOR)


class MoveNotAllowed(ValueError):
    """A move that does not exist, or one the stage or the actor does not allow."""


class Move(NamedTuple):
    name: str
    from_stages: frozenset
    to_stage: str
    actor: str


def _move(name, from_stages, to_stage, actor):
    return Move(name, frozenset(from_stages), to_stage, actor)


_MOVES = (
    _move('assign', [stages.PENDING_ASSIGNMENT], stages.ASSIGNED, STAFF),
    _move('request_records', [stages.ASSIGNED], stages.PENDING_REGISTERS_UPLOAD, STAFF),
    _move('records_complete', [stages.PENDING_REGISTERS_UPLOAD],
          stages.PROCESSING_PRESCRIPTION, DOCTOR),
    _move('prescription_done', [stages.PROCESSING_PRESCRIPTION],
          stages.PRESCRIPTION_DONE, STAFF),
    _move('request_appointment', [stages.ASSIGNED, stages.PRESCRIPTION_DONE],
          stages.PENDING_APPOINTMENT, STAFF),
    _move('start_development', [stages.PENDING_APPOINTMENT], stages.IN_DEVELOPMENT, STAFF),
    _move('send_for_review', [stages.IN_DEVELOPMENT], stages.PENDING_REVIEW, STAFF),
    _move('send_for_approval', [stages.PENDING_REVIEW], stages.PENDING_APPROVAL, STAFF),
    _move('request_changes', [stages.PENDING_REVIEW, stages.PENDING_APPROVAL],
          stages.IN_DEVELOPMENT, STAFF),
    _move('approve', [stages.PENDING_APPROVAL], stages.APPROVED, DOCTOR),
)

MOVES = {move.name: move for move in _MOVES}
STAFF_MOVES = tuple(move.name for move in _MOVES if move.actor == STAFF)
DOCTOR_MOVES = tuple(move.name for move in _MOVES if move.actor == DOCTOR)

for _m in _MOVES:
    for _from in _m.from_stages:
        stages.check_transition(_from, _m.to_stage)
del _m, _from


def check_move(name, from_stage, actor_type):
    """The stage `name` leads to from `from_stage` for an actor of `actor_type`
    (`STAFF` or `DOCTOR`); `MoveNotAllowed` for an unknown move, a stage it does not
    start from, or another kind of actor."""
    move = MOVES.get(name)
    if move is None:
        raise MoveNotAllowed(f'unknown move {name!r}')
    if actor_type != move.actor:
        raise MoveNotAllowed(f'{name} is a {move.actor} move')
    if from_stage not in move.from_stages:
        raise MoveNotAllowed(f'{name} cannot start from {from_stage}')
    return move.to_stage

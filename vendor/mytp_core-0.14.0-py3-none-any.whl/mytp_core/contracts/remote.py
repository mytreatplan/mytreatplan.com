"""The answer to a remote read (0.13.0, architecture AD-4, AD-17, AD-23, interface I6): the
admin site reads one record of a regional portal live, and keeps nothing of it.

A portal serves each resource at its own route (the staging sample record:
``GET /api/v1/remote/sample-record``), signed by the admin site with the admin user's
access as extra claims (`mytp_core.interface.remote_actor`), answers 200 with
`RemoteRecord`, sent with ``Cache-Control: no-store``::

    {"resource": "sample_record", "region": "eu",
     "object_id": "1b4e28ba-2fa1-4d3b-a3f5-ef19b5a7633b",
     "fields": ["assignee_uuid", "note", "patient_name", "uuid"],
     "data": {"uuid": "1b4e28ba-...", "patient_name": "...", "assignee_uuid": null,
              "note": "..."}}

``fields`` lists, sorted, the names of the fields the region sent (its access log lists
the same names); ``data`` holds exactly those, and no float (amounts are `Amount`). A
field the role may not see (`mytp_core.access`) is absent, never null. Refusals use the
error body
(`errors.remote_read_error`): 403 ``forbidden``, 404 ``not_found``, 503
``access_log_unavailable``; the signature refusals stay 401.

Each resource's ``data`` has its reader model (`RESOURCE_READERS`): `SampleRecordData`
for ``sample_record`` (staging only; removed with it).
"""
from typing import Annotated, Optional

from pydantic import Field, JsonValue, StringConstraints, model_validator

from .amounts import Amount
from .base import ContractModel
from .events import REGION_PATTERN, CanonicalUuid

NAME_PATTERN = r'^[a-z][a-z0-9_]{0,63}$'
Name = Annotated[str, StringConstraints(pattern=NAME_PATTERN)]


class RemoteRecord(ContractModel):
    """One record of a remote read, with only the fields the role may see."""

    resource: Name
    region: str = Field(pattern=REGION_PATTERN)
    object_id: CanonicalUuid
    fields: list[Name] = Field(max_length=200)
    data: dict[str, JsonValue]

    @model_validator(mode='after')
    def _fields_name_the_data(self):
        if self.fields != sorted(set(self.fields)):
            raise ValueError('fields are sorted and distinct')
        if set(self.fields) != set(self.data):
            raise ValueError('fields name exactly the keys of data')
        if _has_float(self.data):
            raise ValueError('no float in data: amounts are Amount strings')
        return self


def _has_float(value):
    stack = [value]
    while stack:
        item = stack.pop()
        if isinstance(item, float):
            return True
        if isinstance(item, dict):
            stack.extend(item.values())
        elif isinstance(item, list):
            stack.extend(item)
    return False


def remote_record(resource, region, object_id, data):
    """The JSON-ready answer for one record: `data` (a dict already reduced to the fields
    the role sees, `mytp_core.access.visible`) with its sorted field names."""
    return RemoteRecord(resource=resource, region=region, object_id=object_id,
                        fields=sorted(data), data=data).model_dump(mode='json')


class SampleRecordData(ContractModel):
    """``data`` of the staging-only ``sample_record`` (every field optional: a role sees
    some of them)."""

    uuid: Optional[CanonicalUuid] = None
    patient_name: Optional[str] = Field(default=None, max_length=150)
    amount: Optional[Amount] = None
    assignee_uuid: Optional[CanonicalUuid] = None
    note: Optional[str] = Field(default=None, max_length=500)


RESOURCE_READERS = {'sample_record': SampleRecordData}

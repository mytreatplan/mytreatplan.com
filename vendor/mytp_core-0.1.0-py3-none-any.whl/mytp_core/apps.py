from django.apps import AppConfig
from django.core import checks


class MytpCoreConfig(AppConfig):
    name = 'mytp_core'
    verbose_name = 'MyTreatPlan core'

    def ready(self):
        from .crypto import check_field_keys

        # Missing or malformed field keys stop `check`, `runserver` and `migrate`
        # (mytp_core.E001, mytp_core.E002).
        checks.register(check_field_keys, checks.Tags.security)

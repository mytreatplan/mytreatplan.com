"""Code shared by the MyTreatPlan sites (portal, admin site): field encryption, the blind
index, the OVHcloud KMS client and their management commands (architecture AD-10).

Add ``'mytp_core'`` to INSTALLED_APPS: that registers the field key system checks
(mytp_core.E001, mytp_core.E002) and the commands ``generate_field_keys``,
``generate_kms_field_key`` and ``kmscheck``.
"""
__version__ = '0.1.0'

"""Print a new KMS-wrapped interface signing key and its public key (0.6.0, AD-4).

    python manage.py generate_interface_signing_key <kid>
    python manage.py generate_interface_signing_key --public   # the configured key's public key

Asks the OVHcloud KMS for a new 256-bit data key wrapped by the service key
KMS_SERVICE_KEY_ID: its 32 bytes are the Ed25519 seed of the site's signing key
(mytp_core.interface). The plain seed is used only to derive the public key and is then
discarded: it is never printed, logged or stored. Prints two lines:

    INTERFACE_SIGNING_KMS_KEY=<kid>:<wrapped key>     # for this site's settings.env
    INTERFACE_PUBLIC_KEY=<SITE>:<kid>:<public key>     # for the peers

The public key is not secret: it goes to the other sites (a portal's INTERFACE_PEER_KEYS,
the admin site's `add_peer_key`). With --public, prints only the second line, for the
signing key already configured (INTERFACE_SIGNING_KMS_KEY, unwrapped through the KMS, or
INTERFACE_SIGNING_KEY in local development).
"""
from django.conf import settings
from django.core.management.base import BaseCommand, CommandError

from mytp_core import interface, kms
from mytp_core.crypto import KeyConfigurationError, check_wrapped_key

DATA_KEY_BITS = interface.SEED_SIZE * 8


class Command(BaseCommand):
    help = ('Print a new INTERFACE_SIGNING_KMS_KEY value (<kid>:<wrapped key>, an Ed25519 '
            'seed wrapped by the KMS service key) and its public key; with --public, the '
            'public key of the configured signing key. The seed is never printed.')
    # Runs before the key is configured, so no system checks.
    requires_system_checks = []

    def add_arguments(self, parser):
        parser.add_argument('kid', nargs='?',
                            help='Id of the new key (letters, digits, "-" and "_", at most 32 '
                                 'characters), e.g. sig20261105.')
        parser.add_argument('--public', action='store_true',
                            help='Print the public key of the configured signing key instead.')

    def handle(self, *args, kid=None, public=False, **options):
        if public:
            if kid:
                raise CommandError('--public takes no key id.')
            try:
                key = interface.get_signing_key()
            except interface.InterfaceError as exc:
                raise CommandError(f'generate_interface_signing_key: {exc}') from None
            self.stdout.write(f'INTERFACE_PUBLIC_KEY={settings.SITE}:{key.kid}:{key.public_text}')
            return
        if not kid:
            raise CommandError('Give the new key id, e.g. '
                               '`manage.py generate_interface_signing_key sig20261105`.')
        try:
            interface.check_kid(kid)
        except interface.InterfaceConfigurationError as exc:
            raise CommandError(str(exc)) from None
        try:
            client = kms.KMSClient.from_settings(settings)
            wrapped, seed = client.generate_data_key(
                settings.KMS_SERVICE_KEY_ID.strip(), f'mytp-interface-{kid}', DATA_KEY_BITS)
        except kms.KMSError as exc:
            raise CommandError(f'generate_interface_signing_key: {exc}') from None
        size = len(seed)
        if size != interface.SEED_SIZE:
            del seed
            raise CommandError(f'generate_interface_signing_key: the KMS returned a {size}-byte '
                               f'key, not {interface.SEED_SIZE}.')
        public_text = interface.SigningKey(kid, seed).public_text
        del seed  # the plain seed is never kept
        try:
            wrapped = check_wrapped_key(wrapped, 'the KMS answer')
        except KeyConfigurationError:
            raise CommandError('generate_interface_signing_key: the wrapped key the KMS '
                               'returned cannot be stored in a setting (spaces or commas).'
                               ) from None
        self.stdout.write(f'{interface.KMS_SETTING}={kid}:{wrapped}')
        self.stdout.write(f'INTERFACE_PUBLIC_KEY={settings.SITE}:{kid}:{public_text}')

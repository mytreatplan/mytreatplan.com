"""Verification codes (0.4.0): the provider interface, the fake provider, `get_provider`
and the send orchestration `send_code`, shared by the portal (signup, resume and login
codes) and the admin site (its second factor).

A provider sends a code to a contact and later checks the code the person typed. The
code rules belong to the provider, as with Twilio Verify (mytp_core.twilio_verify): 6
digits, valid for 10 minutes, a send within that time repeats the same code, and 5 wrong
attempts invalidate it. No database ever holds a code. `get_provider()` returns the class
named by the setting VERIFICATION_PROVIDER: this module's fake (FAKE_PROVIDER;
development and tests) or Twilio Verify (staging and production).

A site's own limits and event log plug into `send_code` through a `SendHooks` object;
the default hooks have no limits and log nothing.

Seams a site may override in a subclass: `logger_name` (the logger a provider writes on;
the fake's line holds the code, so keep that logger out of Sentry), the fake's
`cache_prefix`, `_now()` (the fake's clock) and the Twilio provider's `_post_verify`.
"""
import hashlib
import hmac
import http.client
import logging
import secrets
import time
from collections import namedtuple

from django.conf import settings
from django.core.cache import cache
from django.utils import translation
from django.utils.crypto import constant_time_compare
from django.utils.module_loading import import_string

from .crypto import email_index, phone_index

# The dotted path of this module's fake, for VERIFICATION_PROVIDER.
FAKE_PROVIDER = 'mytp_core.verification.FakeVerificationProvider'

# Channels a code is sent over.
EMAIL = 'email'
WHATSAPP = 'whatsapp'
SMS = 'sms'
CHANNELS = (EMAIL, WHATSAPP, SMS)

# Kinds of contact: an email address, or a mobile number (E.164) reached over WhatsApp
# or SMS. A mobile has one code, whichever of its channels carried it.
MOBILE = 'mobile'
CONTACT_KINDS = {EMAIL: EMAIL, WHATSAPP: MOBILE, SMS: MOBILE}

# What a code is for; part of the fake's code derivation, so a code for one purpose fails
# another. Sites may use other purposes; these are the portal's.
PURPOSE_SIGNUP = 'signup'
PURPOSE_RESUME = 'resume'
PURPOSE_LOGIN = 'login'

CODE_LENGTH = 6
# How long a code is valid after it was first sent.
CODE_TTL_SECONDS = 600
# Wrong attempts that invalidate a code.
MAX_CHECK_ATTEMPTS = 5

# `check` results.
APPROVED = 'approved'
WRONG = 'wrong'
NO_CODE = 'no_code'  # no valid code: none sent, expired, invalidated or already used

# Fixed numbers the fake provider treats specially, so both paths can be exercised:
# WhatsApp cannot deliver to the first (the code goes by SMS); every send to the second
# fails. Both are valid Spanish mobiles.
FAKE_NO_WHATSAPP_NUMBER = '+34699000001'
FAKE_SEND_FAILS_NUMBER = '+34699000002'

# What a failed HTTP call can raise: URLError and HTTPError (4xx/5xx) are OSErrors, as are
# timeouts and resets; a broken response is an HTTPException; a bad body a ValueError.
FETCH_ERRORS = (OSError, http.client.HTTPException, ValueError)

DEFAULT_LOGGER_NAME = 'mytp_core.verification'


class VerificationError(Exception):
    """A code could not be sent or checked."""


class ChannelUnavailable(VerificationError):
    """The channel cannot deliver to this contact (e.g. the number has no WhatsApp)."""


class SendFailed(VerificationError):
    """The provider, or the network to it, failed."""


class CheckFailed(VerificationError):
    """A code could not be checked: the provider, or the network to it, failed (a network
    error, refused credentials, a 5xx). The code is neither right nor wrong; the person
    tries again. The fake provider never raises it."""


def contact_kind(channel):
    """EMAIL or MOBILE for a channel; ValueError for an unknown one."""
    try:
        return CONTACT_KINDS[channel]
    except KeyError:
        raise ValueError(f'Unknown verification channel: {channel!r}') from None


def contact_index(kind, contact):
    """The contact's blind index (mytp_core.crypto), so no plain contact is ever a key."""
    return email_index(contact) if kind == EMAIL else phone_index(contact)


def _now():
    return time.time()


class VerificationProvider:
    """Interface for verification-code providers."""

    # The logger the provider writes on (a site's subclass may name its own).
    logger_name = DEFAULT_LOGGER_NAME

    @property
    def logger(self):
        return logging.getLogger(self.logger_name)

    @classmethod
    def _now(cls):
        """The current time (seconds); a site's subclass may route it to its own clock."""
        return _now()

    def send(self, channel, contact, purpose, language):
        """Send a code to `contact` (an email address or a phone number) over `channel`,
        in `language`. Raises ChannelUnavailable when the channel cannot deliver to the
        contact, SendFailed when the provider or the network fails."""
        raise NotImplementedError

    def check(self, channel, contact, purpose, code):
        """APPROVED, WRONG or NO_CODE for `code` typed for this contact and purpose
        (`channel` gives the kind of contact: a mobile's code is the same over WhatsApp
        and SMS). An approved code is used up. Raises CheckFailed when the provider or
        the network fails."""
        raise NotImplementedError

    @staticmethod
    def _validate_channel(channel):
        contact_kind(channel)


class FakeVerificationProvider(VerificationProvider):
    """Development and test stand-in that emulates Twilio Verify's code rules.

    Per (kind of contact, contact's blind index, purpose) the cache (CACHES['default'])
    holds a random nonce, the time the code was first sent and the wrong attempts; the
    code is HMAC(SECRET_KEY, kind|index|purpose|nonce) reduced to 6 digits. Neither the
    code nor the plain contact is stored. The log line in `send` is the one place a code
    is ever written (keep `logger_name` out of Sentry).

    A send while the code is valid repeats it; a code is valid for CODE_TTL_SECONDS
    from its first send, until approved, or until MAX_CHECK_ATTEMPTS wrong attempts.
    FAKE_NO_WHATSAPP_NUMBER and FAKE_SEND_FAILS_NUMBER simulate the two send failures.
    """

    # The cache keys: <cache_prefix><kind>:<blind index>:<purpose>.
    cache_prefix = 'mytp-core:fake-otp:'

    def send(self, channel, contact, purpose, language):
        kind = contact_kind(channel)
        if kind == MOBILE and contact == FAKE_SEND_FAILS_NUMBER:
            raise SendFailed('fake provider: send fails for this test number')
        if channel == WHATSAPP and contact == FAKE_NO_WHATSAPP_NUMBER:
            raise ChannelUnavailable('fake provider: no WhatsApp for this test number')
        key = self._key(kind, contact, purpose)
        now = self._now()
        record = self._valid_record(key, now)
        if record is None:
            record = {'nonce': secrets.token_hex(16), 'sent_at': now, 'wrong': 0}
            self._store(key, record, now)
        code = self._code(kind, contact, purpose, record['nonce'])
        # The only place a code is ever written. Keep this logger out of Sentry.
        self.logger.info('Verification code for %s %s (%s, %s): %s',
                         channel, contact, purpose, language, code)

    def check(self, channel, contact, purpose, code):
        kind = contact_kind(channel)
        key = self._key(kind, contact, purpose)
        now = self._now()
        record = self._valid_record(key, now)
        if record is None:
            return NO_CODE
        code = (code or '').strip()
        expected = self._code(kind, contact, purpose, record['nonce'])
        if len(code) == CODE_LENGTH and code.isdigit() and constant_time_compare(code, expected):
            cache.delete(key)  # used up, as Twilio's approved verification
            return APPROVED
        record['wrong'] += 1
        if record['wrong'] >= MAX_CHECK_ATTEMPTS:
            cache.delete(key)
            return NO_CODE
        self._store(key, record, now)
        return WRONG

    @classmethod
    def current_code(cls, channel, contact, purpose):
        """The valid code for this contact and purpose, or None. For tests only."""
        kind = contact_kind(channel)
        record = cls._valid_record(cls._key(kind, contact, purpose), cls._now())
        return None if record is None else cls._code(kind, contact, purpose, record['nonce'])

    @classmethod
    def _key(cls, kind, contact, purpose):
        return f'{cls.cache_prefix}{kind}:{contact_index(kind, contact)}:{purpose}'

    @staticmethod
    def _valid_record(key, now):
        record = cache.get(key)
        if not isinstance(record, dict) or now - record['sent_at'] >= CODE_TTL_SECONDS:
            return None
        return record

    @staticmethod
    def _store(key, record, now):
        # The cache's own expiry is only housekeeping; validity is checked on `sent_at`.
        cache.set(key, record, timeout=max(1, int(record['sent_at'] + CODE_TTL_SECONDS - now) + 60))

    @staticmethod
    def _code(kind, contact, purpose, nonce):
        message = f'{kind}|{contact_index(kind, contact)}|{purpose}|{nonce}'.encode()
        digest = hmac.new(settings.SECRET_KEY.encode(), message, hashlib.sha256).digest()
        return f'{int.from_bytes(digest, "big") % 10 ** CODE_LENGTH:0{CODE_LENGTH}d}'


def get_provider():
    """An instance of the provider class named by settings.VERIFICATION_PROVIDER."""
    return import_string(settings.VERIFICATION_PROVIDER)()


# --- Sending a code within a site's limits ----------------------------------------------

# What `send_code` did: `status` (below), the `channel` the code went (or tried to go)
# over, whether WhatsApp could not deliver so it went by SMS (`fallback`), and for
# COOLDOWN and HOURLY the seconds until the next send is allowed.
SendOutcome = namedtuple('SendOutcome', 'status channel fallback wait_seconds')
SENT, COOLDOWN, HOURLY, FAILED = 'sent', 'cooldown', 'hourly', 'failed'
# Not sent: the site's per-IP (or other) reservation was refused (`SendHooks.reserve`).
BLOCKED = 'blocked'

# A site's per-contact limit check: `allowed`; else `wait_seconds` until the next send is
# allowed, and whether the hourly limit (not the cooldown) is the reason.
SendCheck = namedtuple('SendCheck', 'allowed wait_seconds hourly_blocked')

# The reservation the default hooks hand out (anything but None means "not blocked").
_NO_RESERVATION = object()


class SendHooks:
    """A site's limits and event log around `send_code`. The defaults have no limits and
    log nothing (no lock, every send allowed, nothing reserved or counted).

    `event(kind, **data)` is called with:
    - 'rejected' (status=COOLDOWN or HOURLY, wait_seconds, channel): a limit refused it;
    - 'ip_blocked' (channel): `reserve()` returned None;
    - 'send_failed' (channel, fallback, error): the provider failed (after the log line);
    - 'sent' (channel, fallback): the code went.
    A lock not got (`acquire_lock` False: another send to the contact is running) answers
    COOLDOWN with `lock_wait_seconds`, with no event.
    """

    # The wait a COOLDOWN answers with when the send lock is held.
    lock_wait_seconds = 0
    # The logger (name) of the "send failed" error line; None: the provider's logger.
    send_failed_logger = None
    # Its message, given channel, purpose and the error (never the contact).
    send_failed_message = 'Verification code send failed: channel=%s purpose=%s error=%s'

    def acquire_lock(self, contact, purpose):
        """Take the per-contact-and-purpose send lock; False if another send holds it."""
        return True

    def release_lock(self, contact, purpose):
        pass

    def check_send(self, contact, purpose):
        """A SendCheck: whether a code may be sent to `contact` for `purpose` now."""
        return SendCheck(True, 0, False)

    def reserve(self):
        """Reserve one send (e.g. a per-IP count); the reservation, or None if blocked."""
        return _NO_RESERVATION

    def refund(self, reservation):
        """Give back a reservation whose send did not go."""

    def record_send(self, contact, purpose):
        """Count a successful send."""

    def event(self, kind, **data):
        """Log what happened (see the class docstring)."""


def send_code(contact, purpose, channel, language=None, *, provider=None, hooks=None):
    """Send a code to `contact` for `purpose` over `channel` within the `hooks`' limits.

    A mobile goes by `channel` (WhatsApp, or SMS); if WhatsApp cannot deliver to the
    number the code goes by SMS at once (`fallback`). `language` defaults to the active
    one; `provider` to `get_provider()`; `hooks` to `SendHooks()` (no limits). Returns a
    SendOutcome: SENT; COOLDOWN (the lock is held, or the hooks' cooldown) or HOURLY,
    not sent; BLOCKED (`hooks.reserve()` refused), not sent; or FAILED (the provider
    raised a VerificationError: logged as an error with the channel, the purpose and the
    error only, and the reservation given back). ValueError for an unknown channel.
    """
    contact_kind(channel)
    hooks = SendHooks() if hooks is None else hooks
    if not hooks.acquire_lock(contact, purpose):
        # Another request is sending to this contact right now (e.g. a double click).
        return SendOutcome(COOLDOWN, channel, False, hooks.lock_wait_seconds)
    try:
        return _send_locked(contact, purpose, channel, language, provider, hooks)
    finally:
        hooks.release_lock(contact, purpose)


def _send_locked(contact, purpose, channel, language, provider, hooks):
    check = hooks.check_send(contact, purpose)
    if not check.allowed:
        status = HOURLY if check.hourly_blocked else COOLDOWN
        hooks.event('rejected', status=status, wait_seconds=check.wait_seconds,
                    channel=channel)
        return SendOutcome(status, channel, False, check.wait_seconds)
    # The send is counted first, and given back if it does not go.
    reservation = hooks.reserve()
    if reservation is None:
        hooks.event('ip_blocked', channel=channel)
        return SendOutcome(BLOCKED, channel, False, 0)
    sent = False
    try:
        outcome = _send(contact, purpose, channel, language, provider, hooks)
        sent = outcome.status == SENT
        return outcome
    finally:
        if not sent:
            hooks.refund(reservation)


def _send(contact, purpose, channel, language, provider, hooks):
    provider = get_provider() if provider is None else provider
    language = translation.get_language() if language is None else language
    fallback = False
    try:
        try:
            provider.send(channel, contact, purpose, language)
        except ChannelUnavailable:
            if channel != WHATSAPP:
                raise
            channel, fallback = SMS, True
            provider.send(channel, contact, purpose, language)
    except VerificationError as error:
        # No contact here. The error's message is safe to log (the providers put only
        # Twilio's error code and HTTP status in it).
        _send_failed_logger(provider, hooks).error(hooks.send_failed_message,
                                                   channel, purpose, error)
        hooks.event('send_failed', channel=channel, fallback=fallback, error=error)
        return SendOutcome(FAILED, channel, fallback, 0)
    hooks.record_send(contact, purpose)
    hooks.event('sent', channel=channel, fallback=fallback)
    return SendOutcome(SENT, channel, fallback, 0)


def _send_failed_logger(provider, hooks):
    if hooks.send_failed_logger:
        return logging.getLogger(hooks.send_failed_logger)
    return logging.getLogger(getattr(provider, 'logger_name', DEFAULT_LOGGER_NAME))

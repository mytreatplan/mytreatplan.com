"""Code shared by the MyTreatPlan sites (portal, admin site): field encryption, the blind
index, the OVHcloud KMS client, the operations code (Sentry with its scrubber,
scheduled jobs with Sentry cron monitors, the /healthz view, database backups), the
background task helpers (enqueue after commit, idempotent effects, the worker
heartbeat) and the verification codes (the provider interface, the fake and
Twilio Verify providers, `send_code` with a site's hooks; 0.4.0) and the sign-in rules
(remembered devices, the failure lockout, one session per account, each with a site's
policy; 0.5.0) and the signed calls between the sites (Ed25519 request tokens, the peers'
keyring, the replay cache and a signed GET; 0.6.0), with their management commands
(architecture AD-4, AD-8, AD-10).

Add ``'mytp_core'`` to INSTALLED_APPS: that registers the field key system checks
(mytp_core.E001, mytp_core.E002), the table of done task effects (0.3.0, `migrate`) and
the commands ``generate_field_keys``, ``generate_kms_field_key``, ``kmscheck``,
``runjob``, ``backupdb``, ``enqueue_worker_heartbeat``, ``requeue_interrupted_tasks`` and
``generate_interface_signing_key``.
"""
__version__ = '0.6.0'

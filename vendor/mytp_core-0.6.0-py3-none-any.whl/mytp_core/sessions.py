"""One session per account, with an idle limit (0.5.0, moved from the portal's
`accounts.sessions`).

Every sign-in records the session's key on the account (a user field, default
`current_session_key`; mytp_core.models.SingleSessionUserMixin adds it) and deletes the
account's previous session: connect `SingleSession.on_user_logged_in` to Django's
`user_logged_in` signal in the site's AppConfig.ready (core connects no signal). The
middleware (`SessionLimitMiddleware`, a subclass naming the site's `single_session`) then
ends an authenticated request:

- whose session is not the account's current one: signed out, to the login page;
- that comes more than the policy's `idle_limit_seconds` after the session's last
  request: signed out, to the login page with the idle message.

The previous session's row is deleted by the new sign-in, so its browser's next request
is anonymous: the deleted key is remembered (hashed, in the cache, for the grace period),
and a request still carrying it goes to the login page with the replaced message, once.

Otherwise it stores the request's time as the last activity (htmx requests included) and
renews the session's own expiry (cookie and row) to `session_grace_seconds`, longer than
the idle limit, so an idle session can still be read, and its message shown, when the
person comes back within that time. Anonymous sessions are untouched.

`end_all_sessions(user)` ends every session of an account (for a password reset). Pages
named in `pass_through_url_names` never bounce to login: a session ended on them carries
on anonymously there.

Core has no locale: the site passes its own (translated) messages. Seams a site may
override in a subclass: `_now`, `_delete_replaced` (called by `on_user_logged_in`) and
`login_url(request)` (default: settings.LOGIN_URL; None lets the request go on, signed
out).
"""
import hashlib
import time
from importlib import import_module

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth import logout as auth_logout
from django.contrib.auth.views import redirect_to_login
from django.core.cache import cache
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import resolve_url
from django.urls import NoReverseMatch, Resolver404, resolve
from django.utils.crypto import constant_time_compare

# The time (epoch seconds) of the session's last authenticated request.
SEEN_SESSION_KEY = 'auth_seen_at'
SESSION_KEY_FIELD = 'current_session_key'

DEFAULT_REPLACED_MESSAGE = ('You were logged out because your account was logged in on '
                            'another device.')
DEFAULT_IDLE_MESSAGE = ('Your session ended after a period without activity. Please log '
                        'in again.')


class SingleSession:
    seen_session_key = SEEN_SESSION_KEY
    replaced_prefix = 'session-replaced:'

    def __init__(self, policy, *, replaced_message=DEFAULT_REPLACED_MESSAGE,
                 idle_message=DEFAULT_IDLE_MESSAGE, pass_through_url_names=frozenset(),
                 session_key_field=SESSION_KEY_FIELD):
        self.policy = policy
        self.replaced_message = replaced_message
        self.idle_message = idle_message
        self.pass_through_url_names = frozenset(pass_through_url_names)
        self.session_key_field = session_key_field

    @property
    def idle_limit(self):
        return self.policy.idle_limit_seconds

    @property
    def session_grace(self):
        return self.policy.session_grace_seconds

    # --- Seams ----------------------------------------------------------------------

    def _now(self):
        """The current time (epoch seconds)."""
        return time.time()

    def login_url(self, request):
        """The login page an ended session goes to; None lets the request go on."""
        try:
            return resolve_url(settings.LOGIN_URL)
        except NoReverseMatch:
            return None

    # --- The account's current session ----------------------------------------------

    @staticmethod
    def _session_store():
        return import_module(settings.SESSION_ENGINE).SessionStore

    def _accounts(self, user):
        return get_user_model()._default_manager.filter(pk=user.pk)

    def _stored_key(self, user):
        return self._accounts(user).values_list(self.session_key_field, flat=True).first()

    def _set_current_key(self, user, key, expected=None, check_expected=False):
        """Record `key` as the account's current session; with `check_expected`, only if
        the current one is still `expected`. Returns whether it was recorded."""
        accounts = self._accounts(user)
        if check_expected:
            accounts = accounts.filter(**{self.session_key_field: expected})
        recorded = accounts.update(**{self.session_key_field: key}) > 0
        if recorded:
            setattr(user, self.session_key_field, key)
        return recorded

    def _replaced_cache_key(self, session_key):
        # Hashed: the cache never holds a session key, even a deleted one.
        return self.replaced_prefix + hashlib.sha256(session_key.encode()).hexdigest()

    def _delete_replaced(self, session_key):
        """Delete the account's previous session, remembering that it was replaced."""
        self._session_store()(session_key).delete()
        cache.set(self._replaced_cache_key(session_key), 1, timeout=self.session_grace)

    def _pop_replaced(self, session_key):
        """Whether `session_key` was replaced by a later sign-in; forgotten once asked."""
        cache_key = self._replaced_cache_key(session_key)
        if cache.get(cache_key) is None:
            return False
        cache.delete(cache_key)
        return True

    def _start_activity(self, session):
        session[self.seen_session_key] = self._now()
        session.set_expiry(self.session_grace)

    def on_user_logged_in(self, sender, request, user, **kwargs):
        """A sign-in: the account's previous session is deleted and this one becomes
        current, with its activity clock started."""
        session = getattr(request, 'session', None)
        if session is None:
            return
        if session.session_key is None:
            session.save()
        key = session.session_key
        # Written only over the key read, so two simultaneous sign-ins cannot both replace
        # the same session: the one that loses re-reads the winner's key and replaces it
        # in turn (its browser gets the message).
        while True:
            previous = self._stored_key(user)
            if previous and previous != key:
                self._delete_replaced(previous)
            if self._set_current_key(user, key, expected=previous, check_expected=True):
                break
        self._start_activity(session)

    def end_all_sessions(self, user):
        """End every session of `user`: the current one is deleted and none is current any
        more, so any other session it may still have is ended by the middleware on its
        next request."""
        previous = self._stored_key(user)
        if previous:
            self._session_store()(previous).delete()
        self._set_current_key(user, None)

    def _is_current(self, user, key):
        current = getattr(user, self.session_key_field, None)
        return bool(current) and constant_time_compare(current, key or '')

    # --- Ending a session -------------------------------------------------------------

    def _is_pass_through(self, request):
        if not self.pass_through_url_names:
            return False
        try:
            return resolve(request.path_info).url_name in self.pass_through_url_names
        except Resolver404:
            return False

    def _to_login(self, request):
        """The response that sends an ended session to the login page; None to let the
        request go on (signed out): no login page, already on it, or a pass-through
        page."""
        login_url = self.login_url(request)
        if login_url is None or request.path == login_url or self._is_pass_through(request):
            return None
        if request.headers.get('HX-Request'):
            # htmx: a full-page redirect, not the login page swapped into a fragment.
            response = HttpResponse(status=204)
            response['HX-Redirect'] = login_url
            return response
        if request.method == 'GET':
            # Back to this page after the next sign-in (the login checks `next` is safe).
            return redirect_to_login(request.get_full_path(), login_url)
        return HttpResponseRedirect(login_url)

    def _was_replaced(self, request):
        """An anonymous request still carrying the cookie of a session that a later
        sign-in deleted (only a cookie whose session is gone is looked up)."""
        cookie = request.COOKIES.get(settings.SESSION_COOKIE_NAME)
        if not cookie or request.session.session_key is not None:
            return False
        return self._pop_replaced(cookie)

    def _ended_meanwhile(self, request, user, start_key):
        """Whether this request's session stopped being the account's during the view: a
        sign-in elsewhere or `end_all_sessions` deleted its row. A key cycled without a
        sign-in (Django's `update_session_auth_hash`, after a password change) becomes
        current, unless another sign-in has meanwhile."""
        new_key = request.session.session_key
        if new_key and new_key != start_key:
            return not self._set_current_key(user, new_key, expected=start_key,
                                             check_expected=True)
        return not self._session_store()().exists(start_key)

    def process(self, request, get_response):
        """The middleware's work for one request (see the module docstring)."""
        user = request.user
        start_key = None
        if user.is_authenticated:
            session = request.session
            key = session.session_key
            if not self._is_current(user, key):
                # A session from before this rule, or one left after `end_all_sessions`
                # (a later sign-in deletes the older session: it arrives anonymous).
                return self._end(request, None, get_response)
            seen = session.get(self.seen_session_key)
            if not isinstance(seen, (int, float)) or self._now() - seen > self.idle_limit:
                return self._end(request, self.idle_message, get_response)
            self._start_activity(session)
            start_key = key
        elif self._was_replaced(request):
            return self._end(request, self.replaced_message, get_response)
        response = get_response(request)
        still_in = (start_key is not None and request.user.is_authenticated
                    and request.user.pk == user.pk)
        if still_in and self._ended_meanwhile(request, user, start_key):
            # Replaced (or ended) while this request ran: its session must not be saved
            # (its row is gone), and the browser goes to login as it would next time.
            message = self.replaced_message if self._pop_replaced(start_key) else None
            auth_logout(request)
            if message is not None:
                messages.info(request, message)
            return self._to_login(request) or response
        return response

    def _end(self, request, message, get_response):
        auth_logout(request)
        if message is not None:
            messages.info(request, message)
        response = self._to_login(request)
        if response is None:
            return get_response(request)
        return response


class SessionLimitMiddleware:
    """One session per account, ended after the idle limit (see the module docstring).
    Subclass it with the site's `single_session` (a SingleSession) and list the subclass
    after AuthenticationMiddleware and MessageMiddleware."""

    single_session = None

    def __init__(self, get_response):
        if self.single_session is None:
            raise TypeError(f'{type(self).__name__} needs a single_session')
        self.get_response = get_response

    def __call__(self, request):
        return self.single_session.process(request, self.get_response)

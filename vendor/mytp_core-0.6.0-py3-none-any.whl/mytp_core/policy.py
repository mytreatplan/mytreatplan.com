"""A site's sign-in policy (0.5.0): the numbers the remembered device
(mytp_core.devices), the failure lockout (mytp_core.lockout) and the single session
(mytp_core.sessions) apply, so the portal and the admin site share the code and differ
only here.

Two ready policies:

- PORTAL: a device is remembered 90 days; 5 failures of one counter within 24 hours lock
  for 10 minutes; a session ends after 15 minutes without a request and lives 1 hour
  unrenewed; codes go by email, or to a mobile by WhatsApp, then SMS; no fresh code.
- ADMIN: a device is remembered 7 days; the same lockout rule (epic decision 2026-10-30);
  20 minutes idle, 1 hour grace (decision 2026-11-02); codes by email or SMS; a fresh code
  at every sign-in (`fresh_code`, a flag only: the admin site builds the behaviour).

`lock_notifier`, when set, is called as `notifier(subject, counter, count)` once when a
lock starts (`subject` is `account:<pk>` or `email:<blind index>`); None is a no-op. A
site sets it with `policy.with_notifier(fn)`.
"""
from dataclasses import dataclass, field, replace
from types import MappingProxyType
from typing import Callable, Mapping, Optional

from .verification import EMAIL, MOBILE, SMS, WHATSAPP

DAY_SECONDS = 24 * 60 * 60


@dataclass(frozen=True)
class SitePolicy:
    name: str
    # The remembered device: how long a mark is valid after it was given.
    remember_days: int
    # The kinds of contact a code can go to, each with its channels in the order tried
    # (a read-only mapping, left out of the hash, which it cannot take part in).
    channels: Mapping[str, tuple] = field(hash=False)
    # The single session: seconds without a request that end a signed-in session, and
    # seconds a session (cookie and row) lives unrenewed (longer, so the idle message can
    # still be shown).
    idle_limit_seconds: int
    session_grace_seconds: int
    # The lockout: this many failures in a row of one counter, each within the window of
    # the one before, lock the account (or the email) for lock_seconds.
    lock_threshold: int = 5
    lock_seconds: int = 10 * 60
    failure_window_seconds: int = DAY_SECONDS
    lock_notifier: Optional[Callable] = None
    # A fresh code at every sign-in, even on a remembered device (a flag only).
    fresh_code: bool = False

    @property
    def remember_seconds(self):
        return self.remember_days * DAY_SECONDS

    def with_notifier(self, notifier):
        """This policy, calling `notifier(subject, counter, count)` when a lock starts."""
        return replace(self, lock_notifier=notifier)


PORTAL = SitePolicy(
    name='portal',
    remember_days=90,
    channels=MappingProxyType({EMAIL: (EMAIL,), MOBILE: (WHATSAPP, SMS)}),
    idle_limit_seconds=15 * 60,
    session_grace_seconds=60 * 60,
    fresh_code=False,
)

ADMIN = SitePolicy(
    name='admin',
    remember_days=7,
    channels=MappingProxyType({EMAIL: (EMAIL,), MOBILE: (SMS,)}),
    idle_limit_seconds=20 * 60,
    session_grace_seconds=60 * 60,
    fresh_code=True,
)

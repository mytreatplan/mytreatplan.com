"""mytp-core's only table (0.3.0): the effects background tasks have done (AD-8); and an
abstract mixin (0.5.0) for a site's user model.

The package shares code, never data (AD-10): each site has its own table, in its own
database, created by `manage.py migrate`. The mixin adds no table and no migration here:
the site's own migration adds its field.
"""
from django.db import models


class TaskEffect(models.Model):
    """One effect done once: `effect` for the record `record` (a UUID) in `period` ('' for
    an effect done once per record). Written by mytp_core.tasks.run_once in the same
    transaction as the effect's database writes."""

    effect = models.CharField(max_length=100)
    record = models.UUIDField()
    period = models.CharField(max_length=32, blank=True, default='')
    done_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['effect', 'record', 'period'],
                                    name='mytp_core_taskeffect_once'),
        ]

    def __str__(self):
        period = f' ({self.period})' if self.period else ''
        return f'{self.effect} {self.record}{period}'


class SingleSessionUserMixin(models.Model):
    """The field mytp_core.sessions keeps the account's one current session key in (set at
    every sign-in, cleared by `end_all_sessions`; never shown). Mix it into the site's user
    model; the site's own migration adds the column."""

    current_session_key = models.CharField(max_length=40, null=True, blank=True,
                                           editable=False)

    class Meta:
        abstract = True

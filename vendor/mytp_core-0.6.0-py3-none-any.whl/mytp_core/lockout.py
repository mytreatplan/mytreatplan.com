"""The sign-in failure counters and the lockout (0.5.0, moved from the portal's
`accounts.login_failures`).

Two counters per account: PASSWORD (wrong passwords) and CODE (wrong or no longer valid
second-factor codes). A failure for an email with no account counts under PASSWORD for
that email's blind index (mytp_core.crypto.email_index), never the plain email. Each count
lives in CACHES['default'], one key per counter and account (or email index), and runs
out the policy's `failure_window_seconds` after its last failure. A successful sign-in
resets both counts of its account (`reset`); a site may also lift a lock (`unlock`).

Each count's read-then-write runs under a per-key lock (mytp_core.cache_mutex), waited for
up to a second, so two simultaneous failures are both counted. When a count reaches the
policy's `lock_threshold`, its subject (the account, or the typed email's blind index) is
locked for `lock_seconds` (`lock`, `is_locked`), that count starts again from 0 (so after
the lock a new run is needed), and the policy's `lock_notifier`, if any, is called once per
lock as `(subject, counter, count)`, after the counter's mutex is released (a "notified"
mark claimed with `cache.add`, kept for the lock's time, makes it once across both
counters).

Only counts and times are kept: never a password, a code or a contact. Any primary key
works (integer or UUID).

Seams a site may override in a subclass: the key prefixes, the mutex constants, and the
methods `_now`, `_sleep`, `_key`, `_clear` and `lock` (called by `record_failure`), and
`is_locked`.
"""
import time
from collections import namedtuple

from django.core.cache import cache

from .cache_mutex import cache_mutex
from .crypto import email_index

PASSWORD = 'password'
CODE = 'code'
COUNTERS = (PASSWORD, CODE)

# What `record_failure` did: the count in the run, whether it set the lock, and the
# (action, error) pairs of the steps that failed (lock, clear_count, store_count,
# notify), for the caller to report.
Failure = namedtuple('Failure', 'count locked errors')


class LoginFailures:
    failures_prefix = 'login:failures'
    lock_prefix = 'login:lock'

    # The per-key lock covers only a read-then-write; a request that finds it held tries
    # again every mutex_pause seconds, mutex_tries times (a second), then gives up
    # (mytp_core.cache_mutex.CounterBusy, for the caller to report).
    mutex_seconds = 5
    mutex_pause = 0.05
    mutex_tries = 20

    def __init__(self, policy):
        self.policy = policy

    @property
    def lock_threshold(self):
        return self.policy.lock_threshold

    @property
    def lock_seconds(self):
        return self.policy.lock_seconds

    @property
    def failure_window_seconds(self):
        return self.policy.failure_window_seconds

    def _now(self):
        """The current time (epoch seconds)."""
        return time.time()

    def _sleep(self, seconds):
        time.sleep(seconds)

    @staticmethod
    def _subject(account_id=None, email=None):
        """What a count or a lock belongs to: the account, else the email's blind index."""
        if account_id is not None:
            return f'account:{account_id}'
        if email is None:
            raise ValueError('a login failure counts for an account or an email')
        return f'email:{email_index(email)}'

    def _key(self, counter, account_id=None, email=None):
        if counter not in COUNTERS:
            raise ValueError(f'unknown login failure counter: {counter}')
        return f'{self.failures_prefix}:{counter}:{self._subject(account_id, email)}'

    def _lock_key(self, account_id=None, email=None):
        return f'{self.lock_prefix}:{self._subject(account_id, email)}'

    def _current(self, key, now):
        """The stored count, or 0 when there is none or its run has expired."""
        entry = cache.get(key)
        if (not isinstance(entry, dict)
                or now - entry.get('last', 0) >= self.failure_window_seconds):
            return 0
        return entry.get('count', 0)

    def _store(self, key, count, now):
        # The entry outlives the window a little; `_current` checks the time itself.
        cache.set(key, {'count': count, 'last': now},
                  timeout=self.failure_window_seconds + 60)

    def _clear(self, key):
        cache.delete(key)

    def record_failure(self, counter, *, account_id=None, email=None):
        """Count one failure of `counter` for the account `account_id` (a user pk) or, with
        no account, for `email`. Returns a Failure: the count in the current run (1 for
        the first), and whether it set the lock. The count that reaches the threshold
        locks the account (or the email) and starts that count again from 0. Setting the
        lock and clearing (or, without the lock, storing) the count are independent
        steps: one that fails is returned in `errors`, and does not undo or skip the
        other. The notifier is called only when the lock was set and this failure is the
        first to claim the subject's "notified" mark (an atomic `cache.add`, kept for the
        lock's time, shared by both counters), so one lock gives one call; it runs after
        the counter's mutex is released, so a slow notifier holds up no other failure."""
        key = self._key(counter, account_id, email)
        notifier = self.policy.lock_notifier
        notify = False
        with cache_mutex(key, seconds=self.mutex_seconds, pause=self.mutex_pause,
                         tries=self.mutex_tries, sleep=self._sleep):
            now = self._now()
            count = self._current(key, now) + 1
            if count < self.lock_threshold:
                self._store(key, count, now)
                return Failure(count, False, ())
            errors = []
            locked = False
            try:
                self.lock(account_id=account_id, email=email)
                locked = True
            except Exception as error:  # noqa: BLE001 - reported by the caller
                errors.append(('lock', error))
            try:
                if locked:
                    self._clear(key)
                else:  # not locked: keep counting, so the next failure tries the lock again
                    self._store(key, count, now)
            except Exception as error:  # noqa: BLE001 - reported by the caller
                errors.append(('clear_count' if locked else 'store_count', error))
            if locked and notifier is not None:
                try:
                    notify = cache.add(self._notified_key(account_id, email), 1,
                                       timeout=self.lock_seconds)
                except Exception as error:  # noqa: BLE001 - reported by the caller
                    errors.append(('notify', error))
        if notify:
            try:
                notifier(self._subject(account_id, email), counter, count)
            except Exception as error:  # noqa: BLE001 - reported by the caller
                errors.append(('notify', error))
        return Failure(count, locked, tuple(errors))

    def _notified_key(self, account_id=None, email=None):
        """The mark that this subject's current lock was notified (both counters share it)."""
        return f'{self.lock_prefix}:notified:{self._subject(account_id, email)}'

    def failure_count(self, counter, *, account_id=None, email=None):
        """The current count of `counter` for the account (or the email with no account);
        0 when there is no run going."""
        return self._current(self._key(counter, account_id, email), self._now())

    def reset(self, account_id):
        """A successful sign-in: both counts of the account start again from 0."""
        cache.delete_many([self._key(counter, account_id) for counter in COUNTERS])

    def lock(self, *, account_id=None, email=None):
        """Lock the account (or the email with no account) for lock_seconds from now."""
        now = self._now()
        cache.set(self._lock_key(account_id, email), {'until': now + self.lock_seconds},
                  timeout=self.lock_seconds + 60)

    def unlock(self, *, account_id=None, email=None):
        """Lift the lock of the account (or of the email with no account) at once."""
        cache.delete(self._lock_key(account_id, email))

    def is_locked(self, *, account_id=None, email=None):
        """Whether the account, or the email (its blind index), is locked now. With both,
        either lock counts."""
        keys = []
        if account_id is not None:
            keys.append(self._lock_key(account_id=account_id))
        if email is not None:
            keys.append(self._lock_key(email=email))
        now = self._now()
        for entry in cache.get_many(keys).values():
            if isinstance(entry, dict) and now < entry.get('until', 0):
                return True
        return False

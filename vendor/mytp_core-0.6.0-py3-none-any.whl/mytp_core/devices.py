"""The remembered device (0.5.0, moved from the portal's `accounts.devices`): "remember
this device" after a passed second factor, for the policy's `remember_days`.

The mark is a signed cookie only (no table): `django.core.signing` with its own salt,
carrying the account id, the issue time and the account's session auth hash. It is valid
while the signature checks, the issue time is less than the policy's remember period old
(fixed from the moment it was given: a later sign-in does not extend it) and the hash
still matches the account, so a password change or reset forgets every remembered device
of the account. Each account has its own cookie, named from a keyed, non-reversible digest
of its id, so several accounts in one browser keep their own marks. The cookie holds no
email or phone; nothing here logs. Any primary key works (integer or UUID): it is
compared as text.

Seams a site may override in a subclass: `signing_salt`, `name_salt`, `cookie_prefix`
(changing one forgets the marks already given), and `cookie_name`, `issue`, `is_valid`
(called by `is_remembered` and `remember`).
"""
from django.conf import settings
from django.core import signing
from django.utils.crypto import constant_time_compare, salted_hmac


class RememberedDevices:
    signing_salt = 'mytp_core.devices.remembered'
    name_salt = 'mytp_core.devices.cookie-name'
    cookie_prefix = 'mytp_device_'

    def __init__(self, policy):
        self.policy = policy

    @property
    def remember_seconds(self):
        return self.policy.remember_seconds

    def cookie_name(self, user):
        """This account's cookie: a keyed digest of its id (not reversible to the id)."""
        digest = salted_hmac(self.name_salt, str(user.pk), algorithm='sha256').hexdigest()
        return self.cookie_prefix + digest[:24]

    def issue(self, user, now):
        """The signed mark for `user`, given at `now` (epoch seconds)."""
        return signing.dumps({'u': str(user.pk), 't': int(now),
                              'h': user.get_session_auth_hash()},
                             salt=self.signing_salt)

    def is_valid(self, value, user, now):
        """Whether `value` is a valid mark of `user` at `now`: the signature checks, it was
        given for this account less than the remember period ago, and the account's
        session auth hash (its password) is the same."""
        if not value:
            return False
        try:
            data = signing.loads(value, salt=self.signing_salt)
        except signing.BadSignature:
            return False
        if not isinstance(data, dict):
            return False
        issued = data.get('t')
        if not isinstance(issued, int) or not 0 <= now - issued < self.remember_seconds:
            return False
        return (constant_time_compare(str(data.get('u', '')), str(user.pk))
                and constant_time_compare(str(data.get('h', '')),
                                          user.get_session_auth_hash()))

    def is_remembered(self, request, user, now):
        """Whether this browser holds a valid mark of `user`."""
        return self.is_valid(request.COOKIES.get(self.cookie_name(user)), user, now)

    def remember(self, response, user, now):
        """Give this browser `user`'s mark on `response`, for the remember period from
        `now`: HttpOnly, SameSite=Lax, Secure as the session cookie is."""
        response.set_cookie(
            self.cookie_name(user), self.issue(user, now),
            max_age=self.remember_seconds,
            secure=settings.SESSION_COOKIE_SECURE,
            httponly=True,
            samesite='Lax',
        )
        return response

"""Views every site serves (moved from the portal's mytp_publicsite/views.py, story 1.9).

Route `healthz` at the root of the site's URLconf (not under a language prefix):

    path('healthz', mytp_core.views.healthz, name='healthz')
"""
from django.conf import settings
from django.db import connection
from django.http import HttpResponse
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_safe

_TEXT = 'text/plain; charset=utf-8'


@never_cache
@require_safe
def healthz(request):
    """Uptime probe (outside basic auth). The first line is `ok` (200) when the database
    answers `SELECT 1`, else `unavailable` (503); a healthy answer adds `site: <SITE>`
    (architecture AD-24) and, when `REGION` is set (a portal), `region: <REGION>` (AD-13,
    0.2.1). No versions, other settings or error details."""
    try:
        with connection.cursor() as cursor:
            cursor.execute('SELECT 1')
            cursor.fetchone()
    except Exception:
        return HttpResponse('unavailable\n', status=503, content_type=_TEXT)
    lines = ['ok']
    site = getattr(settings, 'SITE', '')
    if site:
        lines.append(f'site: {site}')
    region = getattr(settings, 'REGION', '')
    if region:
        lines.append(f'region: {region}')
    return HttpResponse('\n'.join(lines) + '\n', content_type=_TEXT)

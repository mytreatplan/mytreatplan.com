"""Sentry error reporting for every MyTreatPlan site (moved from the portal's
mytreatplan/sentry.py, story 1.9; extended for architecture AD-23).

A site calls `init_sentry` from its settings only when SENTRY_DSN is set, so local
development and CI send nothing. Events never carry personal data: the SDK is told not
to collect it (`send_default_pii=False`, no request bodies, no local variables) and
`scrub_event` removes whatever an integration still attaches:

- request data other than the method and the URL path (bodies, cookies, headers, query
  strings, the client IP), and user details other than the numeric id;
- emails, IPv4/IPv6 addresses and phone numbers in free text (exception values, log
  messages, breadcrumb messages, and every string in `extra`, `contexts`, `tags` and
  breadcrumb `data`);
- the values of named sensitive fields (`SENSITIVE_FIELDS` plus the site's own) anywhere
  in `extra`, `contexts` (except the SDK's own, `SDK_CONTEXTS`), `tags` and breadcrumb
  `data`.

Settings a site passes to `init_sentry` (from its settings module, where
`django.conf.settings` cannot be read yet): `MYTP_SENTRY_IGNORED_LOGGERS` (loggers whose
records never reach Sentry), `MYTP_SENTRY_SENSITIVE_FIELDS` (more field names) and
`MYTP_SENTRY_SAFE_KEYS` (keys that keep their value).
"""
import ipaddress
import re
from urllib.parse import urlsplit, urlunsplit

import sentry_sdk

# Request keys that may hold personal data (form fields, cookies, headers, query
# strings, the client IP in `env`). Only the method and the URL path are kept.
_REQUEST_KEYS_KEPT = {'method', 'url'}
# User keys kept: the numeric id only (no email, username or IP).
_USER_KEYS_KEPT = {'id'}

# Field names whose values never leave the site (AD-23). A key matches when, ignoring
# case and with every separator removed (`_`, `-`, `.`, spaces), it contains one of these:
# `patient_name`, `patients`, `apikey`, `X-Api-Key`, `phonenumber`, `fullname` and
# `patient.notes` all match. This redacts too much rather than too little (`monkey`,
# `namespace` match too); keys known to be safe are listed in the safe keys.
SENSITIVE_FIELDS = (
    'password', 'secret', 'token', 'key', 'authorization', 'cookie', 'email', 'phone',
    'name', 'first_name', 'last_name', 'patient', 'address', 'iban',
)
# Keys (whole, ignoring case) that keep their value although they contain a field name:
# the default for MYTP_SENTRY_SAFE_KEYS (the portal's `password_reset.action` tag).
DEFAULT_SAFE_KEYS = ('password_reset.action',)
# Contexts the Sentry SDK fills itself (no personal data by design): their keys are not
# matched against the field names (`runtime.name`, `os.name` stay); their strings are
# still redacted for emails, IPs and phone numbers.
SDK_CONTEXTS = ('runtime', 'os', 'device', 'browser', 'app', 'trace', 'culture',
                'cloud_resource')

REDACTED = '[redacted]'
_EMAIL_RE = re.compile(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}')
# Candidates only; each is confirmed with `ipaddress`, so times like 03:30:00 stay.
_IP_CANDIDATE_RE = re.compile(r'(?<![\w:.])[0-9A-Fa-f:.]*[.:][0-9A-Fa-f:.]*(?![\w:])')
# Phone numbers: 9 to 15 digits (E.164's longest), either after a `+`, with spaces,
# hyphens or brackets between them (`+34 622 918 374`, `+1 (415) 555-2671`), or all
# together (`622918374`). Shorter numbers (prices, IDs, HTTP statuses), groups without a
# `+` (`200 301 404`), and digits inside a word, a decimal or an identifier stay.
_PHONE_RE = re.compile(r'(?<![\w+])\+\d(?:[ \-()]{0,2}\d){8,14}(?!\w)'
                       r'|(?<![\w.+-])\d{9,15}(?!\w|\.\d)')
_SEPARATORS_RE = re.compile(r'[^a-z0-9]+')
# Nesting deeper than this is replaced whole (events are JSON; this only bounds the walk).
_MAX_DEPTH = 20

# Set by init_sentry: the site's MYTP_SENTRY_SENSITIVE_FIELDS and MYTP_SENTRY_SAFE_KEYS.
_site_sensitive_fields = ()
_safe_keys = DEFAULT_SAFE_KEYS


def _squash(name):
    """'X-Api-Key' -> 'xapikey', 'patient.notes' -> 'patientnotes'."""
    return _SEPARATORS_RE.sub('', str(name).lower())


def _field_patterns():
    return {_squash(f) for f in (*SENSITIVE_FIELDS, *_site_sensitive_fields)} - {''}


def is_sensitive_key(key, patterns=None):
    """True when `key` names a sensitive field (see SENSITIVE_FIELDS) and is not a safe key."""
    patterns = _field_patterns() if patterns is None else patterns
    if str(key).lower() in {k.lower() for k in _safe_keys}:
        return False
    squashed = _squash(key)
    return any(pattern in squashed for pattern in patterns)


def _redact_ip(match):
    text = match.group(0)
    core = text.rstrip('.')
    try:
        ipaddress.ip_address(core)
    except ValueError:
        return text
    return REDACTED + text[len(core):]


def redact(text):
    """Replace email addresses, IPv4/IPv6 addresses and phone numbers in free text."""
    if not isinstance(text, str):
        return text
    text = _IP_CANDIDATE_RE.sub(_redact_ip, _EMAIL_RE.sub(REDACTED, text))
    return _PHONE_RE.sub(REDACTED, text)


def scrub_data(value, patterns=None, depth=0):
    """A copy of `value` (dicts, lists, strings) with the values of sensitive keys replaced
    by REDACTED and emails, IPs and phone numbers redacted in every string."""
    patterns = _field_patterns() if patterns is None else patterns
    if depth > _MAX_DEPTH:
        return REDACTED
    if isinstance(value, dict):
        return {k: REDACTED if is_sensitive_key(k, patterns)
                else scrub_data(v, patterns, depth + 1) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [scrub_data(v, patterns, depth + 1) for v in value]
    return redact(value)


def _scrub_tags(tags, patterns):
    if isinstance(tags, dict):
        return scrub_data(tags, patterns)
    if isinstance(tags, (list, tuple)):  # [[key, value], ...]
        scrubbed = []
        for item in tags:
            if isinstance(item, (list, tuple)) and len(item) == 2:
                key, value = item
                scrubbed.append([key, REDACTED if is_sensitive_key(key, patterns)
                                 else redact(value)])
            else:
                scrubbed.append(scrub_data(item, patterns))
        return scrubbed
    return tags


def _strip_query(url):
    parts = urlsplit(url)
    return urlunsplit((parts.scheme, parts.netloc, parts.path, '', ''))


def scrub_event(event, hint=None):
    """`before_send`: drop request data, cookies, headers, query strings, user email
    and IP from an event; redact emails, IPs and phone numbers in messages, exception
    values and breadcrumbs; and replace the values of sensitive fields in `extra`,
    `contexts`, `tags` and breadcrumb data, before it leaves the server."""
    patterns = _field_patterns()
    request = event.get('request')
    if isinstance(request, dict):
        scrubbed = {k: v for k, v in request.items() if k in _REQUEST_KEYS_KEPT}
        if isinstance(scrubbed.get('url'), str):
            scrubbed['url'] = _strip_query(scrubbed['url'])
        event['request'] = scrubbed

    user = event.get('user')
    if isinstance(user, dict):
        kept = {k: v for k, v in user.items() if k in _USER_KEYS_KEPT}
        if kept:
            event['user'] = kept
        else:
            event.pop('user', None)

    # Free text: exception values (e.g. a database error's DETAIL line with an email),
    # log messages and their arguments.
    for exc in (event.get('exception') or {}).get('values', []) or []:
        if isinstance(exc, dict) and 'value' in exc:
            exc['value'] = redact(exc['value'])
    logentry = event.get('logentry')
    if isinstance(logentry, dict):
        logentry.pop('params', None)
        for key in ('message', 'formatted'):
            if key in logentry:
                logentry[key] = redact(logentry[key])
    if isinstance(event.get('message'), str):
        event['message'] = redact(event['message'])

    # Structured data: named sensitive fields at any depth, free text in every string.
    if isinstance(event.get('extra'), dict):
        event['extra'] = scrub_data(event['extra'], patterns)
    contexts = event.get('contexts')
    if isinstance(contexts, dict):
        # The SDK's own contexts keep their keys (`runtime.name`); free text is redacted.
        event['contexts'] = {
            name: scrub_data(value, frozenset() if name in SDK_CONTEXTS else patterns)
            for name, value in contexts.items()}
        for name in event['contexts']:
            if name not in SDK_CONTEXTS and is_sensitive_key(name, patterns):
                event['contexts'][name] = REDACTED
    if 'tags' in event:
        event['tags'] = _scrub_tags(event['tags'], patterns)

    # Breadcrumbs: HTTP ones (outgoing requests) can carry query strings too.
    for crumb in (event.get('breadcrumbs') or {}).get('values', []) or []:
        if not isinstance(crumb, dict):
            continue
        if 'message' in crumb:
            crumb['message'] = redact(crumb['message'])
        data = crumb.get('data')
        if isinstance(data, dict):
            data.pop('http.query', None)
            data.pop('http.fragment', None)
            if isinstance(data.get('url'), str):
                data['url'] = _strip_query(data['url'])
            crumb['data'] = scrub_data(data, patterns)
    return event


def init_sentry(dsn, environment, release=None, *, ignored_loggers=(), sensitive_fields=(),
                safe_keys=DEFAULT_SAFE_KEYS):
    """Turn on Sentry. Called from a site's settings only when SENTRY_DSN is set.

    `ignored_loggers` (MYTP_SENTRY_IGNORED_LOGGERS): loggers whose records stay on the
    server (no breadcrumbs, events or Sentry Logs), e.g. ones that log verification codes.
    `sensitive_fields` (MYTP_SENTRY_SENSITIVE_FIELDS): field names scrubbed in addition
    to SENSITIVE_FIELDS.
    `safe_keys` (MYTP_SENTRY_SAFE_KEYS, default DEFAULT_SAFE_KEYS): whole keys that keep
    their value although they contain a field name.
    """
    global _site_sensitive_fields, _safe_keys
    from sentry_sdk.integrations.django import DjangoIntegration
    from sentry_sdk.integrations.logging import ignore_logger, ignore_logger_for_sentry_logs

    if any(isinstance(v, str) for v in (ignored_loggers, sensitive_fields, safe_keys)):
        raise TypeError(
            'ignored_loggers, sensitive_fields and safe_keys take a list or tuple of names')
    for logger_name in ignored_loggers:
        ignore_logger(logger_name)
        ignore_logger_for_sentry_logs(logger_name)
    _site_sensitive_fields = tuple(sensitive_fields)
    _safe_keys = tuple(safe_keys)

    sentry_sdk.init(
        dsn=dsn,
        environment=environment,
        release=release or None,
        integrations=[DjangoIntegration()],
        send_default_pii=False,
        max_request_body_size='never',
        include_local_variables=False,
        before_send=scrub_event,
        # Errors only; no performance tracing.
        traces_sample_rate=0,
    )

"""The interface version policy (0.7.0, architecture AD-12 "Version skew"): API paths are
``/api/v<n>/``; a breaking change is a new version; the admin site serves the current
version n and n-1, so a portal one release behind still talks to it. Readers ignore
unknown fields and event types (the contract models drop unknown fields).

A site lists its versions' URL modules and lets `api_url_patterns` include the served
ones:

    urlpatterns += api_url_patterns({1: 'interface.api_v1', 2: 'interface.api_v2'})
"""
from django.core.exceptions import ImproperlyConfigured
from django.urls import include, path

API_VERSION = 1


def served_versions(current=API_VERSION):
    """The versions served: (n, n-1), or (1,) while n is 1."""
    if type(current) is not int or current < 1:
        raise ValueError('an API version is an integer >= 1')
    return (current, current - 1) if current > 1 else (current,)


def api_url_patterns(urlconfs, current=API_VERSION, prefix='api/'):
    """``path('<prefix>v<n>/', include(urlconfs[n]))`` for each served version, newest
    first. A served version missing from `urlconfs` is an ImproperlyConfigured; older
    entries are not served."""
    missing = [version for version in served_versions(current) if version not in urlconfs]
    if missing:
        raise ImproperlyConfigured(
            f'the API URLs of version(s) {", ".join(map(str, missing))} are missing: '
            f'versions {served_versions(current)} are served.')
    return [path(f'{prefix}v{version}/', include(urlconfs[version]))
            for version in served_versions(current)]

"""The event envelope (0.7.0, architecture AD-3 outbox, AD-12, conventions "Interface
envelope"):

    {"event_id": "<uuid>", "type": "client.updated", "version": 1,
     "aggregate_id": "<uuid>", "aggregate_version": 3, "sequence": 7,
     "occurred_at": "2026-11-05T10:00:00Z", "region": "eu", "payload": {...}}

- ``event_id``, ``aggregate_id``: UUID strings; ``type``: dotted lowercase
  (``<entity>.<past-tense verb>``); ``version``, ``aggregate_version``, ``sequence``:
  integers >= 1 (a JSON integer, never a float or a string); ``occurred_at``: ISO 8601 UTC
  ending in ``Z``; ``region``: a region code (``eu``, ``ae``); ``payload``: an object that
  passes `checks.check_central_payload` (no float, patient field or file).
- An unknown ``type`` still parses: the reader skips an event it does not handle
  (AD-12: readers ignore unknown fields and event types). Each event type's closed
  payload model lives in `contracts.payloads` (0.8.0).
- One event per POST; the body (the envelope's JSON) is at most `MAX_EVENT_BYTES`
  (256 KB, 0.8.0).
- The answer to an event POST (0.8.0, `EventResult`): 200 with ``{"result": "accepted" |
  "duplicate" | "stale" | "rejected", "reason"?: "<code>"}``; the sender marks the
  event delivered on the first three (`DELIVERED_RESULTS`) and rejected on the last.
- `utc_text(datetime)` (0.8.0) is a time in the contract's form (``...Z``), for any
  interface answer that carries a time.
"""
import re
from datetime import UTC, datetime
from typing import Annotated, Any, Literal
from uuid import UUID

from pydantic import (BeforeValidator, Field, PlainSerializer, StrictInt, WithJsonSchema,
                      field_validator, model_serializer, model_validator)

from .base import ContractModel
from .checks import ContractViolation, check_central_payload, find_violations

TYPE_PATTERN = r'^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$'
REGION_PATTERN = r'^[a-z]{2}$'
# RFC 3339 in UTC, as the writers produce it: seconds always, up to 6 decimals, "Z".
TIME_PATTERN = r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,6})?Z$'
TIME_RE = re.compile(TIME_PATTERN)
# The canonical UUID form only: lowercase, hyphenated.
UUID_PATTERN = r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
UUID_RE = re.compile(UUID_PATTERN)
# The largest envelope body a site sends or accepts (one event per POST).
MAX_EVENT_BYTES = 256 * 1024
PAYLOAD_DESCRIPTION = (
    'An object that passes mytp_core.contracts.checks.check_central_payload: JSON values '
    'only, at most 64 levels deep, no float anywhere (amounts are {"amount": "123.45", '
    '"currency": "EUR"}); no patient field (no key starting with "patient" but '
    '"patient_code"; under "patient"/"patients" only {"patient_code": ...}; '
    '"patient_code" always in the form "EU-7K3QX9MD"); no file (file, files, filename, '
    'file_name, attachment(s), upload(s), object_key, storage_key, download_url, '
    'presigned_url keys, data URIs, object-storage or signed links, long base64). Keys '
    'compare after NFKC, ignoring case, invisible characters, "_", "-", "." and spaces.')


def _utc_z(value):
    if isinstance(value, str):
        if not TIME_RE.fullmatch(value):
            raise ValueError('a time is ISO 8601 UTC as YYYY-MM-DDThh:mm:ss[.ffffff]Z')
        try:
            value = datetime.fromisoformat(value)
        except ValueError:
            raise ValueError('a time is ISO 8601 UTC ending in "Z"') from None
    if not isinstance(value, datetime):
        raise ValueError('a time is an ISO 8601 UTC string ending in "Z"')
    if value.tzinfo is None or value.utcoffset().total_seconds() != 0:
        raise ValueError('a time is in UTC')
    return value.astimezone(UTC)


def _z_text(value):
    timespec = 'microseconds' if value.microsecond else 'seconds'
    return value.astimezone(UTC).isoformat(timespec=timespec).replace('+00:00', 'Z')


def utc_text(value):
    """An aware datetime in the contract's form: ISO 8601 UTC ending in ``Z`` (seconds,
    plus microseconds when there are any). ValueError for a naive datetime."""
    if not isinstance(value, datetime) or value.utcoffset() is None:
        raise ValueError('utc_text takes an aware datetime')
    return _z_text(value)


UtcTime = Annotated[
    datetime,
    BeforeValidator(_utc_z),
    PlainSerializer(_z_text, return_type=str, when_used='json'),
    WithJsonSchema({'type': 'string', 'format': 'date-time', 'pattern': 'Z$',
                    'description': 'ISO 8601 UTC ending in "Z".'}),
]
Positive = Annotated[StrictInt, Field(ge=1)]


def _canonical_uuid(value):
    if isinstance(value, UUID):
        return value
    if not isinstance(value, str) or not UUID_RE.fullmatch(value):
        raise ValueError('a UUID is a lowercase, hyphenated string')
    return value


CanonicalUuid = Annotated[
    UUID,
    BeforeValidator(_canonical_uuid),
    WithJsonSchema({'type': 'string', 'format': 'uuid', 'pattern': UUID_PATTERN}),
]


class EventEnvelope(ContractModel):
    event_id: CanonicalUuid
    type: str = Field(pattern=TYPE_PATTERN, max_length=100)
    version: Positive
    aggregate_id: CanonicalUuid
    aggregate_version: Positive
    sequence: Positive
    occurred_at: UtcTime
    region: str = Field(pattern=REGION_PATTERN)
    payload: dict[str, Any] = Field(description=PAYLOAD_DESCRIPTION)

    @model_validator(mode='before')
    @classmethod
    def _unknown_fields(cls, data):
        # Unknown top-level fields are dropped, but one carrying patient data, a file or a
        # float is refused rather than silently passed over.
        if isinstance(data, dict):
            extra = {key: value for key, value in data.items()
                     if key not in cls.model_fields}
            found = find_violations(extra, path='envelope')
            if found:
                raise ContractViolation(found)
        return data

    @field_validator('payload')
    @classmethod
    def _central_payload(cls, value):
        return check_central_payload(value)

    @model_serializer(mode='wrap')
    def _dump(self, handler):
        # `model_copy(update=...)`, `model_construct` and a payload changed in place skip
        # validation: validate the field values again (the payload's checks included)
        # before anything is dumped, so nothing goes out that would not have been read.
        fields = {name: value for name, value in self.__dict__.items()
                  if name in type(self).model_fields}
        type(self).model_validate(fields)
        return handler(self)


# The answers to an event POST (0.8.0): 200 with {"result": ..., "reason"?: ...} once the
# receiver stored or refused the envelope.
ACCEPTED = 'accepted'      # applied (or an unknown type, ignored)
DUPLICATE = 'duplicate'    # this event_id was received before
STALE = 'stale'            # the aggregate already holds this version or a later one
REJECTED = 'rejected'      # refused for good (reason says why); never resent
EVENT_RESULTS = (ACCEPTED, DUPLICATE, STALE, REJECTED)
# The 2xx results after which the sender marks the event delivered.
DELIVERED_RESULTS = (ACCEPTED, DUPLICATE, STALE)


class EventResult(ContractModel):
    result: Literal['accepted', 'duplicate', 'stale', 'rejected']
    reason: str | None = Field(default=None, pattern=r'^[a-z][a-z0-9_]{0,63}$',
                               description='A short snake_case code (rejected only).')

    @model_validator(mode='after')
    def _reason_with_rejected_only(self):
        if (self.result == REJECTED) != (self.reason is not None):
            raise ValueError('a reason is given with "rejected", and only with it')
        return self


def event_result(result, reason=None):
    """The JSON-ready answer to an event POST (``reason`` left out when None)."""
    return EventResult(result=result, reason=reason).model_dump(mode='json',
                                                                exclude_none=True)

"""The catalogue section of the configuration snapshot (0.12.0, architecture AD-3, AD-6,
AD-16, AD-22; epic-catalogue entry 2): the products, country groups and subscriptions the
admin site's Commercial Manager defines, which every regional portal prices from.

    {"country_groups": [{"id": "<uuid>", "name": "Iberia", "countries": ["ES", "PT"],
                         "catch_all": false, "active": true}],
     "products": [{"id": "<uuid>", "name": "TPS", "category": "tps",
                   "net_price": {"amount": "100.00", "currency": "EUR"}, "active": true}],
     "subscriptions": [{"id": "<uuid>", "tier": "basic", "country_group": "<uuid>",
                        "tps_discount_percent": "10.00", "active": true}]}

- Every row is listed, inactive ones too (``active: false``); ids are UUID strings, each
  once per list.
- A country group lists ISO 3166-1 alpha-2 codes (uppercase), each once; ``catch_all``
  marks the group of every country in no other active group ("Rest of world"). Among the
  active groups a country is in at most one, and at most one is the catch-all.
- A product's ``category`` and a subscription's ``tier`` are lowercase codes (``tps`` /
  ``other`` until 0.20.0, whose codes are listed below; ``basic`` / ``advanced`` /
  ``premium``), not a closed list: a later release adds codes, and a reader skips what it
  does not know.
- ``net_price`` is a net amount (the `Amount` contract; VAT is added at checkout), never
  negative. The admin site writes only the currencies of `mytp_core.money.CURRENCIES`
  (EUR, AED, USD); the contract takes any ISO 4217 form, and a reader skips a product in a
  currency it does not know (a later release may add one). ``tps_discount_percent`` is a
  decimal string with exactly 2 places from ``"0.00"`` to ``"100.00"``.
- A subscription's ``country_group`` is the id of a listed group; at most one active
  subscription per (tier, country group).

Since 0.20.0 (epic-catalogue entry 5) a product may also carry, each optional:

    {"texts": {"en": {"name": "TPS", "description": "A plan.\\nIn two lines."},
               "es": {"name": "TPS", "description": ""}},
     "code": "TPS-BR-01", "valid_from": "2026-01-01", "valid_to": "2026-12-31"}

- ``texts``: the public texts per language (a lowercase language tag: two or three
  letters, then optional ``-`` subtags of letters or digits, as ``es``, ``pt-br``; a
  reader falls back to English for a language it does not show): a ``name`` (at
  most 150 characters) and a short ``description`` (at most 1000; plain text, line breaks
  as ``\\n``; may be empty). English (``en``) is always there with a name that is not
  blank and equals the product's ``name``; any other
  language, or an empty text of one, falls back to English (`CatalogueProduct.name_in`,
  `description_in`). ``name`` stays the English public name, for readers before 0.20.0.
- ``code``: the internal code, unique among the products that have one (a section where
  two products share a code is refused): 1 to 64 uppercase letters,
  digits and ``. _ / -``. Readers identify a product by its id, never by its code.
- ``valid_from`` / ``valid_to``: ISO dates (``YYYY-MM-DD``), each optional, both
  inclusive, in Madrid time; ``valid_to`` never before ``valid_from``. Outside them the
  product is not offered for new orders (`CatalogueProduct.offered_on`) but stays listed.
- The internal notes of a product never leave the admin site: they are not in the contract.
- The category codes of 0.20.0's admin site are ``tps_branded``, ``tps_in_house``,
  ``initial_case_evaluation``, ``virtuaortho_one``, ``virtuaortho_digitaltwin``, ``odb``,
  ``retainers``, ``spark_on_demand``, ``subscription``, ``education`` and
  ``uncategorised`` (a product not yet given one of them); ``tps`` and ``other`` are the
  codes of an admin site before it, which a reader takes as ``tps_branded`` and
  ``uncategorised``. The list stays open, as above.

and a subscription ``tps_in_house_discount_percent`` (optional; a percentage as
``tps_discount_percent``): the discount on ``tps_in_house`` products, while
``tps_discount_percent`` is the discount on ``tps_branded`` ones. Absent (an admin site
before 0.20.0) it reads as 0 (`CatalogueSubscription.in_house_discount_percent`). No
other category is discounted.

Since 0.21.0 (epic-catalogue entry 6) a product may also carry, each optional:

    {"size": "medium", "per_unit": {"min_quantity": 4, "max_quantity": 9},
     "calls": {"count": 3, "minutes": 25},
     "cost_links": [{"provider_product": "<uuid>", "quantity": 2, "monthly": false}]}

- ``size``: a lowercase code (``short``, ``medium``, ``long`` on the admin site of
  0.21.0; an open list, as the categories), given to TPS products only.
- ``per_unit``: the product is priced per unit (``net_price`` is the price of one), for
  a whole quantity from ``min_quantity`` (at least 1) to ``max_quantity`` (never below
  it), both inclusive. Absent: the product is sold once per line (quantity 1).
- ``calls``: the calls the product grants: ``count`` calls of ``minutes`` minutes each,
  whole numbers above 0.
- ``cost_links``: the provider products (ids of the snapshot's ``provider_costs``
  section) the product is made of, each at most once, with a whole ``quantity`` (at
  least 1) and whether the cost is ``monthly``. The product's cost on a date is the sum
  of its links that are not monthly (a product without any has no cost to show:
  `ProductCost.empty`), each the provider product's cost on that date ×
  the quantity (`CatalogueProduct.cost_at`, `sum_costs`); a monthly link is never in the
  sum: it is listed apart with its monthly cost. A link whose provider product has no
  cost on the date (a gap; not listed; another currency than the product's, or one this
  release does not know) leaves the sum partial: it is then marked incomplete and names
  what is missing, and is never to be shown as a complete cost. Only the links in force
  are sent (an ended one is left out).

and the section an optional ``add_ons`` list (0.21.0), what a buyer may choose next to a
product:

    {"add_ons": [{"id": "<uuid>", "code": "BYTE-SYNC",
                  "texts": {"en": {"name": "Byte Sync", "description": ""}},
                  "amount": {"amount": "120.00", "currency": "EUR"},
                  "categories": ["tps_branded", "tps_in_house",
                                 "initial_case_evaluation", "virtuaortho_one",
                                 "virtuaortho_digitaltwin", "odb"], "active": true},
                 {"id": "<uuid>", "code": "ONE-ARCH",
                  "texts": {"en": {"name": "One arch", "description": ""}},
                  "percent": "-25.00", "categories": ["tps_in_house"],
                  "active": true},
                 {"id": "<uuid>", "code": "JUNIOR-1",
                  "texts": {"en": {"name": "Junior I", "description": ""}},
                  "amount": {"amount": "0.00", "currency": "EUR"},
                  "categories": ["tps_branded", "tps_in_house"],
                  "sizes": ["medium"], "active": true}]}

- Every add-on is listed, inactive ones too; ids once, codes once (a code as a product's:
  uppercase letters, digits and ``. _ / -``). ``texts`` as a product's: English always,
  with a name that is not blank.
- Exactly one of ``amount`` (a fixed net amount in one currency, never negative; ``0.00``
  for an add-on that only marks the order) and ``percent`` (a signed percentage with
  exactly 2 places from ``"-100.00"`` to ``"100.00"``, never ``"-0.00"``, applied to the
  product's net price: ``"-25.00"`` takes a quarter off).
- ``categories``: the product categories it is offered on, each once. ``sizes``
  (optional): the product sizes it is offered on, each once; absent, the size does not
  matter. An add-on with an ``amount`` is offered only on products of that currency
  (`CatalogueAddOn.applies_to`, `CatalogueSection.add_ons_for`).
- A line's price (`CatalogueProduct.line_price`, `line_price`): ``net price × quantity ×
  (1 + percent / 100) for each percentage add-on × (1 − subscription discount / 100)``,
  plus the fixed amounts, once per line whatever the quantity; computed exactly and
  rounded half up to cents once, at the end. The subscription discount therefore never
  applies to a fixed add-on.

A field of these that is absent (or null) stays absent when the row is dumped, so a row
without them dumps, and a snapshot of an older admin site signs, exactly as in 0.19.0
(and, without the fields and the list of 0.21.0, as in 0.20.0).

The rules across rows (a subscription's group is listed; at most one active subscription
per tier and group; a country in at most one active group; at most one active catch-all)
are part of the reader contract: a snapshot that breaks one is refused whole
(`invalid_body`), and the reader keeps its last good snapshot, which is the safe failure.
Relaxing any of them is a breaking change: it needs a `min_reader` bump, so readers that
still enforce it keep their snapshot instead of refusing every new one.

The section is optional in the snapshot (`ConfigSnapshot.catalogue`): an admin site older
than 0.12.0 sends none, and a portal then holds an empty catalogue.
"""
import dataclasses
from decimal import (MAX_EMAX, MIN_EMIN, ROUND_HALF_UP, Context, Decimal, Inexact,
                     InvalidOperation)
from typing import Annotated

from pydantic import (BeforeValidator, Field, PlainSerializer, StrictBool, StrictInt,
                      StringConstraints, WithJsonSchema, model_serializer, model_validator)

from .amounts import Amount, _decimal_amount
from .base import ContractModel
from .events import CanonicalUuid
from .provider_costs import IsoDate

Name = Annotated[str, StringConstraints(min_length=1, max_length=150)]
# A choice code: lowercase letters, digits and "_", starting with a letter.
Code = Annotated[str, StringConstraints(min_length=1, max_length=32,
                                        pattern=r'^[a-z][a-z0-9_]*$')]
CountryCode = Annotated[str, StringConstraints(pattern=r'^[A-Z]{2}$')]

PERCENT_PATTERN = r'^(100\.00|[1-9]?[0-9]\.[0-9]{2})$'
HUNDRED = Decimal('100')


def _decimal_percent(value):
    try:
        value = _decimal_amount(value)
    except ValueError:
        raise ValueError('a percentage is a decimal string with exactly 2 places, '
                         'e.g. "10.00"') from None
    if not Decimal(0) <= value <= HUNDRED:
        raise ValueError('a percentage is from "0.00" to "100.00"')
    return value


Percent = Annotated[
    Decimal,
    BeforeValidator(_decimal_percent),
    PlainSerializer(lambda value: format(value, 'f'), return_type=str, when_used='json'),
    WithJsonSchema({'type': 'string', 'pattern': PERCENT_PATTERN,
                    'description': 'A percentage with exactly 2 places, "0.00" to "100.00".'}),
]


# 0.21.0: an add-on's percentage, signed ("-25.00" takes a quarter off).
SIGNED_PERCENT_PATTERN = r'^(?!-0\.00$)-?(100\.00|[1-9]?[0-9]\.[0-9]{2})$'


def _decimal_signed_percent(value):
    try:
        value = _decimal_amount(value)
    except ValueError:
        raise ValueError('a signed percentage is a decimal string with exactly 2 places, '
                         'e.g. "-25.00"') from None
    if not -HUNDRED <= value <= HUNDRED:
        raise ValueError('a signed percentage is from "-100.00" to "100.00"')
    return value


SignedPercent = Annotated[
    Decimal,
    BeforeValidator(_decimal_signed_percent),
    PlainSerializer(lambda value: format(value, 'f'), return_type=str, when_used='json'),
    WithJsonSchema({'type': 'string', 'pattern': SIGNED_PERCENT_PATTERN,
                    'description': 'A signed percentage with exactly 2 places, "-100.00" '
                                   'to "100.00".'}),
]

# 0.21.0: a whole quantity (units of a product, calls, minutes, provider products of a
# link). The upper bound keeps it within every site's integer column.
MAX_QUANTITY = 1_000_000
Quantity = Annotated[StrictInt, Field(ge=1, le=MAX_QUANTITY)]


class CatalogueCountryGroup(ContractModel):
    """A group of countries a subscription applies to."""

    id: CanonicalUuid
    name: Name
    countries: list[CountryCode]
    catch_all: StrictBool = Field(
        description='The group of every country in no other active group.')
    active: StrictBool

    @model_validator(mode='after')
    def _unique_countries(self):
        if len(self.countries) != len(set(self.countries)):
            raise ValueError('a country group lists a country twice')
        return self


def _without_absent(data, names):
    """A dumped row without its optional fields that are None: an absent field stays
    absent (never ``"code": null``), so a row without them dumps as before they existed."""
    if isinstance(data, dict):
        for name in names:
            if name in data and data[name] is None:
                del data[name]
    return data


# 0.20.0: a product's public texts, per language.
ENGLISH = 'en'
# A lowercase language tag: two or three letters, then optional "-" subtags of letters or
# digits ("es", "pt-br", "zh-hans"). Wide on purpose: a reader falls back to English for
# a language it does not show, and a reader rule cannot be relaxed later.
LanguageCode = Annotated[str, StringConstraints(
    max_length=35, pattern=r'^[a-z]{2,3}(-[a-z0-9]{1,8})*$')]
PRODUCT_CODE_PATTERN = r'^[A-Z0-9._/-]{1,64}$'
ProductCode = Annotated[str, StringConstraints(pattern=PRODUCT_CODE_PATTERN)]


class ProductText(ContractModel):
    """A product's public texts in one language (0.20.0): plain text, the description
    with line breaks. An empty one falls back to English."""

    name: str = Field(default='', max_length=150)
    description: str = Field(default='', max_length=1000)


def _check_texts(texts, what):
    if not (ENGLISH in texts and texts[ENGLISH].name.strip()):
        raise ValueError(f"{what}'s texts have an English name")


def _text_in(texts, language, field):
    """The text `field` in `language`, else in English, else ''."""
    texts = texts or {}
    for code in (language, ENGLISH):
        value = getattr(texts.get(code), field, '')
        if value:
            return value
    return ''


def _each_once(values, message):
    if len(values) != len(set(values)):
        raise ValueError(message)


# --- Pricing and costs (0.21.0) -----------------------------------------------------------

class QuantityRefused(ValueError):
    """A quantity a product is not sold in: outside its per-unit range, or other than 1
    for a product that is not priced per unit."""


class AddOnRefused(ValueError):
    """An add-on that cannot be chosen with a product: inactive, not offered on it (its
    category, size or currency), or chosen twice."""


# Exact arithmetic for a line: a result that would need rounding before the end is an
# error, never a silent rounding (and the thread's context never changes a price).
_EXACT = Context(prec=120, rounding=ROUND_HALF_UP, Emax=MAX_EMAX, Emin=MIN_EMIN,
                 traps=[InvalidOperation, Inexact])
_ONE = Decimal(1)


def _is_quantity(value):
    return isinstance(value, int) and not isinstance(value, bool)


def check_quantity(quantity, min_quantity=None, max_quantity=None):
    """`QuantityRefused` unless `quantity` is one the product is sold in: a whole number
    from `min_quantity` to `max_quantity` (both inclusive) for a product priced per unit;
    exactly 1 for any other product (both None)."""
    if not _is_quantity(quantity):
        raise QuantityRefused('a quantity is a whole number')
    if min_quantity is None and max_quantity is None:
        if quantity != 1:
            raise QuantityRefused('this product is not priced per unit: its quantity is 1')
        return
    if min_quantity is None or max_quantity is None:
        raise ValueError('a per-unit range has a minimum and a maximum quantity')
    if not min_quantity <= quantity <= max_quantity:
        raise QuantityRefused(f'the quantity is from {min_quantity} to {max_quantity}')


def add_on_applies(*, categories, sizes, currency, product_category, product_size,
                   product_currency):
    """Whether an add-on is offered on a product: the product's category is among the
    add-on's `categories`; its size among the add-on's `sizes` (None: the size does not
    matter; a product without a size is then never among them); and an add-on with a
    fixed amount (`currency`; None for a percentage) is in the product's currency."""
    if product_category not in categories:
        return False
    if sizes is not None and product_size not in sizes:
        return False
    return currency is None or currency == product_currency


def _percentage(value, low, what):
    if (isinstance(value, bool) or not isinstance(value, (int, Decimal))
            or not Decimal(value).is_finite() or not low <= Decimal(value) <= HUNDRED):
        raise ValueError(f'{what} is a Decimal from {low} to 100')
    return Decimal(value)


def line_price(net_price, *, quantity=1, discount_percent=Decimal(0), percents=(),
               amounts=()):
    """The price of one line, as `mytp_core.money.Money`:

        net_price × quantity × (1 + p / 100) for each p of `percents`
                  × (1 − discount_percent / 100)  +  the `amounts`

    `net_price` and each of `amounts` (the fixed add-ons, once per line) are `Money` of
    one currency (`CurrencyMismatch` otherwise); `percents` are the percentage add-ons
    (Decimals from −100 to 100); `discount_percent` is the subscription's discount on the
    product (0 to 100), which never applies to a fixed amount. A negative net price or
    fixed amount is a ValueError: the rule of the contract models holds here too, for
    the sites that price from their own rows. Computed exactly, then rounded half up to
    cents once. It checks neither the quantity's range nor whether an
    add-on is offered on the product: `check_quantity`, `add_on_applies`."""
    # Imported here: mytp_core.money imports this package (contracts.amounts).
    from ..money import CurrencyMismatch, Money
    if not isinstance(net_price, Money):
        raise TypeError('a net price is Money')
    if net_price.amount < 0:
        raise ValueError('a net price is never negative')
    if not _is_quantity(quantity) or quantity < 1:
        raise QuantityRefused('a quantity is a whole number above 0')
    discount = _percentage(discount_percent, Decimal(0), 'a discount')
    try:
        factor = Decimal(quantity)
        for percent in percents:
            percent = _percentage(percent, -HUNDRED, 'an add-on percentage')
            factor = _EXACT.multiply(factor, _EXACT.add(_ONE, _EXACT.scaleb(percent, -2)))
        factor = _EXACT.multiply(factor,
                                 _EXACT.subtract(_ONE, _EXACT.scaleb(discount, -2)))
        total = _EXACT.multiply(net_price.amount, factor)
        for amount in amounts:
            if not isinstance(amount, Money):
                raise TypeError('a fixed add-on amount is Money')
            if amount.currency != net_price.currency:
                raise CurrencyMismatch(
                    f'cannot add {amount.currency} to a line in {net_price.currency}')
            if amount.amount < 0:
                raise ValueError("an add-on's amount is never negative")
            total = _EXACT.add(total, amount.amount)
    except Inexact:
        raise ValueError('too many percentages for an exact line price') from None
    return Money(total, net_price.currency)


@dataclasses.dataclass(frozen=True)
class MonthlyCost:
    """A monthly cost link of a product: `label` (the provider product's code, with its
    id when another link of the product has the same code: `link_labels`), the link's
    `quantity` and `cost`, the monthly cost of the link (the provider product's
    cost on the date × the quantity, `Money`), or None when there is none on the date."""

    label: str
    quantity: int
    cost: object


@dataclasses.dataclass(frozen=True)
class ProductCost:
    """A product's cost on a date (`sum_costs`): `total` is the sum of its links that are
    not monthly and have a cost on the date (`Money`). It is the product's cost only when
    `complete`; otherwise it is a partial sum, to be shown as such, with `missing`: the
    labels (provider product codes, with the id when two links share a code:
    `link_labels`) of the links without a cost. `monthly`: the monthly links
    (`MonthlyCost`), never in `total`. `links`: how many links are not monthly, summed
    or missing; with none (`empty`: no links, or only monthly ones) there is nothing to
    sum and the product has no cost to show: `total` is then 0.00, which is not a known
    cost of zero."""

    total: object
    complete: bool
    missing: tuple
    monthly: tuple
    links: int = 0

    @property
    def empty(self):
        """Whether no link is summed or missing: the product has no cost to show."""
        return self.links == 0

    @property
    def warning(self):
        """'' for a complete cost; otherwise the warning to show with the partial sum."""
        if self.complete:
            return ''
        return ('Incomplete cost: no cost on this date for ' + ', '.join(self.missing)
                + '.')


def link_labels(links):
    """The labels of a product's cost links, in order, from ``(code, id)`` pairs: the
    provider product's code (not unique across providers; None when it is not known:
    the label is then the id), followed by its id in brackets when another link of the
    product has the same code, so a warning always tells two provider products apart."""
    links = [(code, str(id_)) for code, id_ in links]
    codes = [code for code, _id in links if code is not None]
    return [id_ if code is None else code if codes.count(code) == 1 else f'{code} ({id_})'
            for code, id_ in links]


def sum_costs(entries, currency):
    """The `ProductCost` of a product of `currency` from its links' `entries`, each
    ``(label, quantity, monthly, cost)``: the link's label (`link_labels`), the link's
    quantity, whether the link is monthly, and what one unit of the provider product
    costs on the date (`Money`, or None: no cost on that date). A cost in another
    currency than `currency` counts as missing: it is never converted or summed."""
    from ..money import Money
    total, missing, monthly, links = Money.zero(currency), [], [], 0
    for label, quantity, is_monthly, cost in entries:
        if not _is_quantity(quantity) or quantity < 1:
            raise ValueError("a link's quantity is a whole number above 0")
        if cost is not None and cost.currency != currency:
            cost = None
        if is_monthly:
            monthly.append(MonthlyCost(label, quantity,
                                       None if cost is None else cost * quantity))
        else:
            links += 1
            if cost is None:
                missing.append(label)
            else:
                total = total + cost * quantity
    return ProductCost(total=total, complete=not missing, missing=tuple(missing),
                       monthly=tuple(monthly), links=links)


class PerUnit(ContractModel):
    """A product priced per unit (0.21.0): the quantities it is sold in, both
    inclusive."""

    min_quantity: Quantity
    max_quantity: Quantity

    @model_validator(mode='after')
    def _in_order(self):
        if self.max_quantity < self.min_quantity:
            raise ValueError('a maximum quantity is never below the minimum')
        return self


class ProductCalls(ContractModel):
    """The calls a product grants (0.21.0): `count` calls of `minutes` minutes each."""

    count: Quantity
    minutes: Quantity


class CostLink(ContractModel):
    """A provider product a product is made of (0.21.0): its id in the snapshot's
    ``provider_costs`` section, how many, and whether its cost is monthly (then listed
    apart, never in the product's cost)."""

    provider_product: CanonicalUuid
    quantity: Quantity
    monthly: StrictBool


# A product's optional fields (0.20.0; size, per_unit, calls and cost_links 0.21.0): left
# out of a dump when None.
PRODUCT_OPTIONAL = ('texts', 'code', 'valid_from', 'valid_to', 'size', 'per_unit', 'calls',
                    'cost_links')


class CatalogueProduct(ContractModel):
    """A product, at its net price; since 0.20.0 with its optional public texts per
    language, internal code and validity dates; since 0.21.0 with its optional size,
    per-unit quantity range, calls and cost links."""

    id: CanonicalUuid
    name: Name
    category: Code
    net_price: Amount
    active: StrictBool
    texts: dict[LanguageCode, ProductText] | None = None
    code: ProductCode | None = None
    valid_from: IsoDate | None = None
    valid_to: IsoDate | None = None
    size: Code | None = None
    per_unit: PerUnit | None = None
    calls: ProductCalls | None = None
    cost_links: list[CostLink] | None = None

    @model_serializer(mode='wrap')
    def _without_absent_fields(self, handler):
        return _without_absent(handler(self), PRODUCT_OPTIONAL)

    @model_validator(mode='after')
    def _consistent(self):
        if self.net_price.amount < 0:
            raise ValueError('a net price is never negative')
        if self.texts is not None:
            _check_texts(self.texts, 'a product')
            if self.texts[ENGLISH].name != self.name:
                raise ValueError("a product's name is the English name of its texts")
        if (self.valid_from is not None and self.valid_to is not None
                and self.valid_to < self.valid_from):
            raise ValueError("a product's validity ends before it starts")
        if self.cost_links is not None:
            _each_once([link.provider_product for link in self.cost_links],
                       'a product links a provider product twice')
        return self

    def _text(self, language, field):
        return _text_in(self.texts, language, field)

    def name_in(self, language):
        """The public name in `language` ("es"), else in English, else ``name`` (a row
        without texts)."""
        return self._text(language, 'name') or self.name

    def description_in(self, language):
        """The short description in `language`, else in English, else ''."""
        return self._text(language, 'description')

    def offered_on(self, day):
        """Whether `day` (a date, in Madrid time) is within the validity dates, both
        inclusive; an absent date does not limit. It says nothing of ``active``."""
        return ((self.valid_from is None or self.valid_from <= day)
                and (self.valid_to is None or day <= self.valid_to))

    def check_quantity(self, quantity):
        """`QuantityRefused` unless the product is sold in `quantity`: within its
        ``per_unit`` range, or exactly 1 without one (0.21.0)."""
        if self.per_unit is None:
            check_quantity(quantity)
        else:
            check_quantity(quantity, self.per_unit.min_quantity, self.per_unit.max_quantity)

    def line_price(self, add_ons=(), quantity=1, discount_percent=Decimal(0)):
        """The price (`Money`) of a line of this product with the chosen `add_ons`
        (`CatalogueAddOn`) and `quantity`, under a subscription discount on the product
        (a Decimal percentage): see `line_price`. `QuantityRefused` for a quantity the
        product is not sold in; `AddOnRefused` for an add-on that is inactive, not
        offered on this product or chosen twice; a ValueError for a product in a
        currency outside `mytp_core.money.CURRENCIES`."""
        from ..money import Money
        self.check_quantity(quantity)
        add_ons = list(add_ons)
        _check_add_ons(add_ons, self.id, lambda add_on: add_on.id,
                       lambda add_on: add_on.active and add_on.applies_to(self))
        return line_price(
            Money.from_contract(self.net_price), quantity=quantity,
            discount_percent=discount_percent,
            percents=[add_on.percent for add_on in add_ons if add_on.percent is not None],
            amounts=[Money.from_contract(add_on.amount) for add_on in add_ons
                     if add_on.amount is not None])

    def cost_at(self, day, provider_costs):
        """The product's `ProductCost` on `day` (a date) from its ``cost_links`` and the
        snapshot's provider costs section (`ProviderCostsSection`, or None: then every
        link is missing): see `sum_costs`. A link is named by its provider product's
        code (with its id when two links share a code: `link_labels`), or by its id
        when the section does not list it. A ValueError for a product in a currency
        outside `mytp_core.money.CURRENCIES`."""
        links = list(self.cost_links or ())
        listed = [None if provider_costs is None else provider_costs.product(
            link.provider_product) for link in links]
        labels = link_labels([(item and item.code, link.provider_product)
                              for link, item in zip(links, listed)])
        return sum_costs(
            [(label, link.quantity, link.monthly,
              None if item is None else item.cost_money_at(day))
             for label, link, item in zip(labels, links, listed)],
            self.net_price.currency)


def _check_add_ons(add_ons, product_id, key, offered):
    """`AddOnRefused` when one of `add_ons` is chosen twice or is not `offered`."""
    keys = [key(add_on) for add_on in add_ons]
    if len(keys) != len(set(keys)):
        raise AddOnRefused('an add-on is chosen twice')
    for add_on in add_ons:
        if not offered(add_on):
            raise AddOnRefused(f'the add-on {add_on.code} is not offered on the product '
                               f'{product_id}')


# An add-on's optional fields: left out of a dump when None.
ADD_ON_OPTIONAL = ('amount', 'percent', 'sizes')


class CatalogueAddOn(ContractModel):
    """What a buyer may choose next to a product (0.21.0): a fixed net ``amount`` or a
    signed ``percent`` of the product's net price, offered on the listed product
    ``categories`` and, when ``sizes`` is given, only on products of those sizes."""

    id: CanonicalUuid
    code: ProductCode
    texts: dict[LanguageCode, ProductText]
    amount: Amount | None = None
    percent: SignedPercent | None = None
    categories: list[Code]
    sizes: list[Code] | None = None
    active: StrictBool

    @model_serializer(mode='wrap')
    def _without_absent_fields(self, handler):
        return _without_absent(handler(self), ADD_ON_OPTIONAL)

    @model_validator(mode='after')
    def _consistent(self):
        _check_texts(self.texts, 'an add-on')
        if (self.amount is None) == (self.percent is None):
            raise ValueError('an add-on has an amount or a percentage, never both')
        if self.amount is not None and self.amount.amount < 0:
            raise ValueError("an add-on's amount is never negative")
        _each_once(self.categories, 'an add-on lists a category twice')
        if self.sizes is not None:
            _each_once(self.sizes, 'an add-on lists a size twice')
        return self

    @property
    def name(self):
        """The English public name."""
        return self.texts[ENGLISH].name

    def name_in(self, language):
        """The public name in `language`, else in English."""
        return _text_in(self.texts, language, 'name')

    def description_in(self, language):
        """The short description in `language`, else in English, else ''."""
        return _text_in(self.texts, language, 'description')

    def applies_to(self, product):
        """Whether it is offered on `product` (a `CatalogueProduct`): its category, its
        size and, for a fixed amount, its currency (`add_on_applies`). It says nothing
        of ``active``."""
        return add_on_applies(
            categories=self.categories, sizes=self.sizes,
            currency=None if self.amount is None else self.amount.currency,
            product_category=product.category, product_size=product.size,
            product_currency=product.net_price.currency)


class CatalogueSubscription(ContractModel):
    """A subscription tier in one country group, with its discounts: on TPS branded
    products (``tps_discount_percent``) and, since 0.20.0, on TPS in-house ones."""

    id: CanonicalUuid
    tier: Code
    country_group: CanonicalUuid
    tps_discount_percent: Percent
    # 0.20.0: optional, so the snapshot of an older admin site stays valid.
    tps_in_house_discount_percent: Percent | None = None
    active: StrictBool

    @model_serializer(mode='wrap')
    def _without_absent_fields(self, handler):
        return _without_absent(handler(self), ('tps_in_house_discount_percent',))

    @property
    def in_house_discount_percent(self):
        """The discount on TPS in-house products: 0 when the snapshot has none."""
        if self.tps_in_house_discount_percent is None:
            return Decimal('0.00')
        return self.tps_in_house_discount_percent


def _unique(rows, label):
    ids = [row.id for row in rows]
    if len(ids) != len(set(ids)):
        raise ValueError(f'{label} lists an id twice')


class CatalogueSection(ContractModel):
    """The snapshot's ``catalogue``: see the module docstring."""

    country_groups: list[CatalogueCountryGroup]
    products: list[CatalogueProduct]
    subscriptions: list[CatalogueSubscription]
    # 0.21.0: optional, so the snapshot of an older admin site stays valid.
    add_ons: list[CatalogueAddOn] | None = None

    @model_serializer(mode='wrap')
    def _without_absent_fields(self, handler):
        return _without_absent(handler(self), ('add_ons',))

    def add_ons_for(self, product):
        """The active add-ons offered on `product` (a `CatalogueProduct`), as listed;
        none when the section has no ``add_ons`` (an admin site before 0.21.0)."""
        return [add_on for add_on in self.add_ons or ()
                if add_on.active and add_on.applies_to(product)]

    @model_validator(mode='after')
    def _consistent(self):
        _unique(self.country_groups, 'country_groups')
        _unique(self.products, 'products')
        _unique(self.subscriptions, 'subscriptions')
        if self.add_ons is not None:
            # 0.21.0: an add-on's id and code are each once.
            _unique(self.add_ons, 'add_ons')
            _each_once([add_on.code for add_on in self.add_ons],
                       'two add-ons have the same code')
        # 0.20.0: a code is unique among the products that have one.
        codes = [product.code for product in self.products if product.code is not None]
        if len(codes) != len(set(codes)):
            raise ValueError('two products have the same code')
        active_groups = [group for group in self.country_groups if group.active]
        seen = set()
        for group in active_groups:
            if seen & set(group.countries):
                raise ValueError('a country is in two active country groups')
            seen |= set(group.countries)
        if sum(1 for group in active_groups if group.catch_all) > 1:
            raise ValueError('two active country groups are the catch-all')
        groups = {group.id for group in self.country_groups}
        pairs = set()
        for subscription in self.subscriptions:
            if subscription.country_group not in groups:
                raise ValueError('a subscription names a country group not listed')
            if subscription.active:
                pair = (subscription.tier, subscription.country_group)
                if pair in pairs:
                    raise ValueError('two active subscriptions of one tier and country group')
                pairs.add(pair)
        return self

"""The country map section of the configuration snapshot (0.15.0, architecture AD-3,
AD-14; epic-catalogue entry 3): the state of each ISO country the admin site's Sysadmin
defines, which every regional portal applies (one map for all regions).

    {"countries": [{"code": "ES", "state": "eu"}, {"code": "AE", "state": "ae"},
                   {"code": "RU", "state": "banned"}]}

- ``code``: two uppercase letters, each once. The contract checks the shape only, not
  the ISO 3166-1 list: the admin site restricts codes to its seeded rows (the ISO alpha-2
  codes plus AC and TA, codes reserved for Ascension and Tristan da Cunha).
- ``state``: a lowercase code (``eu``, ``ae``, ``banned`` today), not a closed list: a
  later release adds codes, and a reader keeps a country's current row when its state is
  one it does not know.
- A reader replaces its rows by code with the listed ones; a country not listed keeps its
  current row.

The section is optional in the snapshot (`ConfigSnapshot.country_map`): an admin site
older than 0.15.0 sends none, and a portal then keeps its current rows (its seed).
"""
from typing import Annotated

from pydantic import StringConstraints, model_validator

from .base import ContractModel
from .catalogue import CountryCode

# A state code: lowercase letters, digits and "_", starting with a letter. The portal's
# `regions.Country.state` column is 16 characters: a future state longer than that needs
# a portal migration before the admin site sends it.
StateCode = Annotated[str, StringConstraints(min_length=1, max_length=32,
                                             pattern=r'^[a-z][a-z0-9_]*$')]


class CountryMapEntry(ContractModel):
    """One country and its state."""

    code: CountryCode
    state: StateCode


class CountryMapSection(ContractModel):
    """The snapshot's ``country_map``: see the module docstring."""

    countries: list[CountryMapEntry]

    @model_validator(mode='after')
    def _unique_codes(self):
        codes = [entry.code for entry in self.countries]
        if len(codes) != len(set(codes)):
            raise ValueError('country_map lists a country twice')
        return self

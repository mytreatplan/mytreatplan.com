"""The bases of the contract models.

- `ContractModel` (0.7.0): readers' models, so an unknown field is dropped, never an
  error (architecture AD-12: readers ignore unknown fields).
- `WriterModel` (0.8.0): writers' models, so an unknown field is an error. Every event
  type's payload is a closed `WriterModel` (`contracts.payloads`): a writer cannot put a
  field into a central payload that its model does not name.
"""
from pydantic import BaseModel, ConfigDict


class ContractModel(BaseModel):
    """A shape exchanged between the sites. Read with `model_validate` /
    `model_validate_json`; written with `model_dump(mode='json')`."""

    model_config = ConfigDict(extra='ignore', frozen=True)


class WriterModel(BaseModel):
    """A shape a site writes (an event payload): an unknown field is refused
    (``extra='forbid'``). Built with `model_validate`; written with
    `model_dump(mode='json')`."""

    model_config = ConfigDict(extra='forbid', frozen=True)

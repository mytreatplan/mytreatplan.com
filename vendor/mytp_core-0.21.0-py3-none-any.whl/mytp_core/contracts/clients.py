"""The client record events (0.11.0, architecture AD-2, AD-15, AD-18, interface I8): a
regional portal tells the admin site about each doctor (client) registered there.

- ``client.updated`` (`ClientUpdated`): the client's full current state, sent after
  every client write (signup, a change in the portal's Django admin) and on a re-sync::

    {"title": "dr", "first_name": "Ana", "middle_name": "", "last_name": "Ruiz",
     "email": "ana@example.com", "phone": "+34600000000", "country": "ES",
     "home_region": "eu", "active": true, "joined_at": "2026-11-05T10:00:00Z",
     "how_found": "linkedin"}

  ``title`` and ``how_found`` are the portal's choice codes (or empty); ``phone`` is E.164
  or empty; ``country`` ISO 3166-1 alpha-2 (uppercase) or empty; ``home_region`` the
  region that created the account. The free text of "how found: others" is never sent.
- ``client.erased`` (`ClientErased`): the tombstone, an empty payload. The region erased
  the account (AD-18): the admin site deletes its copy.

Both are aggregate kind ``client``: ``aggregate_id`` is the account's ``uid`` and
``aggregate_version`` the account's sync version, so a ``client.updated`` older than the
erasure is ``stale``. Sent in clear over the signed channel; the admin site encrypts the
personal fields with its own keys.

Writers build with `build_payload` (the closed `ClientUpdated` / `ClientErased`);
readers validate with `ClientUpdatedReader` / `ClientErasedReader` (the same rules,
unknown fields dropped: a later release adds fields, epic-doctor-profile).
"""
from typing import Annotated

from pydantic import Field, StrictBool, StringConstraints

from .base import ContractModel, WriterModel
from .events import REGION_PATTERN, UtcTime

CLIENT_UPDATED = 'client.updated'
CLIENT_ERASED = 'client.erased'

# A choice code of the portal (title, how found), or empty.
Code = Annotated[str, StringConstraints(max_length=30, pattern=r'^[a-z0-9_]*$')]
Name = Annotated[str, StringConstraints(max_length=150)]
# What the portal stores (Django's EmailValidator, quoted local parts included): 3 to 254
# characters with a non-empty domain after the last "@"; no other rule.
Email = Annotated[str, StringConstraints(min_length=3, max_length=254,
                                         pattern=r'^[\s\S]*@[^@]+$')]
# E.164: "+" and up to 15 digits, the first 1-9; or empty.
Phone = Annotated[str, StringConstraints(max_length=16, pattern=r'^(\+[1-9][0-9]{1,14})?$')]
Country = Annotated[str, StringConstraints(max_length=2, pattern=r'^([A-Z]{2})?$')]
RegionCode = Annotated[str, Field(pattern=REGION_PATTERN)]


class ClientUpdatedReader(ContractModel):
    """A client's full state, as the admin site reads it (unknown fields dropped)."""

    title: Code
    first_name: Name
    middle_name: Name
    last_name: Name
    email: Email
    phone: Phone
    country: Country
    home_region: RegionCode
    active: StrictBool
    joined_at: UtcTime
    how_found: Code


class ClientErasedReader(ContractModel):
    """The tombstone, as the admin site reads it (no field)."""


class ClientUpdated(WriterModel):
    """The payload of ``client.updated`` a portal writes (closed: the same fields and
    rules as `ClientUpdatedReader`, an unknown field refused)."""

    title: Code
    first_name: Name
    middle_name: Name
    last_name: Name
    email: Email
    phone: Phone
    country: Country
    home_region: RegionCode
    active: StrictBool
    joined_at: UtcTime
    how_found: Code


class ClientErased(WriterModel):
    """The payload of ``client.erased`` a portal writes: empty."""


# The reader model of each client event type.
CLIENT_READERS = {CLIENT_UPDATED: ClientUpdatedReader, CLIENT_ERASED: ClientErasedReader}

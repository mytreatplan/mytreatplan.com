"""The contact message events (0.14.0, architecture AD-18, interface I9): a regional
portal tells the admin site about each message sent through its contact form.

- ``contact_message.updated`` (`ContactMessageUpdated`): the message's full state, sent
  once it is saved and on a re-sync::

    {"first_name": "Ana", "middle_name": "", "surname": "Ruiz",
     "email": "ana@example.com", "phone": "+34 600 000 000", "country": "Spain",
     "aligners": "yes", "club": "", "decision": "no",
     "sent_at": "2026-11-07T10:00:00Z"}

  ``phone`` and ``country`` are the form's free text (the phone: digits, spaces and
  ``+()-.``, at most 32 characters; the country at most 80); names at most 80 characters;
  ``aligners``, ``club`` and ``decision`` are ``yes``, ``no`` or empty. The status of the
  mail to the company inbox is not sent.
- ``contact_message.deleted`` (`ContactMessageDeleted`): the tombstone, an empty payload.
  A staff member deleted the message in the region: the admin site deletes its copy.

Both are aggregate kind ``contact_message``: ``aggregate_id`` is the message's ``uid``
and ``aggregate_version`` its sync version, so an update older than the deletion is
``stale``. Sent in clear over the signed channel; the admin site encrypts the personal
fields with its own keys.

Writers build with `build_payload` (the closed `ContactMessageUpdated` /
`ContactMessageDeleted`); readers validate with `ContactMessageUpdatedReader` /
`ContactMessageDeletedReader` (the same rules, unknown fields dropped).
"""
from typing import Annotated

from pydantic import StringConstraints

from .base import ContractModel, WriterModel
from .clients import Email
from .events import UtcTime

CONTACT_MESSAGE_UPDATED = 'contact_message.updated'
CONTACT_MESSAGE_DELETED = 'contact_message.deleted'

# The contact form's limits (the portal's mytp_publicsite.models).
Name = Annotated[str, StringConstraints(max_length=80)]
# The form's free format: digits, spaces and + ( ) . - only, at most 32 characters.
Phone = Annotated[str, StringConstraints(max_length=32, pattern=r'^[0-9 +().\-]*$')]
Country = Annotated[str, StringConstraints(max_length=80)]
# A yes/no answer of the form, or empty (not answered).
Answer = Annotated[str, StringConstraints(max_length=3, pattern=r'^(yes|no)?$')]


class ContactMessageUpdatedReader(ContractModel):
    """A contact message's full state, as the admin site reads it (unknown fields
    dropped)."""

    first_name: Name
    middle_name: Name
    surname: Name
    email: Email
    phone: Phone
    country: Country
    aligners: Answer
    club: Answer
    decision: Answer
    sent_at: UtcTime


class ContactMessageDeletedReader(ContractModel):
    """The tombstone, as the admin site reads it (no field)."""


class ContactMessageUpdated(WriterModel):
    """The payload of ``contact_message.updated`` a portal writes (closed: the same fields
    and rules as `ContactMessageUpdatedReader`, an unknown field refused)."""

    first_name: Name
    middle_name: Name
    surname: Name
    email: Email
    phone: Phone
    country: Country
    aligners: Answer
    club: Answer
    decision: Answer
    sent_at: UtcTime


class ContactMessageDeleted(WriterModel):
    """The payload of ``contact_message.deleted`` a portal writes: empty."""


# The reader model of each contact message event type.
CONTACT_MESSAGE_READERS = {CONTACT_MESSAGE_UPDATED: ContactMessageUpdatedReader,
                           CONTACT_MESSAGE_DELETED: ContactMessageDeletedReader}

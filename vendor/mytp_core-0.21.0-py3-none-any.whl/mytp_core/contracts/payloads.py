"""The event payload registry (0.8.0, architecture AD-3, AD-12, AD-23): every event type a
site may write has one closed payload model (a `WriterModel`, ``extra='forbid'``),
registered here by its type.

- `register_payload(type, model)` (or ``@register_payload(type)`` on the class) adds a
  type; a type is registered once, and its name follows the envelope's type form
  (``<entity>.<past-tense verb>``, dotted lowercase).
- `payload_model_for(type)` is the type's model, or None for a type this version does
  not know (a reader skips such an event, AD-12).
- `build_payload(type, data)` is what a writer stores and sends: `data` validated by the
  type's model, dumped with ``model_dump(mode='json')`` and passed through
  `check_central_payload`. An unregistered type raises `UnknownEventType`; a payload the
  model or the checks refuse raises `InvalidPayload` or `ContractViolation` (all three
  are ValueError). The error text names fields and rules, never values.

The registered types: ``client.updated`` (`ClientUpdated`) and ``client.erased``
(`ClientErased`), the client record events of epic-admin-interface entry 8
(`contracts.clients`, 0.11.0); ``contact_message.updated`` (`ContactMessageUpdated`) and
``contact_message.deleted`` (`ContactMessageDeleted`), the contact message events of
entry 9 (`contracts.contact_messages`, 0.14.0). The staging-only ``sample.recorded`` of
entry 3 is gone.
"""
import re
import typing

from pydantic import BaseModel, ValidationError

from .base import WriterModel
from .checks import check_central_payload
from .clients import CLIENT_ERASED, CLIENT_UPDATED, ClientErased, ClientUpdated
from .contact_messages import (CONTACT_MESSAGE_DELETED, CONTACT_MESSAGE_UPDATED,
                               ContactMessageDeleted, ContactMessageUpdated)
from .events import TYPE_PATTERN

TYPE_RE = re.compile(TYPE_PATTERN)

_REGISTRY = {}


class UnknownEventType(ValueError):
    """The event type has no registered payload model."""

    def __init__(self, event_type):
        self.event_type = event_type
        super().__init__(f'no payload model is registered for the event type '
                         f'{event_type!r}')


class InvalidPayload(ValueError):
    """The type's payload model refused the data. `violations` lists (path, error code)
    pairs: the path keeps the models' field names and list indexes and shows any other
    part (a dict key, a union tag) as HIDDEN_PART; the code is pydantic's error type.
    Neither holds a value."""

    def __init__(self, event_type, violations):
        self.event_type = event_type
        self.violations = list(violations)
        super().__init__(f'{event_type}: ' + '; '.join(
            f'{path}: {reason}' for path, reason in self.violations))


# A path part that is not a field name of the models (a dict key, a union tag) is shown
# as this, as it may be a value.
HIDDEN_PART = '<key>'
_OPEN_TYPES = (typing.Any, object, dict, list, tuple, set, frozenset, typing.Dict,
               typing.List, typing.Tuple, typing.Set, typing.FrozenSet)


def _check_closed(annotation, where, seen):
    """TypeError when `annotation` (a model or a field type) leaves anything open: a
    nested model without extra='forbid', Any, or an untyped dict, list, tuple or set."""
    if isinstance(annotation, type) and issubclass(annotation, BaseModel):
        if annotation in seen:
            return
        seen.add(annotation)
        if annotation.model_config.get('extra') != 'forbid':
            raise TypeError(f'{where}: a nested model must be closed (extra="forbid")')
        for name, field in annotation.model_fields.items():
            _check_closed(field.annotation, f'{where}.{name}', seen)
        return
    if any(annotation is open_type for open_type in _OPEN_TYPES):
        raise TypeError(f'{where}: an open type (Any, or an untyped dict, list, tuple or '
                        f'set) is not allowed in a payload model')
    origin = typing.get_origin(annotation)
    if origin is typing.Literal:
        return
    args = typing.get_args(annotation)
    if origin is typing.Annotated:
        args = args[:1]
    for arg in args:
        if arg is Ellipsis or arg is type(None):
            continue
        _check_closed(arg, where, seen)


def _field_names(annotation, seen):
    """Every field name of the models reachable from `annotation`."""
    names = set()
    if isinstance(annotation, type) and issubclass(annotation, BaseModel):
        if annotation not in seen:
            seen.add(annotation)
            for name, field in annotation.model_fields.items():
                names.add(name)
                names |= _field_names(field.annotation, seen)
        return names
    if typing.get_origin(annotation) is typing.Literal:
        return names
    for arg in typing.get_args(annotation):
        names |= _field_names(arg, seen)
    return names


def _safe_part(part, names):
    if isinstance(part, int) or part in names:
        return str(part)
    return HIDDEN_PART


def register_payload(event_type, model=None):
    """Register `model` (a `WriterModel` subclass) as the payload of `event_type`; returns
    the model. Without `model`, a class decorator. ValueError for a malformed or already
    registered type, TypeError for a model that is not closed all the way down (not a
    `WriterModel`, a nested model without extra='forbid', Any, or an untyped dict, list,
    tuple or set anywhere in its fields)."""
    def register(model):
        if not isinstance(event_type, str) or len(event_type) > 100 \
                or not TYPE_RE.fullmatch(event_type):
            raise ValueError(f'{event_type!r} is not an event type (dotted lowercase, '
                             f'<entity>.<past-tense verb>)')
        if not (isinstance(model, type) and issubclass(model, WriterModel)
                and model.model_config.get('extra') == 'forbid'):
            raise TypeError('a payload model is a WriterModel subclass (extra="forbid")')
        _check_closed(model, model.__name__, set())
        if event_type in _REGISTRY:
            raise ValueError(f'the event type {event_type!r} is already registered')
        _REGISTRY[event_type] = model
        return model

    return register if model is None else register(model)


def payload_model_for(event_type):
    """The payload model registered for `event_type`, or None."""
    return _REGISTRY.get(event_type)


def registered_types():
    """The registered event types, sorted."""
    return sorted(_REGISTRY)


def build_payload(event_type, data):
    """`data` (a dict, or an instance of the type's model) as the JSON-ready payload a
    writer stores and sends; see the module docstring for the errors."""
    model = payload_model_for(event_type)
    if model is None:
        raise UnknownEventType(event_type)
    if isinstance(data, model):
        # Re-validate: model_construct / model_copy(update=...) skip validation.
        data = data.model_dump()
    try:
        payload = model.model_validate(data).model_dump(mode='json')
    except ValidationError as exc:
        # pydantic's messages and paths can quote values (validator messages, dict keys,
        # union tags): report the error code and the models' field names only.
        names = _field_names(model, set())
        raise InvalidPayload(event_type, [
            ('.'.join(['payload', *(_safe_part(part, names) for part in error['loc'])]),
             error['type'])
            for error in exc.errors(include_input=False, include_url=False,
                                    include_context=False)]) from None
    return check_central_payload(payload)


# --- The registered types ---------------------------------------------------------------

register_payload(CLIENT_UPDATED, ClientUpdated)
register_payload(CLIENT_ERASED, ClientErased)
register_payload(CONTACT_MESSAGE_UPDATED, ContactMessageUpdated)
register_payload(CONTACT_MESSAGE_DELETED, ContactMessageDeleted)

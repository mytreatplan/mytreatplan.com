"""An amount on the wire (0.7.0, architecture AD-6): ``{"amount": "123.45", "currency":
"EUR"}``. The amount is a JSON string of a decimal with exactly two places, read as a
`Decimal`; a JSON number (int or float) is refused, so a float never carries money. The
currency is three uppercase letters (ISO 4217 form). The `Money` type itself (arithmetic,
rounding) is `mytp_core.money` (0.9.0), which converts to and from this shape."""
import re
from decimal import Decimal, InvalidOperation
from typing import Annotated

from pydantic import BeforeValidator, Field, PlainSerializer, WithJsonSchema

from .base import ContractModel

# No leading zeros, at most 15 integer digits, exactly 2 places; never "-0.00".
AMOUNT_PATTERN = r'^(?!-0\.00$)-?(0|[1-9][0-9]{0,14})\.[0-9]{2}$'
AMOUNT_RE = re.compile(AMOUNT_PATTERN)
CURRENCY_PATTERN = r'^[A-Z]{3}$'


def _decimal_amount(value):
    if isinstance(value, Decimal):
        # A writer's Decimal: finite, with exactly two places (quantized to 0.01).
        if not value.is_finite() or value.as_tuple().exponent != -2:
            raise ValueError('an amount is a Decimal with exactly 2 decimal places')
        value = format(value, 'f')
    if not isinstance(value, str):
        raise ValueError('an amount is a string such as "123.45", never a number')
    if not AMOUNT_RE.fullmatch(value):
        raise ValueError('an amount is a decimal string with exactly 2 places, e.g. "123.45"')
    try:
        return Decimal(value)
    except InvalidOperation:  # pragma: no cover - the pattern admits only valid decimals
        raise ValueError('an amount is a decimal string') from None


DecimalAmount = Annotated[
    Decimal,
    BeforeValidator(_decimal_amount),
    PlainSerializer(lambda value: format(value, 'f'), return_type=str, when_used='json'),
    WithJsonSchema({'type': 'string', 'pattern': AMOUNT_PATTERN,
                    'description': 'A decimal with exactly 2 places, e.g. "123.45".'}),
]


class Amount(ContractModel):
    amount: DecimalAmount
    currency: str = Field(pattern=CURRENCY_PATTERN, description='ISO 4217 code, e.g. EUR.')

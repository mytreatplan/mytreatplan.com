"""The provider costs section of the configuration snapshot (0.19.0, architecture AD-3,
AD-6; epic-catalogue entry 4): what the company pays its providers (labs, aligner makers,
services) for each of their products, over time, which a regional portal will need for
the cost at order time (epic-payments) and the links to our products (epic-catalogue
entry 5). It carries no provider: no name, no fiscal or payment detail.

    {"products": [{"id": "<uuid>", "code": "DM-SCAN", "currency": "EUR", "active": true,
                   "costs": [{"valid_from": "2026-01-01", "valid_to": "2026-06-30",
                              "face": "100.00", "discounted": "100.00"},
                             {"valid_from": "2026-07-01", "valid_to": null,
                              "face": "100.00", "discounted": "90.00"}]}]}

- Every provider product is listed, inactive ones too (``active: false``: the product or
  its provider is inactive); ids are UUID strings, each once.
- ``code`` is the provider's code for the product (1 to 64 characters: letters, digits
  and ``. _ / -``, starting with a letter or digit). It is not unique across providers:
  readers identify a product by its id.
- ``currency``: three uppercase letters (ISO 4217 form), the same for every cost of the
  product. The admin site writes only `mytp_core.money.CURRENCIES` (EUR, AED, USD); a
  reader that needs money uses `ProviderCostProduct.cost_money_at`, which gives None for
  a currency it does not know (a later release may add one).
- ``costs``: dated price ranges, ordered by ``valid_from``. ``valid_from`` is an ISO date
  (``YYYY-MM-DD``); ``valid_to`` is an ISO date or null (open-ended) and inclusive, never
  before ``valid_from``. Two ranges of one product never overlap; gaps are allowed (no
  cost on those dates). ``face`` and ``discounted`` are decimal strings with exactly 2
  places in the product's currency, never negative, ``discounted`` never above ``face``
  (it equals ``face`` when there is no discount). The cost on a date is the ``discounted``
  price of the range holding it (`ProviderCostProduct.cost_at`), or none.

The rules within and across rows (ids once; a range's dates in order; ranges in order and
never overlapping; ``discounted`` <= ``face``; amounts never negative; the code's form)
are part of the reader contract: a snapshot that breaks one is refused whole
(`invalid_body`), and the reader keeps its last good snapshot. Relaxing any of them is a
breaking change and needs a `min_reader` bump.

The section is optional in the snapshot (`ConfigSnapshot.provider_costs`): an admin site
older than 0.19.0 sends none, and a portal then holds no costs.
"""
import re
from datetime import date, datetime
from typing import Annotated

from pydantic import (BeforeValidator, PlainSerializer, StrictBool, StringConstraints,
                      WithJsonSchema, model_validator)

from .amounts import CURRENCY_PATTERN, DecimalAmount
from .base import ContractModel
from .events import CanonicalUuid

CODE_PATTERN = r'^[A-Za-z0-9][A-Za-z0-9._/-]{0,63}$'
ProviderProductCode = Annotated[str, StringConstraints(min_length=1, max_length=64,
                                                       pattern=CODE_PATTERN)]
Currency = Annotated[str, StringConstraints(pattern=CURRENCY_PATTERN)]

DATE_PATTERN = r'^[0-9]{4}-[0-9]{2}-[0-9]{2}$'
DATE_RE = re.compile(DATE_PATTERN)


def _iso_date(value):
    if isinstance(value, datetime):
        raise ValueError('a date is YYYY-MM-DD, without a time')
    if isinstance(value, date):
        return value
    if not isinstance(value, str) or not DATE_RE.fullmatch(value):
        raise ValueError('a date is a string YYYY-MM-DD')
    try:
        return date.fromisoformat(value)
    except ValueError:
        raise ValueError('a date is a valid YYYY-MM-DD') from None


IsoDate = Annotated[
    date,
    BeforeValidator(_iso_date),
    PlainSerializer(lambda value: value.isoformat(), return_type=str, when_used='json'),
    WithJsonSchema({'type': 'string', 'format': 'date', 'pattern': DATE_PATTERN,
                    'description': 'An ISO 8601 date, YYYY-MM-DD.'}),
]


class ProviderCost(ContractModel):
    """One dated price range of a provider product: from ``valid_from`` to ``valid_to``
    (inclusive; null: open-ended)."""

    valid_from: IsoDate
    valid_to: IsoDate | None = None
    face: DecimalAmount
    discounted: DecimalAmount

    @model_validator(mode='after')
    def _consistent(self):
        if self.valid_to is not None and self.valid_to < self.valid_from:
            raise ValueError('a cost range ends before it starts')
        if self.face < 0 or self.discounted < 0:
            raise ValueError('a cost is never negative')
        if self.discounted > self.face:
            raise ValueError('a discounted price is never above the face price')
        return self

    def holds(self, day):
        return self.valid_from <= day and (self.valid_to is None or day <= self.valid_to)


class ProviderCostProduct(ContractModel):
    """A provider product (no provider details), with its dated costs."""

    id: CanonicalUuid
    code: ProviderProductCode
    currency: Currency
    active: StrictBool
    costs: list[ProviderCost]

    @model_validator(mode='after')
    def _ranges_in_order_without_overlap(self):
        for earlier, later in zip(self.costs, self.costs[1:]):
            if later.valid_from <= earlier.valid_from:
                raise ValueError('cost ranges are listed by valid_from, each date once')
            if earlier.valid_to is None or earlier.valid_to >= later.valid_from:
                raise ValueError('two cost ranges of one provider product overlap')
        return self

    def cost_at(self, day):
        """The cost on `day` (a date): the discounted price (a Decimal) of the range
        holding it, or None (a gap, or before the first range)."""
        for cost in self.costs:
            if cost.holds(day):
                return cost.discounted
        return None

    def cost_money_at(self, day):
        """The cost on `day` as `mytp_core.money.Money`, or None: a gap, or a currency
        outside `mytp_core.money.CURRENCIES` (one this release does not know; the reader
        skips the product rather than guess)."""
        # Imported here: mytp_core.money imports this package (contracts.amounts).
        from ..money import CURRENCIES, Money
        if self.currency not in CURRENCIES:
            return None
        amount = self.cost_at(day)
        return None if amount is None else Money(amount, self.currency)


class ProviderCostsSection(ContractModel):
    """The snapshot's ``provider_costs``: see the module docstring."""

    products: list[ProviderCostProduct]

    @model_validator(mode='after')
    def _unique_ids(self):
        ids = [product.id for product in self.products]
        if len(ids) != len(set(ids)):
            raise ValueError('provider_costs lists an id twice')
        return self

    def product(self, product_id):
        """The listed product of this id (a UUID or its string), or None."""
        wanted = str(product_id)
        return next((product for product in self.products if str(product.id) == wanted),
                    None)


"""Contract checks on central payloads (0.7.0, architecture AD-2, AD-5, AD-6, AD-23): what
a portal sends to the admin site (events, the accounting feed) never carries a float,
patient data or a file.

These checks are a safety net: the guarantee is that every event type defines its payload
as a closed writer-side model (`extra='forbid'`) whose output also passes these checks.

`check_central_payload(obj)` walks a payload and raises `ContractViolation` naming every
offending path (``payload.lines[0].patient_name``) when it finds:

- a value that is not JSON-shaped: only dict, list, tuple, str, int, bool and None are
  walked; anything else (a float, a Decimal, a set, a model, a dataclass, a mapping that
  is not a dict) is refused. Amounts travel as `{"amount": "123.45", "currency": "EUR"}`;
- nesting deeper than `MAX_DEPTH` containers, or a cycle;
- an object with both ``amount`` and ``currency`` keys that is not a valid `Amount`;
- a patient field: any key starting with ``patient`` but ``patient_code``; under
  ``patient`` or ``patients``, anything but an object (or a list of objects) holding only
  ``patient_code``; and ``patient_code`` anywhere that is not a string in the AD-5 form
  (``EU-7K3QX9MD``). Doctor and clinic names stay allowed;
- a file: a key in `FILE_FIELDS`; a string that holds a data URI (by its grammar,
  ``data:<type>/<subtype>[;...],`` anywhere), a link to an object-storage host
  (`STORAGE_HOST_SUFFIXES`, `STORAGE_HOSTS`), a signed link (X-Amz-Signature/Credential,
  AWSAccessKeyId with Signature, X-Goog-Signature/Credential; any case, also
  percent-encoded), or 200+ characters of base64 only; a string that is still changing
  after `MAX_UNQUOTE_ROUNDS` rounds of percent-decoding.

Keys compare normalised (`normalise_key`): NFKC, invisible (format) characters removed,
stripped, lowercased, without ``_``, ``-``, ``.`` and whitespace (``patientName``,
``patient.name`` and ``downloadUrl`` match). A later need for a file reference centrally
(e.g. an invoice PDF) is an explicit, reviewed entry in this module in a new mytp-core
release, never a bypass in a site. The envelope (`events.EventEnvelope`) runs this on
`payload` when it reads it and again when it dumps it.
"""
import re
import unicodedata
from urllib.parse import unquote

from pydantic import ValidationError

from .amounts import Amount

PATIENT_PREFIX = 'patient'
PATIENT_CODE_KEY = 'patient_code'
PATIENT_OBJECT_KEYS = frozenset({'patient', 'patients'})
PATIENT_CODE_RE = re.compile(r'^[A-Z]{2}-[0-9A-Z]{8}$')
# The decision's named patient fields (all covered by the `patient` prefix rule).
PATIENT_FIELDS = frozenset({
    'patient_name', 'patient_first_name', 'patient_last_name', 'patient_photo',
    'patient_comments',
})

FILE_FIELDS = frozenset({
    'file', 'files', 'filename', 'file_name', 'attachment', 'attachments', 'upload',
    'uploads', 'object_key', 'storage_key', 'download_url', 'presigned_url',
})
STORAGE_HOST_SUFFIXES = ('amazonaws.com', 'digitaloceanspaces.com', 'cloud.ovh.net')
STORAGE_HOSTS = frozenset({'storage.googleapis.com'})

MAX_DEPTH = 64
MAX_UNQUOTE_ROUNDS = 20
MIN_BASE64_LENGTH = 200

_KEY_NOISE_RE = re.compile(r'[_\-.\s]')


def _without_format_chars(text):
    if text.isascii():
        return text
    return ''.join(char for char in text if unicodedata.category(char) != 'Cf')


def normalise_key(key):
    """A key as the checks compare it: NFKC, format characters removed, stripped,
    lowercased, without ``_``, ``-``, ``.`` and whitespace."""
    text = str.__str__(key)  # a plain str: a subclass's own strip/lower never apply
    text = _without_format_chars(unicodedata.normalize('NFKC', text))
    return _KEY_NOISE_RE.sub('', str.lower(str.strip(text)))


_PATIENT_PREFIX = normalise_key(PATIENT_PREFIX)
_PATIENT_CODE = normalise_key(PATIENT_CODE_KEY)
_PATIENT_OBJECTS = frozenset(map(normalise_key, PATIENT_OBJECT_KEYS))
_FILE_KEYS = frozenset(map(normalise_key, FILE_FIELDS))

_DATA_URI_RE = re.compile(r'data:[a-z0-9.+-]{1,64}/[a-z0-9.+-]{1,64}(;[^,]{0,200})?,',
                          re.IGNORECASE)
_SIGNED_RE = re.compile(r'x-(amz|goog)-(signature|credential)', re.IGNORECASE)
_AWS_KEY_RE = re.compile(r'awsaccesskeyid', re.IGNORECASE)
_SIGNATURE_RE = re.compile(r'signature', re.IGNORECASE)
_URL_HOST_RE = re.compile(r'https?://(?:[^\s/?#@]{0,255}@)?([^\s/?#:@]{1,255})',
                          re.IGNORECASE)
_BASE64_RE = re.compile(r'[A-Za-z0-9+/=\r\n]{%d,}' % MIN_BASE64_LENGTH)


class ContractViolation(ValueError):
    """A payload breaks a contract rule. `violations` lists (path, reason) pairs."""

    def __init__(self, violations):
        self.violations = list(violations)
        super().__init__('; '.join(f'{path}: {reason}' for path, reason in self.violations))


def _decoded(text):
    """`text` percent-decoded until it stops changing; None when it still changes after
    MAX_UNQUOTE_ROUNDS rounds."""
    for _ in range(MAX_UNQUOTE_ROUNDS):
        decoded = unquote(text)
        if decoded == text:
            return text
        text = decoded
    return None


def _storage_host(host):
    host = host.lower().rstrip('.')
    return host in STORAGE_HOSTS or any(
        host == suffix or host.endswith('.' + suffix) for suffix in STORAGE_HOST_SUFFIXES)


def _file_like_string(value):
    text = _without_format_chars(str.__str__(value))
    decoded = _decoded(text)
    if decoded is None:
        return 'a string percent-encoded too many times is not allowed'
    for candidate in (text, decoded):
        if _DATA_URI_RE.search(candidate):
            return 'a data: URI (a file) is not allowed centrally'
        if _SIGNED_RE.search(candidate) or (_AWS_KEY_RE.search(candidate)
                                            and _SIGNATURE_RE.search(candidate)):
            return 'a signed object-storage link is not allowed centrally'
        if any(_storage_host(host) for host in _URL_HOST_RE.findall(candidate)):
            return 'a link to object storage is not allowed centrally'
        if _BASE64_RE.fullmatch(candidate.strip()):
            return 'base64 content (a file) is not allowed centrally'
    return None


_NOT_A_PATIENT = 'a patient is an object with patient_code only'


class _Walk:
    def __init__(self):
        self.found = []
        self._ancestors = set()
        self._done = set()

    def _enter(self, value, path, depth, mode):
        """Whether to walk into the container `value` (reports too deep and cycles)."""
        if depth > MAX_DEPTH:
            self.found.append((path, f'nested deeper than {MAX_DEPTH} levels'))
            return False
        if id(value) in self._ancestors:
            self.found.append((path, 'a cycle is not allowed'))
            return False
        # A container shared by several paths is checked once per mode.
        return (id(value), mode) not in self._done

    def _walk_container(self, value, path, depth, mode, body):
        if not self._enter(value, path, depth, mode):
            return
        self._ancestors.add(id(value))
        try:
            body()
        finally:
            self._ancestors.discard(id(value))
            self._done.add((id(value), mode))

    def patient_code(self, value, path):
        if not (isinstance(value, str) and PATIENT_CODE_RE.fullmatch(str.__str__(value))):
            self.found.append((path, 'a patient code is a string such as "EU-7K3QX9MD"'))

    def patient(self, value, path, depth):
        """The value under a `patient`/`patients` key: an object (or a list of objects)
        holding at most `patient_code`."""
        if type(value) in (list, tuple):
            def items():
                for index, item in enumerate(value):
                    if type(item) is dict:
                        self.patient(item, f'{path}[{index}]', depth + 1)
                    else:
                        self.found.append((f'{path}[{index}]', _NOT_A_PATIENT))
            self._walk_container(value, path, depth, 'patient', items)
            return
        if type(value) is not dict:
            self.found.append((path, _NOT_A_PATIENT))
            return

        def keys():
            for key, item in value.items():
                child = f'{path}.{key}'
                if not isinstance(key, str) or normalise_key(key) != _PATIENT_CODE:
                    self.found.append((child, 'only patient_code is allowed in a patient '
                                              'object'))
                else:
                    self.patient_code(item, child)
        self._walk_container(value, path, depth, 'patient', keys)

    def value(self, value, path, depth):
        if value is None or isinstance(value, (bool, int)):
            return
        if isinstance(value, float):
            self.found.append((path, 'a float is not allowed (amounts are decimal strings)'))
            return
        if isinstance(value, str):
            reason = _file_like_string(value)
            if reason:
                self.found.append((path, reason))
            return
        if type(value) in (list, tuple):
            def items():
                for index, item in enumerate(value):
                    self.value(item, f'{path}[{index}]', depth + 1)
            self._walk_container(value, path, depth, 'value', items)
            return
        if type(value) is not dict:
            self.found.append((path, f'a {type(value).__name__} is not allowed (JSON values '
                                     f'only)'))
            return
        self._walk_container(value, path, depth, 'value',
                             lambda: self._dict(value, path, depth))

    def _dict(self, value, path, depth):
        if 'amount' in value and 'currency' in value:
            try:
                Amount.model_validate(value)
            except ValidationError:
                self.found.append((path, 'an amount is {"amount": "123.45", "currency": '
                                         '"EUR"}'))
        for key, item in value.items():
            child = f'{path}.{key}'
            if not isinstance(key, str):
                self.found.append((child, 'a key is a string'))
                continue
            name = normalise_key(key)
            if name == _PATIENT_CODE:
                self.patient_code(item, child)
            elif name in _PATIENT_OBJECTS:
                self.patient(item, child, depth + 1)
            elif name.startswith(_PATIENT_PREFIX):
                self.found.append((child, 'a patient field is not allowed centrally'))
            elif name in _FILE_KEYS:
                self.found.append((child, 'a file field is not allowed centrally'))
            else:
                self.value(item, child, depth + 1)


def find_violations(obj, path='payload'):
    """The (path, reason) pairs of every rule `obj` breaks (empty when it is clean)."""
    walk = _Walk()
    walk.value(obj, path, 1)
    return walk.found


def check_central_payload(obj, path='payload'):
    """`obj` unchanged when it may go centrally, else ContractViolation naming the paths."""
    found = find_violations(obj, path)
    if found:
        raise ContractViolation(found)
    return obj

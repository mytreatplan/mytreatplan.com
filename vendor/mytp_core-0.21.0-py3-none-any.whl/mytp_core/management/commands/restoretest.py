"""Restore the site's latest backup into a scratch database and check it (0.18.0, AD-24).

    python manage.py restoretest

Run weekly by the site's `restoretest` job in its jobs.conf (through `manage.py runjob`,
so a failed or missed run raises a Sentry alert). It:

1. checks the settings: the BACKUP_* bucket settings, BACKUP_PREFIX, MYTP_BACKUP_BASENAME,
   the scratch database RESTORE_TEST_DATABASE (a DATABASES-style dict whose NAME ends in
   `_restore_test`, with its own USER: never the site's database or user), the tools
   (`age`, `pg_restore` not older than the scratch server) and the temp directory
   (BACKUP_TMP_DIR, 0700); it refuses a scratch role that is a superuser or may create
   roles or databases (never the service admin);
2. reads the restore identity file (RESTORE_AGE_IDENTITY_FILE; see
   mytp_core.restore_identity) and checks its public key is BACKUP_AGE_RESTORE_RECIPIENT;
3. empties the scratch database if a killed run left anything in it (it drops its
   schemas and creates `public` again), and refuses to go on unless it is then empty;
4. lists the bucket under `<BACKUP_PREFIX><MYTP_BACKUP_BASENAME>-` and takes the newest
   object whose whole name is `<BACKUP_PREFIX><basename>-<yyyymmddThhmmssZ>.dump.age`
   (prefix **and** basename, so another site's dump in a shared prefix is never taken);
   none, the newest older than RESTORE_TEST_MAX_AGE_DAYS (default 8), or one dated more
   than an hour in the future, fails;
5. downloads it (ciphertext only) into an open temp file in BACKUP_TMP_DIR and checks
   its size;
6. unwraps the restore identity through the KMS, in memory only, and runs
   `age --decrypt --identity /dev/fd/<n> <file> | pg_restore --no-owner --no-privileges
   --single-transaction --exit-on-error --dbname <scratch>`: the identity goes to `age`
   through a pipe, never a file, and the plain dump only through the second pipe;
7. checks the restored database for this site: `django_migrations` has rows, every one
   of them is a migration the live database also has (a dump of another site fails
   here), and the site's user table (RESTORE_TEST_USER_TABLE, default the
   AUTH_USER_MODEL's table) exists;
8. empties the scratch database and removes the downloaded file, whatever happened.

Success prints one line: the site, the dump's time and age, its size, the migration and
user counts. A failure raises one CommandError `restoretest: site=<SITE> code=<code>:
<detail>` (runjob sends it to Sentry once). The codes: settings, tools, tmp-dir,
identity, scratch-db, list, no-dump, stale-dump, download, decrypt, restore, check,
cleanup, interrupted. No message holds a password, a key, the identity, an endpoint or
anything read from the dump (pg_restore's and age's own output is never shown: it can
quote rows); the original exceptions are not chained. When pg_restore fails first, `age`
dies of a broken pipe: that is reported as `restore`, not `decrypt`.

The PG* variables of the environment are ignored: the scratch connection and pg_restore
use RESTORE_TEST_DATABASE only. Python cannot wipe memory: the plain identity is dropped
(`del`) once `age` has it, not zeroed.

It never deletes or writes objects in the bucket.
"""
import contextlib
import os
import re
import shutil
import signal
import subprocess
import tempfile
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

from django.conf import settings
from django.core.management.base import BaseCommand, CommandError

from mytp_core import restore_identity
from mytp_core.management.commands import backupdb

S3_SETTINGS = ('BACKUP_S3_ENDPOINT', 'BACKUP_S3_REGION', 'BACKUP_S3_BUCKET',
               'BACKUP_S3_ACCESS_KEY', 'BACKUP_S3_SECRET_KEY', 'BACKUP_PREFIX')
DEFAULT_MAX_AGE_DAYS = 8
# \Z, never $: `$` also matches before a trailing newline.
SCRATCH_NAME_RE = re.compile(r'\A[a-z0-9_]+_restore_test\Z')
TABLE_RE = re.compile(r'\A[a-z_][a-z0-9_]{0,62}\Z')
# A dump dated further ahead than this (clock skew aside) is refused.
FUTURE_SKEW = timedelta(hours=1)
PG_RESTORE_ARGS = ('--no-owner', '--no-privileges', '--single-transaction', '--exit-on-error')
_STAMP_FORMAT = '%Y%m%dT%H%M%SZ'
_VERSION_RE = re.compile(r'\(PostgreSQL\)\s+(\d+)')


class Interrupted(BaseException):
    """SIGTERM (systemd stopping a run past its timeout). A BaseException, so no
    `except Exception` around a step can swallow it; run_test turns it into the
    `interrupted` failure after the clean-up."""


class Failure(Exception):
    def __init__(self, code, detail):
        self.code = code
        self.detail = detail
        super().__init__(f'{code}: {detail}')


# --- seams the tests replace -------------------------------------------------------------

def make_s3_client():
    return backupdb.make_s3_client()


def live_migrations():
    """(app, name) of every migration applied to the site's own database."""
    from django.db import connection
    from django.db.migrations.recorder import MigrationRecorder

    return set(MigrationRecorder(connection).migration_qs.values_list('app', 'name'))


def open_scratch_database(db):
    return ScratchDatabase(db)


# --- the scratch database ----------------------------------------------------------------

def _db_error(exc):
    """A failed database call, by class and SQLSTATE only (messages can quote values)."""
    sqlstate = getattr(exc, 'sqlstate', None)
    return f'{type(exc).__name__}{f" {sqlstate}" if sqlstate else ""}'


@contextlib.contextmanager
def _without_pg_environment():
    """Hide the PG* variables while libpq connects (PGSERVICE, PGHOSTADDR, PGOPTIONS...
    would otherwise fill in what RESTORE_TEST_DATABASE leaves out)."""
    saved = {k: os.environ.pop(k) for k in [k for k in os.environ if k.startswith('PG')]}
    try:
        yield
    finally:
        os.environ.update(saved)


class ScratchDatabase:
    """The scratch database through psycopg (autocommit), as the restore user."""

    def __init__(self, db):
        import psycopg

        options = db.get('OPTIONS') or {}
        params = {
            'host': db.get('HOST'), 'port': db.get('PORT'), 'user': db.get('USER'),
            'password': db.get('PASSWORD'), 'dbname': db.get('NAME'),
            'sslmode': options.get('sslmode'), 'sslrootcert': options.get('sslrootcert'),
        }
        params = {k: str(v) for k, v in params.items() if v not in (None, '')}
        with _without_pg_environment():
            self.conn = psycopg.connect(**params, connect_timeout=30, autocommit=True,
                                        application_name='mytp-restoretest')

    def _rows(self, query, args=None):
        with self.conn.cursor() as cur:
            cur.execute(query, args)
            return cur.fetchall() if cur.description else []

    def server_major(self):
        return self.conn.info.server_version // 10000

    def role_flags(self):
        """The scratch role's powers that must all be off."""
        row = self._rows('SELECT rolsuper, rolcreaterole, rolcreatedb FROM pg_roles '
                         'WHERE rolname = current_user')[0]
        return {'superuser': row[0], 'createrole': row[1], 'createdb': row[2]}

    def relation_count(self):
        return self._rows(
            "SELECT count(*) FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace "
            "WHERE n.nspname NOT IN ('pg_catalog', 'information_schema') "
            "AND n.nspname !~ '^pg_(toast|temp)' AND c.relkind IN ('r', 'p', 'v', 'm', 'S', 'f')"
        )[0][0]

    def reset(self):
        """Drop every non-system schema (everything a restore made), then create
        `public` again."""
        from psycopg import sql

        names = [row[0] for row in self._rows(
            "SELECT nspname FROM pg_namespace WHERE nspname !~ '^pg_' "
            "AND nspname <> 'information_schema'")]
        for name in names:
            self._rows(sql.SQL('DROP SCHEMA {} CASCADE').format(sql.Identifier(name)))
        self._rows('CREATE SCHEMA public')

    def migrations(self):
        """(app, name) of each restored migration, or None without the table."""
        if self._rows("SELECT to_regclass('public.django_migrations')")[0][0] is None:
            return None
        return {(app, name) for app, name in self._rows('SELECT app, name FROM django_migrations')}

    def count_rows(self, table):
        """Rows in public.<table>, or None without it."""
        from psycopg import sql

        if self._rows('SELECT to_regclass(%s)', [f'public.{table}'])[0][0] is None:
            return None
        return self._rows(sql.SQL('SELECT count(*) FROM public.{}').format(
            sql.Identifier(table)))[0][0]

    def close(self):
        self.conn.close()


# --- helpers -----------------------------------------------------------------------------

def scratch_settings():
    return dict(getattr(settings, 'RESTORE_TEST_DATABASE', None) or {})


def user_table():
    configured = str(getattr(settings, 'RESTORE_TEST_USER_TABLE', '') or '').strip()
    if configured:
        return configured
    from django.contrib.auth import get_user_model

    return get_user_model()._meta.db_table


def max_age():
    return timedelta(days=int(getattr(settings, 'RESTORE_TEST_MAX_AGE_DAYS', 0)
                              or DEFAULT_MAX_AGE_DAYS))


def dump_name_re(prefix, basename):
    return re.compile(rf'\A{re.escape(prefix)}{re.escape(basename)}-(\d{{8}}T\d{{6}}Z)'
                      rf'{re.escape(backupdb.OBJECT_SUFFIX)}\Z')


def newest_dump(objects, prefix, basename):
    """(key, size, when) of the newest of `objects` (dicts with Key and Size) named
    `<prefix><basename>-<stamp>.dump.age`, or None."""
    pattern = dump_name_re(prefix, basename)
    best = None
    for obj in objects:
        match = pattern.match(obj.get('Key', ''))
        if not match:
            continue
        try:
            when = datetime.strptime(match.group(1), _STAMP_FORMAT).replace(tzinfo=timezone.utc)
        except ValueError:
            continue
        if best is None or when > best[2]:
            best = (obj['Key'], int(obj.get('Size') or 0), when)
    return best


class Command(BaseCommand):
    help = ("Restore the site's latest backup into its scratch database "
            "(RESTORE_TEST_DATABASE), check it and empty the scratch database again.")

    def handle(self, **options):
        site = settings.SITE
        start = time.monotonic()
        previous = None
        if threading.current_thread() is threading.main_thread():
            previous = signal.signal(signal.SIGTERM, self._on_sigterm)
        try:
            try:
                report = self.run_test()
            except Interrupted:
                raise Failure('interrupted', 'stopped (SIGTERM)') from None
        except Failure as exc:
            raise CommandError(f'restoretest: site={site} code={exc.code}: {exc.detail}') from None
        finally:
            if previous is not None:
                signal.signal(signal.SIGTERM, previous)
        self.stdout.write(
            f'restoretest: ok site={site} dump={report["stamp"]} '
            f'({report["age_hours"]:.1f} h old, {report["size"]} bytes) '
            f'migrations={report["migrations"]}/{report["live_migrations"]} '
            f'users={report["users"]} in {time.monotonic() - start:.1f}s')

    @staticmethod
    def _on_sigterm(signum, frame):
        raise Interrupted()

    # --- the run -------------------------------------------------------------------------

    def run_test(self):
        db, table = self.check_settings()
        age, pg_restore = self.check_tools()
        tmp_dir = self.check_tmp_dir()
        identity_data = self.read_identity()

        scratch = None
        tmp_path = None
        failure = None
        try:
            try:
                scratch = open_scratch_database(db)
                server = scratch.server_major()
            except Exception as exc:
                raise Failure('scratch-db', f'could not connect ({_db_error(exc)})') from None
            self.check_role(scratch)
            self.check_pg_restore(pg_restore, server)
            self.empty_scratch(scratch)

            key, size, when = self.find_dump()
            identity = self.unwrap_identity(identity_data)
            fd, name = tempfile.mkstemp(prefix=backupdb.temp_prefix(),
                                        suffix=backupdb.TEMP_SUFFIX, dir=tmp_dir)
            tmp_path = Path(name)
            self.download(key, size, fd, tmp_path)
            try:
                self.restore(age, pg_restore, identity, tmp_path, db)
            finally:
                del identity
            report = self.check_restored(scratch, table)
            report.update(
                stamp=when.strftime(_STAMP_FORMAT), size=size,
                age_hours=(datetime.now(timezone.utc) - when).total_seconds() / 3600)
            return report
        except Failure as exc:
            failure = exc
            raise
        except Interrupted:
            failure = Failure('interrupted', 'stopped (SIGTERM)')
            raise failure from None
        finally:
            if tmp_path is not None:
                tmp_path.unlink(missing_ok=True)
            if scratch is not None:
                self.cleanup(scratch, failure)

    def cleanup(self, scratch, failure):
        """Empty the scratch database; a clean-up failure is the run's failure unless it
        already failed (then it is added to that error)."""
        problem = None
        try:
            scratch.reset()
            if scratch.relation_count() != 0:
                problem = 'the scratch database is not empty after the clean-up'
        except Exception as exc:
            problem = f'could not empty the scratch database ({_db_error(exc)})'
        finally:
            try:
                scratch.close()
            except Exception:
                pass
        if problem:
            if failure is not None:
                failure.detail = f'{failure.detail}; also {problem}'
            else:
                raise Failure('cleanup', problem)

    # --- checks --------------------------------------------------------------------------

    def check_settings(self):
        for key in S3_SETTINGS:
            if not str(getattr(settings, key, '') or '').strip():
                raise Failure('settings', f'setting {key} is missing (shared/settings.env)')
        prefix = settings.BACKUP_PREFIX
        if prefix.startswith('/') or not prefix.endswith('/'):
            raise Failure('settings', 'BACKUP_PREFIX must end with "/" and not start with it')
        if not backupdb._BASENAME_RE.match(backupdb.object_basename()):
            raise Failure('settings', 'MYTP_BACKUP_BASENAME must be lowercase letters, '
                                      'digits, "-" or "_"')
        if not backupdb.restore_recipient():
            raise Failure('settings', 'BACKUP_AGE_RESTORE_RECIPIENT is missing (the restore '
                                      'identity, manage.py generate_restore_identity)')
        db = scratch_settings()
        live = settings.DATABASES['default']
        if not db:
            raise Failure('settings', 'RESTORE_TEST_DATABASE is not set '
                                      '(RESTORE_TEST_DATABASE_URL in shared/settings.env)')
        if 'postgresql' not in str(db.get('ENGINE', '')):
            raise Failure('settings', 'RESTORE_TEST_DATABASE is not PostgreSQL')
        if not SCRATCH_NAME_RE.match(str(db.get('NAME') or '')):
            raise Failure('settings', 'the scratch database name must end in _restore_test')
        if db.get('NAME') == live.get('NAME'):
            raise Failure('settings', "the scratch database is the site's own database")
        if not db.get('USER') or db.get('USER') == live.get('USER'):
            raise Failure('settings', "the scratch database needs its own user, never the "
                                      "site's")
        table = user_table()
        if not TABLE_RE.match(table):
            raise Failure('settings', 'RESTORE_TEST_USER_TABLE is not a table name')
        return db, table

    def check_role(self, scratch):
        try:
            flags = scratch.role_flags()
        except Exception as exc:
            raise Failure('scratch-db', f'could not read the scratch role ({_db_error(exc)})') from None
        powers = sorted(name for name, on in flags.items() if on)
        if powers:
            raise Failure('scratch-db', f'the scratch role must not have {", ".join(powers)} '
                                        f'(its own plain user, never the service admin)')

    def check_tools(self):
        found = []
        for tool, package in (('age', 'age'), ('pg_restore', 'postgresql-client')):
            path = shutil.which(tool)
            if not path:
                raise Failure('tools', f'{tool} not found; install the {package} package '
                                       f'(provision.sh)')
            found.append(path)
        return found

    def check_pg_restore(self, pg_restore, server):
        try:
            result = subprocess.run([pg_restore, '--version'], capture_output=True, text=True,
                                    timeout=30, stdin=subprocess.DEVNULL)
        except (OSError, subprocess.SubprocessError) as exc:
            raise Failure('tools', f'could not run pg_restore --version '
                                   f'({type(exc).__name__})') from None
        match = _VERSION_RE.search(result.stdout)
        if result.returncode != 0 or not match:
            raise Failure('tools', 'unexpected pg_restore --version output')
        client = int(match.group(1))
        if client < server:
            raise Failure('tools', f'pg_restore {client} is older than the scratch database '
                                   f'server ({server})')

    def check_tmp_dir(self):
        try:
            return backupdb.Command().check_tmp_dir()
        except CommandError as exc:
            raise Failure('tmp-dir', str(exc).removeprefix('backupdb: ')) from None

    def read_identity(self):
        try:
            data = restore_identity.read_file()
        except restore_identity.RestoreIdentityError as exc:
            raise Failure('identity', str(exc)) from None
        if data['recipient'] != backupdb.restore_recipient():
            raise Failure('identity', 'the restore identity file is not the key of '
                                      'BACKUP_AGE_RESTORE_RECIPIENT')
        return data

    def unwrap_identity(self, data):
        try:
            return restore_identity.unwrap(data)
        except restore_identity.RestoreIdentityError as exc:
            raise Failure('identity', f'{exc.code}: {exc}') from None

    def empty_scratch(self, scratch):
        try:
            if scratch.relation_count():
                scratch.reset()
            count = scratch.relation_count()
        except Exception as exc:
            raise Failure('scratch-db', f'could not empty the scratch database '
                                        f'({_db_error(exc)})') from None
        if count:
            raise Failure('scratch-db', f'the scratch database is not empty ({count} relations)')

    # --- the bucket ----------------------------------------------------------------------

    def find_dump(self):
        prefix = settings.BACKUP_PREFIX
        basename = backupdb.object_basename()
        objects = []
        try:
            client = make_s3_client()
            token = None
            while True:
                kwargs = {'Bucket': settings.BACKUP_S3_BUCKET, 'Prefix': f'{prefix}{basename}-'}
                if token:
                    kwargs['ContinuationToken'] = token
                page = client.list_objects_v2(**kwargs)
                objects.extend(page.get('Contents') or [])
                token = page.get('NextContinuationToken')
                if not page.get('IsTruncated') or not token:
                    break
        except Exception as exc:
            raise Failure('list', f'could not list the backups ({backupdb._s3_error(exc)})') from None
        newest = newest_dump(objects, prefix, basename)
        if newest is None:
            raise Failure('no-dump', f'no {basename} dump under {prefix}')
        key, size, when = newest
        age = datetime.now(timezone.utc) - when
        if -age > FUTURE_SKEW:
            raise Failure('stale-dump', 'the newest dump is dated more than an hour in the '
                                        'future (a clock or naming fault)')
        if age > max_age():
            raise Failure('stale-dump', f'the newest dump is {age.days} days old '
                                        f'(limit {max_age().days})')
        return key, size, when

    def download(self, key, size, fd, path):
        """Into the open temp file `fd` (no second file a kill could leave behind)."""
        try:
            with open(fd, 'wb') as fh:
                make_s3_client().download_fileobj(settings.BACKUP_S3_BUCKET, key, fh)
        except Exception as exc:
            raise Failure('download', f'download failed ({backupdb._s3_error(exc)})') from None
        got = path.stat().st_size
        if got != size:
            raise Failure('download', f'downloaded {got} bytes, expected {size}')

    # --- decrypt and restore -------------------------------------------------------------

    def restore(self, age, pg_restore, identity, path, db):
        """age --decrypt (identity through a pipe) | pg_restore into the scratch database."""
        read_fd, write_fd = os.pipe()
        try:
            # An identity is about 75 bytes, far below the pipe buffer: no deadlock.
            os.write(write_fd, f'{identity}\n'.encode())
        finally:
            os.close(write_fd)
        name = db['NAME']
        # Their output is dropped, never shown or logged: pg_restore's errors can quote
        # restored rows.
        try:
            decrypt = subprocess.Popen(
                [age, '--decrypt', '--identity', f'/dev/fd/{read_fd}', str(path)],
                stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                pass_fds=(read_fd,))
        finally:
            os.close(read_fd)
        try:
            load = subprocess.Popen(
                [pg_restore, *PG_RESTORE_ARGS, f'--dbname={name}'],
                stdin=decrypt.stdout, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                env=backupdb.pg_environment(db, appname='mytp-restoretest'))
        except BaseException:
            decrypt.kill()
            decrypt.wait()
            raise
        decrypt.stdout.close()
        try:
            load_rc = load.wait()
            age_rc = decrypt.wait()
        finally:
            for proc in (decrypt, load):
                if proc.poll() is None:
                    proc.kill()
                    proc.wait()
        # pg_restore failing first kills age with SIGPIPE: that is a restore failure.
        if age_rc != 0 and not (load_rc != 0 and age_rc == -signal.SIGPIPE):
            raise Failure('decrypt', f'age failed (exit {age_rc}); the dump is damaged or '
                                     f'not encrypted to the restore key')
        if load_rc != 0:
            raise Failure('restore', f'pg_restore failed (exit {load_rc}); nothing was kept '
                                     f'(single transaction)')

    def check_restored(self, scratch, table):
        try:
            restored = scratch.migrations()
            users = scratch.count_rows(table)
        except Exception as exc:
            raise Failure('check', f'could not read the restored database ({_db_error(exc)})') from None
        if not restored:
            raise Failure('check', 'the restored database has no applied migrations')
        try:
            live = live_migrations()
        except Exception as exc:
            raise Failure('check', f"could not read the site's migrations ({_db_error(exc)})") from None
        unknown = restored - live
        if unknown:
            raise Failure('check', f'{len(unknown)} restored migration(s) are unknown to this '
                                   f"site: another site's dump?")
        if users is None:
            raise Failure('check', f'the user table {table} is missing from the restored database')
        return {'migrations': len(restored), 'live_migrations': len(live), 'users': users}

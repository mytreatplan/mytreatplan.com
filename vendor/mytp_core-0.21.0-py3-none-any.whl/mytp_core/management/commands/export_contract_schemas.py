"""Rewrite the contract JSON Schema files from the models (0.7.0, mytp_core.contracts).

    python manage.py export_contract_schemas            # rewrite mytp_core/schemas/*.json
    python manage.py export_contract_schemas --check    # fail if a file differs

Run it in mytp-core after changing a contract model, and commit the files with the
change; the drift test (tests/test_contracts.py) fails until then.
"""
from pathlib import Path

from django.core.management.base import BaseCommand, CommandError

from mytp_core.contracts import SCHEMA_DIR, SCHEMA_MODELS, schema_text


class Command(BaseCommand):
    help = 'Rewrite mytp_core/schemas/*.json from the contract models (--check: compare only).'

    def add_arguments(self, parser):
        parser.add_argument('--check', action='store_true',
                            help='Write nothing; fail when a file differs from its model.')
        parser.add_argument('--dir', default=str(SCHEMA_DIR),
                            help='The folder of the schema files (default: the package\'s).')

    def handle(self, *args, check=False, dir=None, **options):
        folder = Path(dir)
        stale = []
        for name, model in SCHEMA_MODELS.items():
            target = folder / name
            text = schema_text(model)
            current = target.read_text(encoding='utf-8') if target.exists() else None
            if current == text:
                continue
            stale.append(name)
            if not check:
                folder.mkdir(parents=True, exist_ok=True)
                target.write_text(text, encoding='utf-8')
                self.stdout.write(f'wrote {name}')
        if check and stale:
            raise CommandError(f'schema files differ from the models: {", ".join(stale)} '
                               f'(run manage.py export_contract_schemas)')
        if not stale:
            self.stdout.write('schema files are up to date')

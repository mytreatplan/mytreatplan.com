"""Make the site's restore-only age identity, KMS-wrapped (0.18.0, AD-24).

    python manage.py generate_restore_identity            # writes RESTORE_AGE_IDENTITY_FILE
    python manage.py generate_restore_identity --replace  # replaces an existing file
    python manage.py generate_restore_identity --public   # the configured file's recipient

Runs `age-keygen` with its output captured in memory, wraps the identity with a new KMS
data key (mytp_core.restore_identity) and writes RESTORE_AGE_IDENTITY_FILE (default
SITE_HOME/shared/restore-identity.json, mode 600). The identity is never printed, logged
or written in plain. Prints one line, the public key, for the site's settings.env:

    BACKUP_AGE_RESTORE_RECIPIENT=age1...

Python cannot wipe memory: the identity is dropped (`del`) once wrapped, not zeroed. If
the KMS or the write fails, no file is left. Run it on the server as the site's user. The team's own key (BACKUP_AGE_RECIPIENT) is not
touched: its private half never goes to a server.
"""
import os
import re
import shutil
import subprocess

from django.core.management.base import BaseCommand, CommandError

from mytp_core import restore_identity

_PUBLIC_RE = re.compile(r'^# public key: (age1[0-9a-z]+)$', re.M)
_SECRET_RE = re.compile(r'^(AGE-SECRET-KEY-1[0-9A-Z]+)$', re.M)


def new_identity():
    """(identity, recipient) from age-keygen, kept in memory."""
    keygen = shutil.which('age-keygen')
    if not keygen:
        raise CommandError('generate_restore_identity: age-keygen not found; install the age '
                           'package (provision.sh)')
    try:
        result = subprocess.run([keygen], capture_output=True, text=True, timeout=30,
                                stdin=subprocess.DEVNULL)
    except (OSError, subprocess.SubprocessError) as exc:
        raise CommandError(
            f'generate_restore_identity: could not run age-keygen ({type(exc).__name__})'
        ) from None
    public = _PUBLIC_RE.search(result.stdout)
    secret = _SECRET_RE.search(result.stdout)
    if result.returncode != 0 or not public or not secret:
        raise CommandError('generate_restore_identity: unexpected age-keygen output')
    return secret.group(1), public.group(1)


class Command(BaseCommand):
    help = ("Make the site's restore-only age identity, wrap it with a KMS data key into "
            "RESTORE_AGE_IDENTITY_FILE and print BACKUP_AGE_RESTORE_RECIPIENT=<public key>. "
            "The identity is never printed.")
    requires_system_checks = []

    def add_arguments(self, parser):
        parser.add_argument('--replace', action='store_true',
                            help='Replace an existing identity file (dumps made for the old '
                                 'key stay readable with the team key only).')
        parser.add_argument('--public', action='store_true',
                            help="Print the configured file's public key only (no KMS call).")

    def handle(self, *args, replace=False, public=False, **options):
        path = restore_identity.identity_file()
        if public:
            try:
                data = restore_identity.read_file(path)
            except restore_identity.RestoreIdentityError as exc:
                raise CommandError(f'generate_restore_identity: {exc}') from None
            self.stdout.write(f'BACKUP_AGE_RESTORE_RECIPIENT={data["recipient"]}')
            return
        if os.path.lexists(path) and not replace:
            raise CommandError(f'generate_restore_identity: {path} exists; pass --replace to '
                               f'replace it')
        if not path.parent.is_dir():
            raise CommandError(f'generate_restore_identity: {path.parent} is missing')
        identity, recipient = new_identity()
        try:
            text = restore_identity.wrap(identity, recipient)
            del identity
            restore_identity.write_file(path, text, replace=replace)
        except restore_identity.RestoreIdentityError as exc:
            raise CommandError(f'generate_restore_identity: {exc}') from None
        except OSError as exc:
            raise CommandError(f'generate_restore_identity: could not write {path} '
                               f'({type(exc).__name__})') from None
        self.stdout.write(f'BACKUP_AGE_RESTORE_RECIPIENT={recipient}')

"""The site's restore-only `age` identity, wrapped by the site's KMS key (0.18.0, AD-24).

Every dump `backupdb` makes is encrypted to two age public keys: the team's
(BACKUP_AGE_RECIPIENT; its private half stays in the team password manager and never
reaches a server) and the site's restore-only one (BACKUP_AGE_RESTORE_RECIPIENT). The
restore identity's private half lives on the server only inside one file,
RESTORE_AGE_IDENTITY_FILE (default `SITE_HOME/shared/restore-identity.json`, mode 600):

    {"format": "mytp-restore-identity", "version": 1, "site": "<SITE>",
     "recipient": "age1...", "wrapped_key": "<KMS-wrapped data key>",
     "nonce": "<base64>", "ciphertext": "<base64>"}

The ciphertext is the identity (`AGE-SECRET-KEY-1...`) encrypted with AES-256-GCM under a
256-bit data key from the KMS (KMS_SERVICE_KEY_ID), bound to the site and the recipient
(associated data). Only `wrapped_key` is kept, so the file is useless without the KMS.
`manage.py generate_restore_identity` writes it (the identity comes from `age-keygen` and
is never printed or written in plain); `manage.py restoretest` reads it, unwraps the data
key and decrypts the identity in memory only, and hands it to `age` through a pipe.

A lost or damaged file costs nothing but a new one: the team key still opens every dump,
and the next `backupdb` run after the new recipient is set encrypts to it.

Python cannot wipe memory: the plain identity and data key are dropped (`del`) after use,
not zeroed; they are never printed, logged or written.

Errors are `RestoreIdentityError`s with a short code (`missing`, `format`, `kms`,
`decrypt`, `site`) and a text that never holds the identity, the data key or the wrapped
key.
"""
import base64
import binascii
import json
import os
import re
import secrets
import stat
from pathlib import Path

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from django.conf import settings

from mytp_core import kms
from mytp_core.crypto import KEY_SIZE, NONCE_SIZE, WRAPPED_KEY_RE

FORMAT = 'mytp-restore-identity'
VERSION = 1
FILE_NAME = 'restore-identity.json'
IDENTITY_RE = re.compile(r'\AAGE-SECRET-KEY-1[0-9A-Z]{50,}\Z')
RECIPIENT_RE = re.compile(r'\Aage1[0-9a-z]{20,}\Z')
MAX_FILE_BYTES = 16 * 1024


class RestoreIdentityError(Exception):
    def __init__(self, code, detail):
        self.code = code
        super().__init__(detail)


def identity_file():
    """RESTORE_AGE_IDENTITY_FILE, default SITE_HOME/shared/restore-identity.json."""
    configured = str(getattr(settings, 'RESTORE_AGE_IDENTITY_FILE', '') or '').strip()
    return Path(configured) if configured else Path(settings.SITE_HOME) / 'shared' / FILE_NAME


def _associated_data(site, recipient):
    return f'{FORMAT}:v{VERSION}:{site}:{recipient}'.encode()


def _client():
    return kms.KMSClient.from_settings(settings)


def wrap(identity, recipient, *, site=None, client=None):
    """The file's JSON text for `identity` (an AGE-SECRET-KEY-1... string) and its public
    key `recipient`, under a new KMS data key."""
    site = site or settings.SITE
    if not IDENTITY_RE.match(identity) or not RECIPIENT_RE.match(recipient):
        raise RestoreIdentityError('format', 'not an age identity and its public key')
    try:
        client = client or _client()
        wrapped, data_key = client.generate_data_key(
            settings.KMS_SERVICE_KEY_ID.strip(), f'mytp-restore-identity-{site}', KEY_SIZE * 8)
    except kms.KMSError as exc:
        raise RestoreIdentityError('kms', f'the KMS could not make a data key: {exc}') from None
    if len(data_key) != KEY_SIZE or not WRAPPED_KEY_RE.match(wrapped or ''):
        raise RestoreIdentityError('kms', 'the KMS returned an unusable data key')
    nonce = secrets.token_bytes(NONCE_SIZE)
    ciphertext = AESGCM(data_key).encrypt(nonce, identity.encode(),
                                          _associated_data(site, recipient))
    del data_key
    return json.dumps({
        'format': FORMAT, 'version': VERSION, 'site': site, 'recipient': recipient,
        'wrapped_key': wrapped,
        'nonce': base64.b64encode(nonce).decode(),
        'ciphertext': base64.b64encode(ciphertext).decode(),
    }, indent=1) + '\n'


def write_file(path, text, *, replace=False):
    """Write the file atomically with mode 600; refuses to replace one unless asked."""
    path = Path(path)
    # lexists: a symlink (even a dangling one) counts as there; os.replace then replaces
    # the link itself, never its target.
    if os.path.lexists(path) and not replace:
        raise RestoreIdentityError('exists', f'{path} exists; pass --replace to replace it')
    tmp = path.with_name(f'.{path.name}.{secrets.token_hex(4)}.tmp')
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, 'w') as fh:
            fh.write(text)
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def read_file(path=None):
    """The parsed file (no KMS call): a dict with the fields above."""
    path = Path(path or identity_file())
    try:
        info = path.stat()
        if not stat.S_ISREG(info.st_mode):
            raise RestoreIdentityError('missing', f'{path} is not a file')
        if info.st_mode & 0o077:
            raise RestoreIdentityError('format', f'{path} must be mode 600')
        if info.st_size > MAX_FILE_BYTES:
            raise RestoreIdentityError('format', f'{path} is too large')
        data = json.loads(path.read_text())
    except FileNotFoundError:
        raise RestoreIdentityError(
            'missing', f'{path} is missing (manage.py generate_restore_identity)') from None
    except (OSError, ValueError):
        raise RestoreIdentityError('format', f'{path} is not a restore identity file') from None
    if not isinstance(data, dict) or data.get('format') != FORMAT \
            or data.get('version') != VERSION:
        raise RestoreIdentityError('format', f'{path} is not a restore identity file')
    for field in ('site', 'recipient', 'wrapped_key', 'nonce', 'ciphertext'):
        if not isinstance(data.get(field), str) or not data[field]:
            raise RestoreIdentityError('format', f'{path}: field {field} is missing')
    if not RECIPIENT_RE.match(data['recipient']) or not WRAPPED_KEY_RE.match(data['wrapped_key']):
        raise RestoreIdentityError('format', f'{path}: malformed recipient or wrapped key')
    return data


def unwrap(data, *, site=None, client=None):
    """The identity (AGE-SECRET-KEY-1...) of a parsed file, decrypted in memory."""
    site = site or settings.SITE
    if data['site'] != site:
        raise RestoreIdentityError('site', 'the restore identity file belongs to another site')
    try:
        nonce = base64.b64decode(data['nonce'], validate=True)
        ciphertext = base64.b64decode(data['ciphertext'], validate=True)
    except (binascii.Error, ValueError):
        raise RestoreIdentityError('format', 'the restore identity file is damaged') from None
    try:
        client = client or _client()
        data_key = client.decrypt_data_key(settings.KMS_SERVICE_KEY_ID.strip(),
                                           data['wrapped_key'])
    except kms.KMSError as exc:
        raise RestoreIdentityError('kms', f'the KMS could not unwrap the data key: {exc}') from None
    if len(data_key) != KEY_SIZE:
        raise RestoreIdentityError('kms', 'the KMS returned an unusable data key')
    try:
        plain = AESGCM(data_key).decrypt(nonce, ciphertext,
                                         _associated_data(site, data['recipient']))
    except (InvalidTag, ValueError):
        raise RestoreIdentityError(
            'decrypt', 'the restore identity does not decrypt (damaged file or other key)'
        ) from None
    finally:
        del data_key
    identity = plain.decode('ascii', 'replace')
    if not IDENTITY_RE.match(identity):
        raise RestoreIdentityError('format', 'the restore identity file holds no age identity')
    return identity

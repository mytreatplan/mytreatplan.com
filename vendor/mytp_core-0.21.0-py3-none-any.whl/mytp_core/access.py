"""Who may read what over a remote read (0.13.0, architecture AD-4, AD-17, AD-23,
interface I6), and change what over a remote write (0.16.0, I7): the rules both sides
apply, in code.

The admin site signs a remote read with the admin user's access as extra claims
(``sub``, ``role``, ``regions``; `mytp_core.interface.remote_actor`); the regional portal
decides itself, from these rules, whether to answer and which fields to send.

- `ROLES`: the six staff role values (the admin site's `staff.models.Role`).
- `RESOURCES`: per remote resource, the admin area it belongs to and, per role, a `Rule`:
  the scope (`ALL`, `REGIONS`, `ASSIGNED`, as the admin permission matrix's) and the
  fields that role sees (an allow-list). A role without a rule gets nothing (default
  deny). The admin site's test asserts its matrix gives exactly these roles view access
  to the area, with these scopes.
- AD-17, checked at import (`validate`): clinical roles see no financial field, sales and
  finance roles no patient name, and a Clinical User only records assigned to them.
- `decide(resource, actor, region, assignee=None)`: a `Decision` (granted or the refusal
  reason, and the fields to send); `visible(data, fields)` keeps only those fields.
- Remote writes (0.16.0, interface I7, AD-3, AD-15): each `Rule` also lists the fields
  that role may change (`writable`, an allow-list within the fields it sees; empty: no
  write). `decide_write(resource, actor, region, names, assignee=None)` is `decide` plus
  every changed name in the allow-list (else refused, reason ``field``). The admin site's
  test asserts the roles with a non-empty `writable` are exactly the roles its matrix
  gives CHANGE on the area. Checked at import as well: a role writes only fields it sees,
  and a clinical role never a financial field or a patient name.

Scopes, at the region: `ALL` every record; `REGIONS` the region must be one of the
actor's (every remote read requires that anyway: a token whose ``regions`` lacks the
receiving region is refused); `ASSIGNED` the record's assignee must be the actor's UUID.
"""
from types import MappingProxyType
from typing import NamedTuple

SYSADMIN = 'sysadmin'
FINANCIAL_MANAGER = 'financial_manager'
COMMERCIAL_MANAGER = 'commercial_manager'
COMMERCIAL_REGIONAL_MANAGER = 'commercial_regional_manager'
CLINICAL_MANAGER = 'clinical_manager'
CLINICAL_USER = 'clinical_user'
ROLES = (SYSADMIN, FINANCIAL_MANAGER, COMMERCIAL_MANAGER, COMMERCIAL_REGIONAL_MANAGER,
         CLINICAL_MANAGER, CLINICAL_USER)

# AD-17's groups: clinical roles see no financial data; sales and finance roles no
# patient names.
CLINICAL_ROLES = frozenset({CLINICAL_MANAGER, CLINICAL_USER})
SALES_FINANCE_ROLES = frozenset({FINANCIAL_MANAGER, COMMERCIAL_MANAGER,
                                 COMMERCIAL_REGIONAL_MANAGER})

ALL = 'all'
REGIONS = 'regions'
ASSIGNED = 'assigned'
SCOPES = frozenset({ALL, REGIONS, ASSIGNED})

# Refusal reasons (`Decision.reason`; the portal's access log stores them).
REASON_ACTOR = 'actor'        # the token's sub / role / regions are missing or malformed
REASON_REGION = 'region'      # this region is not among the actor's regions
REASON_ROLE = 'role'          # the role has no rule for the resource
REASON_ASSIGNED = 'assigned'  # ASSIGNED scope, and the record is someone else's
REASON_RESOURCE = 'resource'  # not a remote resource
REASON_FIELD = 'field'        # a write changes a field outside the role's `writable` (0.16.0)


class AccessRulesError(ValueError):
    """The rules break AD-17 or name an unknown role, scope or field (raised at import)."""


class Rule(NamedTuple):
    """A role's access to a resource: the scope, the fields it sees and (0.16.0) the
    fields it may change remotely (empty: read only)."""
    scope: str
    fields: frozenset
    writable: frozenset = frozenset()


class Resource(NamedTuple):
    """A remote resource: its admin `area`, every field it has, which are financial and
    which are patient names (AD-17), and the `rules` by role."""
    area: str
    fields: frozenset
    financial: frozenset
    patient_names: frozenset
    rules: MappingProxyType


class Decision(NamedTuple):
    granted: bool
    reason: str
    fields: frozenset


# --- Resources --------------------------------------------------------------------------

# The staging-only sample record (epic-admin-interface entry 5, decision 2026-10-30),
# removed when epic-ordering's patients exist. Area `patients`: the admin matrix gives it
# to the Sysadmin (all), the Clinical Manager (all) and the Clinical User (assigned), each
# with CHANGE: decision (user, 2026-11-09, entry 6) the three may change the note only.
SAMPLE_RECORD = 'sample_record'
_SAMPLE_FIELDS = frozenset({'uuid', 'patient_name', 'amount', 'assignee_uuid', 'note'})
_SAMPLE_CLINICAL = _SAMPLE_FIELDS - {'amount'}
_SAMPLE_WRITABLE = frozenset({'note'})

_RESOURCES = {
    SAMPLE_RECORD: Resource(
        area='patients',
        fields=_SAMPLE_FIELDS,
        financial=frozenset({'amount'}),
        patient_names=frozenset({'patient_name'}),
        rules={
            SYSADMIN: Rule(ALL, _SAMPLE_FIELDS, _SAMPLE_WRITABLE),
            CLINICAL_MANAGER: Rule(ALL, _SAMPLE_CLINICAL, _SAMPLE_WRITABLE),
            CLINICAL_USER: Rule(ASSIGNED, _SAMPLE_CLINICAL, _SAMPLE_WRITABLE),
        },
    ),
}


def validate(resources):
    """AccessRulesError unless every rule names a known role, scope and fields of its
    resource, and keeps AD-17."""
    for name, resource in resources.items():
        where = f'access rules, {name}'
        if not (resource.financial | resource.patient_names) <= resource.fields:
            raise AccessRulesError(f'{where}: a financial or name field it does not have.')
        for role, rule in resource.rules.items():
            here = f'{where} x {role}'
            if role not in ROLES:
                raise AccessRulesError(f'{here}: unknown role.')
            if rule.scope not in SCOPES:
                raise AccessRulesError(f'{here}: unknown scope {rule.scope!r}.')
            if not isinstance(rule.fields, frozenset) or not rule.fields <= resource.fields:
                raise AccessRulesError(f'{here}: fields must be a frozenset of its fields.')
            if role in CLINICAL_ROLES and rule.fields & resource.financial:
                raise AccessRulesError(f'{here}: a clinical role sees no financial field.')
            if role in SALES_FINANCE_ROLES and rule.fields & resource.patient_names:
                raise AccessRulesError(f'{here}: a sales or finance role sees no patient name.')
            if role == CLINICAL_USER and rule.scope != ASSIGNED:
                raise AccessRulesError(f'{here}: a Clinical User reads assigned records only.')
            if rule.scope == REGIONS and role != COMMERCIAL_REGIONAL_MANAGER:
                raise AccessRulesError(f'{here}: only a regional role has the regions scope.')
            if not isinstance(rule.writable, frozenset) or not rule.writable <= rule.fields:
                raise AccessRulesError(f'{here}: writable must be a frozenset of the fields '
                                       f'the role sees.')
            if role in CLINICAL_ROLES and rule.writable & (resource.financial
                                                           | resource.patient_names):
                raise AccessRulesError(f'{here}: a clinical role writes no financial field '
                                       f'or patient name.')


validate(_RESOURCES)
RESOURCES = MappingProxyType({
    name: resource._replace(rules=MappingProxyType(dict(resource.rules)))
    for name, resource in _RESOURCES.items()})


# --- Decisions --------------------------------------------------------------------------

def rule_for(resource, role):
    """The role's Rule on the resource, or None (no access, or not a remote resource)."""
    found = RESOURCES.get(resource)
    return found.rules.get(role) if found else None


def _refused(reason):
    return Decision(False, reason, frozenset())


def decide(resource, actor, region, assignee=None):
    """May `actor` (a `mytp_core.interface.RemoteActor`, or None for malformed claims)
    read this record of `resource` in `region` (this site's REGION)? `assignee`: the
    record's assignee UUID (text or uuid.UUID, or None), for the ASSIGNED scope. A
    Decision: granted with the fields to send, or refused with a reason."""
    if resource not in RESOURCES:
        return _refused(REASON_RESOURCE)
    if actor is None:
        return _refused(REASON_ACTOR)
    if region not in actor.regions:
        return _refused(REASON_REGION)
    rule = rule_for(resource, actor.role)
    if rule is None:
        return _refused(REASON_ROLE)
    if rule.scope == ASSIGNED and (assignee is None or str(assignee) != actor.sub):
        return _refused(REASON_ASSIGNED)
    return Decision(True, '', rule.fields)


def decide_write(resource, actor, region, names, assignee=None):
    """May `actor` change the fields named `names` (an iterable of field names) of this
    record of `resource` in `region` (0.16.0)? `decide`'s checks, then every name in the
    role's `writable` allow-list (else refused, reason ``field``; no name at all is
    refused the same way). Granted: the Decision's `fields` are the fields the role sees
    (what the answer sends back), as `decide`'s."""
    if isinstance(names, (str, bytes)):
        raise TypeError('names is an iterable of field names, not one string')
    decision = decide(resource, actor, region, assignee=assignee)
    if not decision.granted:
        return decision
    names = frozenset(names)
    if not names or not names <= rule_for(resource, actor.role).writable:
        return _refused(REASON_FIELD)
    return decision


def writable(resource, role):
    """The fields `role` may change on `resource` (0.16.0): a frozenset, empty without a
    rule or without write access."""
    rule = rule_for(resource, role)
    return rule.writable if rule else frozenset()


def visible(data, fields):
    """`data` (a dict of a record's fields) with only `fields` kept."""
    return {name: value for name, value in data.items() if name in fields}

"""Scheduled jobs declared in a site's jobs.conf (moved from the portal's
mytp_publicsite/jobs.py, story 1.9).

systemd timers run them (each site's deploy/provision.sh installs one per line);
`manage.py runjob <name>` runs one and reports Sentry cron check-ins on the monitor
`mytp-<SITE>-<name>` (architecture AD-8, AD-24). The schedule is a systemd OnCalendar
expression; `oncalendar_to_crontab` maps the supported subset to the crontab the Sentry
monitor is created with, so the two never drift apart.

Settings, read when used:

- `MYTP_JOBS_FILE`: the release's jobs.conf (default `BASE_DIR/deploy/jobs.conf`).
- `MYTP_INSTALLED_JOBS_FILE`: the copy provision.sh installed along with the timers
  (default `SITE_HOME/shared/jobs.conf`). On the server the schedules come from it, so
  the Sentry monitors always match what the timers do, even if a release ships a
  jobs.conf that hasn't been provisioned yet.
- `SITE`: the site name in the monitor slugs, and the site whose lines are read.

A line may end with a fourth field, the sites it applies to (0.18.0): `name | command |
schedule | dev,dev-ae`. Without it the line applies to every site that reads the file.
Two lines may share a name only when both list sites and no site is in both, so sites
deployed from one repo (the portal's dev and dev-ae) can run one job at different times
(the weekly restore test, staggered).
"""
import re
import shlex
from dataclasses import dataclass
from pathlib import Path

from django.conf import settings

NAME_RE = re.compile(r'^[a-z0-9][a-z0-9_-]*$')
# provision.sh's site names: lowercase letters, digits and '-', starting with a letter.
SITE_RE = re.compile(r'^[a-z](?:[a-z0-9-]{0,18}[a-z0-9])?$')

_DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
_ONCALENDAR_RE = re.compile(
    r'^(?:(?P<dow>[A-Za-z.,]+) )?'
    r'\*-\*-(?P<dom>\*|\d{1,2}) '
    r'(?P<hour>\*|\d{1,2}):(?P<minute>\d{1,2})(?:/(?P<step>\d{1,2}))?(?::00)? UTC$')


@dataclass(frozen=True)
class Job:
    name: str
    command: str
    args: tuple
    schedule: str
    # The sites the line applies to (0.18.0); empty: every site.
    sites: tuple = ()

    def applies_to(self, site):
        return not self.sites or site in self.sites

    @property
    def crontab(self):
        return oncalendar_to_crontab(self.schedule)


def _cron_dow(spec):
    """'Mon', 'Mon,Wed' or 'Mon..Fri' -> cron day-of-week (0 = Sunday)."""
    def num(day):
        if day not in _DAYS:
            raise ValueError(f'unknown weekday {day!r}')
        return str((_DAYS.index(day) + 1) % 7)
    parts = []
    for item in spec.split(','):
        if '..' in item:
            first, last = item.split('..', 1)
            if last not in _DAYS or first not in _DAYS or _DAYS.index(first) >= _DAYS.index(last) \
                    or last == 'Sun':
                raise ValueError(
                    f'weekday range {item!r} must run forward within Mon..Sat; list Sunday '
                    f'separately, e.g. `Sat,Sun` or `Mon..Sat,Sun`')
            parts.append(f'{num(first)}-{num(last)}')
        else:
            parts.append(num(item))
    return ','.join(parts)


def oncalendar_to_crontab(schedule):
    """Map the supported OnCalendar subset to a 5-field crontab (UTC).

    Raises ValueError for anything else, so an unsupported schedule fails the tests
    instead of silently creating a wrong Sentry monitor.
    """
    match = _ONCALENDAR_RE.match(schedule.strip())
    if not match:
        raise ValueError(
            f'unsupported schedule {schedule!r}; use '
            f'`[Mon..Fri ]*-*-<day|*> <hour|*>:<minute>[/<step>] UTC`')
    minute = int(match['minute'])
    hour = match['hour']
    dom = match['dom']
    if not 0 <= minute <= 59:
        raise ValueError(f'minute out of range in {schedule!r}')
    if hour != '*' and not 0 <= int(hour) <= 23:
        raise ValueError(f'hour out of range in {schedule!r}')
    if dom != '*' and not 1 <= int(dom) <= 28:
        raise ValueError(f'day of month must be 1-28 in {schedule!r}')
    dow = _cron_dow(match['dow']) if match['dow'] else '*'
    hour = hour if hour == '*' else str(int(hour))
    dom = dom if dom == '*' else str(int(dom))
    # `<minute>/<step>` (0.3.0): every <step> minutes from <minute>, starting again at
    # each hour as cron does, e.g. `*:00/5` -> `*/5`, `*:02/15` -> `2-59/15`.
    if match['step'] is not None:
        step = int(match['step'])
        if not 1 <= step <= 59:
            raise ValueError(f'minute step must be 1-59 in {schedule!r}')
        minutes = f'*/{step}' if minute == 0 else f'{minute}-59/{step}'
    else:
        minutes = str(minute)
    return f'{minutes} {hour} {dom} * {dow}'


def parse_job_lines(text):
    """Every line of jobs.conf text as a Job, in order, whatever its sites. Raises
    ValueError on a bad line or a name used twice for one site."""
    lines = []
    for number, raw in enumerate(text.splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        fields = [f.strip() for f in line.split('|')]
        if len(fields) not in (3, 4) or not all(fields):
            raise ValueError(
                f'jobs.conf line {number}: expected `name | command | schedule [| sites]`')
        name, command_line, schedule = fields[:3]
        if not NAME_RE.match(name):
            raise ValueError(f'jobs.conf line {number}: invalid job name {name!r}')
        sites = ()
        if len(fields) == 4:
            sites = tuple(s.strip() for s in fields[3].split(','))
            if not all(SITE_RE.match(s) for s in sites) or len(set(sites)) != len(sites):
                raise ValueError(
                    f'jobs.conf line {number}: sites must be distinct site names, '
                    f'comma-separated (e.g. `dev,dev-ae`)')
        for other in lines:
            if other.name == name and (not sites or not other.sites
                                       or set(sites) & set(other.sites)):
                raise ValueError(f'jobs.conf line {number}: duplicate job {name!r}')
        oncalendar_to_crontab(schedule)
        command, *args = shlex.split(command_line)
        lines.append(Job(name, command, tuple(args), schedule, sites))
    return lines


def parse_jobs(text, site=None):
    """Parse jobs.conf text into {name: Job} for `site` (default: settings.SITE): the
    lines without sites and those listing it. Raises ValueError on a bad line."""
    if site is None and settings.configured:
        site = getattr(settings, 'SITE', None)
    return {job.name: job for job in parse_job_lines(text) if job.applies_to(site)}


def release_jobs_file():
    """The release's jobs.conf (MYTP_JOBS_FILE, default BASE_DIR/deploy/jobs.conf)."""
    configured = getattr(settings, 'MYTP_JOBS_FILE', None)
    return Path(configured) if configured else Path(settings.BASE_DIR) / 'deploy' / 'jobs.conf'


def installed_jobs_file():
    """The provisioned jobs.conf (MYTP_INSTALLED_JOBS_FILE, default
    SITE_HOME/shared/jobs.conf)."""
    configured = getattr(settings, 'MYTP_INSTALLED_JOBS_FILE', None)
    return Path(configured) if configured else Path(settings.SITE_HOME) / 'shared' / 'jobs.conf'


def jobs_file():
    """The provisioned jobs.conf when it exists (the server), else the release's."""
    installed = installed_jobs_file()
    return installed if installed.is_file() else release_jobs_file()


def load_jobs(path=None, site=None):
    return parse_jobs(Path(path or jobs_file()).read_text(), site)


def monitor_slug(name, site=None):
    """The Sentry cron monitor of job `name`: `mytp-<SITE>-<name>`. The Sentry environment
    (SENTRY_ENVIRONMENT) is separate from it: since 0.18.0 each site reports to its own
    environment, named after the site (`dev`, `dev-ae`, `admindev`; production
    `portal-eu`, `portal-ae`, `admin`)."""
    return f'mytp-{site or settings.SITE}-{name}'

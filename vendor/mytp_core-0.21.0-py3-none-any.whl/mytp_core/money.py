"""Money (0.9.0, architecture AD-6): an exact amount of one currency, the one money type of
every site (prices, invoices, the accounting feed).

`Money(amount, currency)` holds a `Decimal` quantized to cents (0.01, ROUND_HALF_UP) and an
ISO 4217 code among `CURRENCIES`. The amount is a `Decimal`, an `int` or a decimal string
(``"123.45"``); a `float` (or a `bool`) is a `TypeError`, so a float never carries money.
The value is immutable and hashable.

Caller rule: build amounts and factors from strings or ints (``Decimal('2.675')``,
``Decimal('0.21')``), never ``Decimal(float)``: ``Decimal(2.675)`` is the float's exact
binary value (2.67499999...), cannot be told apart from an intended Decimal, and rounds
as such (to 2.67).

- Arithmetic only within one currency: ``+``, ``-`` and the ordering (``<``, ``<=``,
  ``>``, ``>=``) between two `Money` of different currencies raise `CurrencyMismatch` (a
  `ValueError`); ``==`` between them is False (``!=`` True); a `Money` never equals a
  bare number; adding a number is a `TypeError`.
- ``Money * n`` and ``n * Money`` for an `int` or `Decimal` n (a quantity, a percentage,
  a VAT rate): the exact product quantized half up to cents. There is no ``/``:
  `split(n)` gives n parts summing exactly to the whole.
- ``sum(items, Money.zero('EUR'))`` totals a list.
- The wire shape is `contracts.Amount`'s ``{"amount": "123.45", "currency": "EUR"}``:
  `to_contract()` and `Money.from_contract(dict_or_Amount)`; the round trip is exact.
  The amount stays within that shape's 15 integer digits, so `to_contract` never fails.

No currency conversion (rates are a later entry) and no model field here.
"""
import re
from decimal import (MAX_EMAX, MIN_EMIN, ROUND_HALF_UP, Context, Decimal,
                     InvalidOperation)

from .contracts.amounts import Amount

CURRENCIES = ('EUR', 'AED', 'USD')

CENT = Decimal('0.01')
# contracts.Amount takes at most 15 integer digits.
LIMIT = Decimal(10) ** 15
# The most parts `split` gives (a bound on memory).
MAX_PARTS = 10_000

# A decimal string: optional sign, digits, optional fraction. No exponent, spaces or "_".
_DECIMAL_RE = re.compile(r'[+-]?[0-9]+(\.[0-9]+)?')

# Quantizing a value below LIMIT needs at most 17 digits; the products are made exact
# by a context sized to their operands (see __mul__). Every operation passes its context,
# so a site's thread context (precision, rounding) never changes a result.
_QUANTIZE = Context(prec=40, rounding=ROUND_HALF_UP, Emax=MAX_EMAX, Emin=MIN_EMIN,
                    traps=[InvalidOperation])


class CurrencyMismatch(ValueError):
    """Two amounts of different currencies were added, subtracted or ordered."""


def _to_decimal(amount):
    if isinstance(amount, bool) or isinstance(amount, float):
        raise TypeError(f'money is never a {type(amount).__name__}; pass a Decimal, an int '
                        f'or a decimal string such as "123.45"')
    if isinstance(amount, Decimal):
        value = amount
    elif isinstance(amount, int):
        value = Decimal(amount)
    elif isinstance(amount, str):
        if not _DECIMAL_RE.fullmatch(amount):
            raise ValueError(f'not a decimal string: {amount!r}')
        value = Decimal(amount)
    else:
        raise TypeError(f'money is a Decimal, an int or a decimal string, '
                        f'not a {type(amount).__name__}')
    if not value.is_finite():
        raise ValueError('money is a finite amount, never NaN or Infinity')
    return value


def _quantize(value):
    if value.copy_abs() >= LIMIT:  # before rounding; any zero passes, whatever its exponent
        raise ValueError('money is below 10**15 in absolute value')
    value = value.quantize(CENT, context=_QUANTIZE)
    if value.copy_abs() >= LIMIT:
        raise ValueError('money is below 10**15 in absolute value')
    if value.is_zero():
        value = Decimal('0.00')  # never -0.00
    return value


def _factor(n):
    if isinstance(n, bool) or not isinstance(n, (int, Decimal)):
        return None
    value = Decimal(n) if isinstance(n, int) else n
    if not value.is_finite():
        raise ValueError('a factor is finite, never NaN or Infinity')
    return value


class Money:
    """An exact amount of one currency. See the module docstring.

    Immutable: an instance is initialised once (calling `__init__` again is a
    `TypeError`). Writing the private slots with `object.__setattr__` is outside the
    contract."""

    __slots__ = ('_amount', '_currency')

    def __init__(self, amount, currency):
        try:
            object.__getattribute__(self, '_currency')
        except AttributeError:
            pass
        else:
            raise TypeError('Money is immutable: an instance is initialised once')
        # Exactly str (a subclass could compare equal to anything); store the constant.
        if type(currency) is not str or currency not in CURRENCIES:
            raise ValueError(f'currency is one of {", ".join(CURRENCIES)}, not {currency!r}')
        object.__setattr__(self, '_amount', _quantize(_to_decimal(amount)))
        object.__setattr__(self, '_currency', CURRENCIES[CURRENCIES.index(currency)])

    @classmethod
    def zero(cls, currency):
        """0.00 of a currency: the start of `sum()`."""
        return cls(0, currency)

    @property
    def amount(self):
        """The `Decimal`, with exactly 2 places."""
        return self._amount

    @property
    def currency(self):
        return self._currency

    # --- Immutability -------------------------------------------------------------------

    def __setattr__(self, name, value):
        raise AttributeError('Money is immutable')

    def __delattr__(self, name):
        raise AttributeError('Money is immutable')

    def __reduce__(self):
        return (Money, (format(self._amount, 'f'), self._currency))

    # --- Text ---------------------------------------------------------------------------

    def __str__(self):
        return f'{self._amount:f} {self._currency}'

    def __repr__(self):
        return f"Money('{self._amount:f}', '{self._currency}')"

    # --- Equality and ordering ----------------------------------------------------------

    def _same_currency(self, other, operation):
        if other._currency != self._currency:
            raise CurrencyMismatch(
                f'cannot {operation} {self._currency} and {other._currency}')

    def __eq__(self, other):
        if not isinstance(other, Money):
            return NotImplemented
        # Different currencies are simply not equal (so `in`, dict and set lookups mixing
        # currencies work); the hash includes the currency, consistent with this.
        return self._currency == other._currency and self._amount == other._amount

    def __hash__(self):
        return hash((self._amount, self._currency))

    def __lt__(self, other):
        if not isinstance(other, Money):
            return NotImplemented
        self._same_currency(other, 'compare')
        return self._amount < other._amount

    def __le__(self, other):
        if not isinstance(other, Money):
            return NotImplemented
        self._same_currency(other, 'compare')
        return self._amount <= other._amount

    def __gt__(self, other):
        if not isinstance(other, Money):
            return NotImplemented
        self._same_currency(other, 'compare')
        return self._amount > other._amount

    def __ge__(self, other):
        if not isinstance(other, Money):
            return NotImplemented
        self._same_currency(other, 'compare')
        return self._amount >= other._amount

    # --- Arithmetic ---------------------------------------------------------------------

    def __add__(self, other):
        if not isinstance(other, Money):
            return NotImplemented
        self._same_currency(other, 'add')
        return Money(_QUANTIZE.add(self._amount, other._amount), self._currency)

    def __sub__(self, other):
        if not isinstance(other, Money):
            return NotImplemented
        self._same_currency(other, 'subtract')
        return Money(_QUANTIZE.subtract(self._amount, other._amount), self._currency)

    def __neg__(self):
        return Money(self._amount.copy_negate(), self._currency)

    def __mul__(self, other):
        factor = _factor(other)
        if factor is None:
            return NotImplemented
        # Enough digits for the exact product, whatever the operands.
        digits = len(self._amount.as_tuple().digits) + len(factor.as_tuple().digits) + 1
        exact = Context(prec=digits, rounding=ROUND_HALF_UP, Emax=MAX_EMAX, Emin=MIN_EMIN,
                        traps=[InvalidOperation])
        return Money(exact.multiply(self._amount, factor), self._currency)

    __rmul__ = __mul__

    def split(self, n):
        """n parts of the same currency summing exactly to this amount; the leftover cents
        go one each to the first parts (a negative amount mirrors it):
        ``Money('10.00', 'EUR').split(3)`` is 3.34, 3.33, 3.33."""
        if isinstance(n, bool) or not isinstance(n, int):
            raise TypeError('split takes an int number of parts')
        if n < 1 or n > MAX_PARTS:
            raise ValueError(f'split takes from 1 to {MAX_PARTS} parts')
        cents = int(self._amount.scaleb(2, context=_QUANTIZE))
        sign = -1 if cents < 0 else 1
        base, leftover = divmod(abs(cents), n)
        return [Money(Decimal(sign * (base + (1 if i < leftover else 0))).scaleb(
                    -2, context=_QUANTIZE), self._currency)
                for i in range(n)]

    # --- Wire shape ---------------------------------------------------------------------

    def to_contract(self):
        """``{"amount": "123.45", "currency": "EUR"}``, validated by `contracts.Amount`."""
        return Amount(amount=self._amount, currency=self._currency).model_dump(mode='json')

    @classmethod
    def from_contract(cls, value):
        """A `Money` from an `Amount` or its dict (validated by `Amount`: a JSON number is
        refused with a pydantic `ValidationError`); a currency outside `CURRENCIES` is a
        `ValueError`."""
        if isinstance(value, dict):
            value = Amount.model_validate(value)
        if not isinstance(value, Amount):
            raise TypeError(f'from_contract takes an Amount or a dict, '
                            f'not a {type(value).__name__}')
        return cls(value.amount, value.currency)


__all__ = ['CURRENCIES', 'CurrencyMismatch', 'Money']

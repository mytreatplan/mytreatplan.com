"""Signed configuration snapshots (0.10.0, architecture AD-3 item 1, AD-4, AD-22,
interface I5): the admin site serves its configuration snapshot
(`mytp_core.contracts.config.ConfigSnapshot`) at ``GET /api/v1/config`` as

    {"snapshot": {...}, "signature": "<jwt>"}

The signature is a JWT signed with EdDSA by the admin site's interface key (the key of
`mytp_core.interface`; header ``kid``), with the claims:

- ``iss``: the admin site; ``aud``: the portal site that asked;
- ``iat``, ``exp``: issued and expiry times (seconds), ``exp`` at most 60 s after ``iat``;
- ``typ``: ``"config"`` (a request token can never pass as a snapshot token);
- ``ver``: the snapshot's version;
- ``sha``: SHA-256 hex of the snapshot object's canonical JSON
  (`contracts.config.snapshot_sha`: sorted keys, no spaces, UTF-8), as sent, unknown
  fields included.

`sign_snapshot(snapshot, audience=...)` builds that answer (the admin site);
`verify_snapshot(data, keyring=..., issuer=...)` checks it (a portal) and returns the
`ConfigSnapshot`, or raises `SnapshotRefused` with one of these codes:

- ``bad_signature``: no signature, a token that does not parse, another algorithm, an
  issuer other than the expected admin site, a key not in the keyring, a signature that
  does not verify, claims of the wrong type, ``typ`` not ``config``, a ``sha`` or a
  ``ver`` that does not match the snapshot;
- ``audience``: the token is for another site;
- ``expired``: ``exp`` passed, more than 60 s after ``iat``, or ``iat`` more than 30 s
  ahead of the reader's clock;
- ``invalid_body``: the answer or the snapshot does not have the contract's shape;
- ``newer_format``: a signed snapshot whose ``min_reader`` is above `SNAPSHOT_READER`
  (`SnapshotRefused.version` says which version was kept out). ``version`` and
  ``min_reader`` are read from the signed object before the rest is parsed, as a newer
  format may reshape what this reader cannot parse.

Whether the version is higher than the one held is the reader's own check. Nothing here
logs or puts the snapshot, a token or a key in an error.
"""
import hmac
import re
import time

import jwt
from django.conf import settings

from mytp_core import interface
from mytp_core.contracts.config import (SNAPSHOT_READER, ConfigResponse, ConfigSnapshot,
                                        canonical_json, snapshot_sha)

TYP = 'config'

BAD_SIGNATURE = 'bad_signature'
AUDIENCE = 'audience'
EXPIRED = 'expired'
INVALID_BODY = 'invalid_body'
NEWER_FORMAT = 'newer_format'
REFUSAL_CODES = (BAD_SIGNATURE, AUDIENCE, EXPIRED, INVALID_BODY, NEWER_FORMAT)

_SHA_RE = re.compile(r'[0-9a-f]{64}')


class SnapshotRefused(interface.InterfaceError):
    """A snapshot answer was refused. `code` is one of REFUSAL_CODES; `version` is the
    snapshot's version when it was valid but of a newer format (else None)."""

    def __init__(self, code, version=None):
        self.code = code
        self.version = version
        super().__init__(f'snapshot refused: {code}')


def sign_snapshot(snapshot, *, audience, issuer=None, signing_key=None,
                  lifetime=interface.MAX_LIFETIME, now=None):
    """The JSON-ready answer ``{"snapshot": ..., "signature": ...}`` for `audience` (the
    portal site that asked). `snapshot` is a ConfigSnapshot or its JSON-ready dict (sent as
    given, unknown fields included); ValueError when it is not a valid ConfigSnapshot or
    not JSON-ready. The signing key defaults to the site's (`interface.get_signing_key`),
    the issuer to settings.SITE."""
    if isinstance(snapshot, ConfigSnapshot):
        snapshot = snapshot.model_dump(mode='json')
    if not isinstance(snapshot, dict):
        raise ValueError('a snapshot is a JSON object')
    canonical_json(snapshot)
    model = ConfigSnapshot.model_validate(snapshot)
    if signing_key is None:
        signing_key = interface.get_signing_key()
    issued = int(time.time() if now is None else now)
    claims = {
        'iss': issuer if issuer is not None else settings.SITE,
        'aud': audience,
        'iat': issued,
        'exp': issued + min(int(lifetime), interface.MAX_LIFETIME),
        'typ': TYP,
        'ver': model.version,
        'sha': snapshot_sha(snapshot),
    }
    return {'snapshot': snapshot, 'signature': signing_key.sign(claims)}


def _claims(token, keyring, issuer):
    try:
        header = jwt.get_unverified_header(token)
        unverified = jwt.decode(token, options={'verify_signature': False})
    except jwt.PyJWTError:
        raise SnapshotRefused(BAD_SIGNATURE) from None
    kid = header.get('kid')
    if header.get('alg') != interface.ALGORITHM or not isinstance(kid, str):
        raise SnapshotRefused(BAD_SIGNATURE)
    if unverified.get('iss') != issuer:
        raise SnapshotRefused(BAD_SIGNATURE)
    public_key = keyring.get(issuer, kid)
    if public_key is None:
        raise SnapshotRefused(BAD_SIGNATURE)
    try:
        claims = jwt.decode(token, public_key, algorithms=[interface.ALGORITHM], options={
            'verify_exp': False, 'verify_iat': False, 'verify_nbf': False,
            'verify_aud': False, 'verify_iss': False, 'verify_sub': False,
            'verify_jti': False})
    except jwt.PyJWTError:
        raise SnapshotRefused(BAD_SIGNATURE) from None
    if not (all(isinstance(claims.get(name), str) for name in ('iss', 'aud', 'typ', 'sha'))
            and all(type(claims.get(name)) is int for name in ('iat', 'exp', 'ver'))
            and claims['iss'] == issuer and claims['typ'] == TYP):
        raise SnapshotRefused(BAD_SIGNATURE)
    return claims


def verify_snapshot(data, *, keyring, issuer, audience=None, now=None,
                    reader=SNAPSHOT_READER):
    """The ConfigSnapshot of a signed answer (`data`: the JSON object the admin site
    answered), checked against `keyring` (the admin site's public keys) for the admin
    site `issuer` and this site (`audience`, default settings.SITE); SnapshotRefused
    otherwise. Nothing is trusted before the signature, the ``sha`` and the ``ver`` match."""
    if not isinstance(data, dict):
        raise SnapshotRefused(INVALID_BODY)
    signature = data.get('signature')
    if not isinstance(signature, str) or not signature \
            or len(signature) > interface.MAX_TOKEN_LENGTH:
        raise SnapshotRefused(BAD_SIGNATURE)
    try:
        answer = ConfigResponse.model_validate(data)
    except ValueError:
        raise SnapshotRefused(INVALID_BODY) from None
    claims = _claims(answer.signature, keyring, issuer)
    if claims['aud'] != (settings.SITE if audience is None else audience):
        raise SnapshotRefused(AUDIENCE)
    current = int(time.time() if now is None else now)
    if (claims['exp'] <= current or claims['exp'] > claims['iat'] + interface.MAX_LIFETIME
            or claims['iat'] > current + interface.CLOCK_SKEW):
        raise SnapshotRefused(EXPIRED)
    try:
        sha = snapshot_sha(answer.snapshot)
    except ValueError:
        raise SnapshotRefused(INVALID_BODY) from None
    if not (_SHA_RE.fullmatch(claims['sha']) and hmac.compare_digest(claims['sha'], sha)):
        raise SnapshotRefused(BAD_SIGNATURE)
    # The version and the format first, from the raw object: a newer format may reshape
    # the rest, which this reader then cannot parse.
    version = answer.snapshot.get('version')
    min_reader = answer.snapshot.get('min_reader')
    if not (type(version) is int and type(min_reader) is int
            and version >= 1 and min_reader >= 1):
        raise SnapshotRefused(INVALID_BODY)
    if version != claims['ver']:
        raise SnapshotRefused(BAD_SIGNATURE)
    if min_reader > reader:
        raise SnapshotRefused(NEWER_FORMAT, version)
    try:
        return ConfigSnapshot.model_validate(answer.snapshot)
    except ValueError:
        raise SnapshotRefused(INVALID_BODY) from None

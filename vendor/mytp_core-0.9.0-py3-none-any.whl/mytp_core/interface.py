"""Signed calls between the MyTreatPlan sites (0.6.0, architecture AD-4, interfaces I1/I2):
the admin site and each regional portal call each other with requests signed by the
caller's own Ed25519 key, checked against the caller's public key.

A request carries ``Authorization: MyTP-Signature <token>``. The token is a JWT signed
with EdDSA (PyJWT), its header names the key (``kid``), and its claims are:

- ``iss``: the caller's SITE; ``aud``: the receiver's SITE;
- ``iat`` and ``exp``: issued and expiry times (seconds), ``exp`` at most 60 s after ``iat``;
- ``jti``: a random uuid4, accepted once (the replay cache);
- ``req``: the SHA-256 hex of ``METHOD\\nPATH?QUERY\\nBODY`` (``?QUERY`` only when there is
  a query), so the token is good for that one request only.

The receiver (`verify_request`, or `verify_django_request` for a Django request) checks,
in this order: the header is there (``missing``), the token parses and is EdDSA
(``signature``), ``iss`` and ``kid`` are in its keyring (``unknown_key``), the signature
and the claims' types (``signature``), ``aud`` is its own SITE (``audience``), ``exp`` has
not passed, is at most ``iat`` + 60 and ``iat`` is at most 30 s ahead (``expired``),
``req`` matches the request received (``request_hash``), and last ``jti`` was never seen
(``replayed``: ``cache.add`` of ``mytp:jti:<iss>:<jti>``, atomic in the database cache).
A failure raises `VerificationFailed` with one of those codes; the site answers 401 with
`refusal_body(code)` and nothing else.

Keys:

- The site's own signing key is a 32-byte Ed25519 seed. On the servers it is a KMS data
  key: ``INTERFACE_SIGNING_KMS_KEY = <kid>:<wrapped key>`` (`manage.py
  generate_interface_signing_key <kid>`), unwrapped through the KMS on first use and kept
  in memory for the life of the process (a failed unwrap is not kept). Tests and local
  development use ``INTERFACE_SIGNING_KEY = <kid>:<base64 seed>``, as the plain field keys.
- The peers' public keys (`Keyring`): ``(site, kid) -> public key``. A portal reads them
  from ``INTERFACE_PEER_KEYS = <site>:<kid>:<base64 public key>,...`` (`Keyring.parse`);
  the admin site from its database (`Keyring.from_entries`). Several kids per site allow
  a rotation: the caller signs with the new kid once the receiver has both.

Outbound (`signed_get`; `signed_post` with a JSON body, 0.8.0): urllib with
``EXTERNAL_CHECK_TIMEOUT`` and ``EXTERNAL_CHECK_USER_AGENT``; failures raise
`PeerCallFailed` with a short, safe text (a body over `signed_post`'s limit raises
`BodyTooLarge` instead, before any call: it is final, never retried).

Never in a log, an error or a repr: the seed, the private key or a token.
"""
import base64
import binascii
import hashlib
import hmac
import http.client
import json
import re
import socket
import ssl
import threading
import time
import urllib.error
import urllib.request
import uuid
from dataclasses import dataclass
from urllib.parse import unquote, urlsplit

import jwt
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (Ed25519PrivateKey,
                                                               Ed25519PublicKey)
from django.conf import settings
from django.utils.encoding import escape_uri_path, iri_to_uri

from mytp_core import crypto, kms
from mytp_core.contracts import errors as contract_errors

SCHEME = 'MyTP-Signature'
ALGORITHM = 'EdDSA'
MAX_LIFETIME = 60          # seconds from iat to exp, at most
CLOCK_SKEW = 30            # seconds an iat may be ahead of the receiver's clock
MAX_TOKEN_LENGTH = 4096
SEED_SIZE = 32
MAX_RESPONSE_BYTES = 1024 * 1024
JTI_CACHE_PREFIX = 'mytp:jti'

KMS_SETTING = 'INTERFACE_SIGNING_KMS_KEY'
PLAIN_SETTING = 'INTERFACE_SIGNING_KEY'
PEER_KEYS_SETTING = 'INTERFACE_PEER_KEYS'

# Site names, as the sites' SITE setting.
SITE_RE = re.compile(r'^[a-z]([a-z0-9-]{0,18}[a-z0-9])?$')
KID_RE = crypto.KEY_ID_RE
_REQ_RE = re.compile(r'[0-9a-f]{64}')

# The refusal codes (named in mytp_core.contracts.errors, 0.7.0), with the only text a
# refusal gives.
REASONS = {
    contract_errors.MISSING: 'The request has no MyTP-Signature authorization.',
    contract_errors.SIGNATURE: 'The request signature is not valid.',
    contract_errors.UNKNOWN_KEY: 'The signing key is not known.',
    contract_errors.AUDIENCE: 'The request is not addressed to this site.',
    contract_errors.EXPIRED: 'The request signature has expired or is not valid yet.',
    contract_errors.REQUEST_HASH: 'The signature does not match this request.',
    contract_errors.REPLAYED: 'The request signature was already used.',
}


class InterfaceError(Exception):
    """Base of this module's errors. Their text never holds a key or a token."""


class InterfaceConfigurationError(InterfaceError):
    """An INTERFACE_* setting is missing or malformed (names the setting)."""


class SigningKeyUnavailable(InterfaceError):
    """The site's signing key is not configured, or the KMS could not unwrap it."""


class VerificationFailed(InterfaceError):
    """A signed request was refused. `code` is one of REASONS; `iss` and `kid` are what
    the token claimed (unverified, may be empty)."""

    def __init__(self, code, iss='', kid=''):
        self.code = code
        self.iss = iss
        self.kid = kid
        super().__init__(f'refused: {code}')


class PeerCallFailed(InterfaceError):
    """An outbound call failed: no answer, an HTTP error or a bad answer. `status` is the
    HTTP status, if any; `code` the peer's error code, if it gave one."""

    def __init__(self, detail, status=None, code=''):
        self.status = status
        self.code = code
        super().__init__(detail)


class BodyTooLarge(ValueError):
    """`signed_post`'s body is larger than its `max_body_bytes` (0.8.0): refused before
    any call. Final: the same body would be refused again, so it is not a call failure
    to retry."""

    def __init__(self, size, limit):
        self.size = size
        self.limit = limit
        super().__init__(f'the body is larger than {limit} bytes')


def refusal_body(code):
    """The JSON body of a refusal: ``{"error": {"code": ..., "message": ...}}``, built
    through the contract's error model (0.7.0, `mytp_core.contracts.errors`)."""
    return contract_errors.error_body(code, REASONS.get(code, 'Refused.'))


# --- Keys -------------------------------------------------------------------------------

def _b64decode(text, size, what):
    try:
        raw = base64.b64decode((text or '').strip(), validate=True)
    except (binascii.Error, ValueError):
        raise InterfaceConfigurationError(f'{what} is not valid base64.') from None
    if len(raw) != size:
        raise InterfaceConfigurationError(f'{what} must be {size} bytes, not {len(raw)}.')
    return raw


def parse_public_key(text, what='the public key'):
    """An Ed25519 public key from its base64 raw form (32 bytes)."""
    return Ed25519PublicKey.from_public_bytes(_b64decode(text, 32, what))


def public_key_text(public_key):
    """The base64 raw form of an Ed25519 public key (44 characters)."""
    raw = public_key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    return base64.b64encode(raw).decode('ascii')


def check_site(value, what='the site name'):
    if not SITE_RE.fullmatch(value or ''):
        raise InterfaceConfigurationError(
            f'{what} must be a site name (lowercase letters, digits and "-").')
    return value


def check_kid(value, what='the key id'):
    if not KID_RE.fullmatch(value or ''):
        raise InterfaceConfigurationError(
            f'{what} may hold letters, digits, "-" and "_" (at most 32 characters).')
    return value


class SigningKey:
    """The site's private signing key and its kid. The repr shows the kid only."""

    def __init__(self, kid, seed):
        if len(seed) != SEED_SIZE:
            raise SigningKeyUnavailable(f'the signing key {kid!r} must be {SEED_SIZE} bytes.')
        self.kid = kid
        self._private = Ed25519PrivateKey.from_private_bytes(bytes(seed))

    def __repr__(self):
        return f'<SigningKey kid={self.kid!r}>'

    @property
    def public_key(self):
        return self._private.public_key()

    @property
    def public_text(self):
        return public_key_text(self.public_key)

    def sign(self, claims):
        return jwt.encode(claims, self._private, algorithm=ALGORITHM,
                          headers={'kid': self.kid})


def _single_entry(value, setting, parse):
    entries = parse(value, setting)
    if len(entries) != 1:
        raise InterfaceConfigurationError(f'{setting} must hold exactly one <kid>:<key> entry.')
    return entries[0]


def signing_key_setting():
    """(setting name, kid, value) of the configured signing key, parsed without any KMS
    call; SigningKeyUnavailable when neither setting is set, InterfaceConfigurationError
    when one is malformed or both are set."""
    wrapped = (getattr(settings, KMS_SETTING, '') or '').strip()
    plain = (getattr(settings, PLAIN_SETTING, '') or '').strip()
    if wrapped and plain:
        raise InterfaceConfigurationError(f'Set {KMS_SETTING} or {PLAIN_SETTING}, not both.')
    try:
        if wrapped:
            kid, value = _single_entry(wrapped, KMS_SETTING, crypto.parse_wrapped_key_list)
            return KMS_SETTING, kid, value
        if plain:
            kid, value = _single_entry(plain, PLAIN_SETTING, crypto.parse_key_list)
            return PLAIN_SETTING, kid, value
    except crypto.KeyConfigurationError as exc:
        raise InterfaceConfigurationError(str(exc)) from None
    raise SigningKeyUnavailable(
        f'No signing key: set {KMS_SETTING} (`manage.py generate_interface_signing_key '
        f'<kid>`), or {PLAIN_SETTING} in local development.')


def signing_key_configured():
    """Whether a well-formed signing key setting is present (no KMS call)."""
    try:
        signing_key_setting()
    except InterfaceError:
        return False
    return True


_signing_key = None
_signing_key_source = None
_signing_lock = threading.Lock()


def get_signing_key():
    """The site's SigningKey, built once per process (the wrapped seed unwrapped through
    the KMS on first use; a failure is not kept, so the next call retries). Raises
    SigningKeyUnavailable or InterfaceConfigurationError."""
    global _signing_key, _signing_key_source
    setting, kid, value = signing_key_setting()
    # The change marker is a digest of the setting, never the (plain) seed itself.
    raw = value if isinstance(value, bytes) else value.encode('utf-8')
    source = hashlib.sha256(f'{setting}\0{kid}\0'.encode('utf-8') + raw).hexdigest()
    del raw
    key = _signing_key
    if key is not None and _signing_key_source == source:
        return key
    with _signing_lock:
        if _signing_key is not None and _signing_key_source == source:
            return _signing_key
        if setting == KMS_SETTING:
            try:
                seed = crypto.unwrap_data_key(KMS_SETTING, kid, value)
            except crypto.KeyUnavailableError as exc:
                raise SigningKeyUnavailable(str(exc)) from None
        else:
            seed = value
        key = SigningKey(kid, seed)
        del seed
        _signing_key, _signing_key_source = key, source
        return key


def reset_signing_key():
    """Forget the process's signing key (tests, or after changing the setting)."""
    global _signing_key, _signing_key_source
    with _signing_lock:
        _signing_key = _signing_key_source = None


class Keyring:
    """The peers' public keys, by (site, kid)."""

    def __init__(self, keys=None):
        self._keys = dict(keys or {})

    def __repr__(self):
        return f'<Keyring {sorted(self._keys)}>'

    def __len__(self):
        return len(self._keys)

    def __contains__(self, site_kid):
        return site_kid in self._keys

    def get(self, site, kid):
        return self._keys.get((site, kid))

    @classmethod
    def from_entries(cls, entries, what='a peer key'):
        """From (site, kid, base64 public key) triples; InterfaceConfigurationError on a
        malformed or repeated one."""
        keys = {}
        for site, kid, public in entries:
            check_site(site, f'{what}: the site')
            check_kid(kid, f'{what}: the key id')
            if (site, kid) in keys:
                raise InterfaceConfigurationError(f'{what}: {site}:{kid} appears twice.')
            keys[(site, kid)] = parse_public_key(public, f'{what} {site}:{kid}')
        return cls(keys)

    @classmethod
    def parse(cls, value, setting=PEER_KEYS_SETTING):
        """From ``<site>:<kid>:<base64 public key>,...``; empty gives an empty keyring."""
        entries = []
        for position, entry in enumerate((value or '').split(','), start=1):
            entry = entry.strip()
            if not entry:
                if (value or '').strip():
                    raise InterfaceConfigurationError(f'{setting}: entry {position} is empty.')
                continue
            parts = entry.split(':')
            if len(parts) != 3:
                raise InterfaceConfigurationError(
                    f'{setting}: entry {position} is not <site>:<kid>:<public key>.')
            entries.append(parts)
        return cls.from_entries(entries, f'{setting}')

    @classmethod
    def from_settings(cls):
        return cls.parse(getattr(settings, PEER_KEYS_SETTING, '') or '')


# --- Tokens -----------------------------------------------------------------------------

def request_target(path, query='', *, decoded=False):
    """The canonical ``PATH?QUERY`` (``PATH`` when there is no query) both sides hash: the
    path percent-decoded once (unless it is already `decoded`, as Django's `request.path`)
    and re-encoded with `escape_uri_path`, the query as Django's `get_full_path` gives it
    (`iri_to_uri`). So a caller's `/a%7Eb%2Fc` matches what Django received."""
    path = path or '/'
    if not decoded:
        path = unquote(path)
    path = escape_uri_path(path)
    query = iri_to_uri(query or '')
    return f'{path}?{query}' if query else path


def request_hash(method, target, body=b''):
    """SHA-256 hex of ``METHOD\\nPATH?QUERY\\nBODY``."""
    if isinstance(body, str):
        body = body.encode('utf-8')
    head = f'{method.upper()}\n{target}\n'.encode('utf-8')
    return hashlib.sha256(head + (body or b'')).hexdigest()


def sign_request(method, target, body=b'', *, audience, issuer=None, signing_key=None,
                 lifetime=MAX_LIFETIME, now=None):
    """A token for one request (METHOD, ``PATH?QUERY``, body) to `audience`."""
    if signing_key is None:
        signing_key = get_signing_key()
    issued = int(time.time() if now is None else now)
    claims = {
        'iss': issuer if issuer is not None else settings.SITE,
        'aud': audience,
        'iat': issued,
        'exp': issued + min(int(lifetime), MAX_LIFETIME),
        'jti': str(uuid.uuid4()),
        'req': request_hash(method, target, body),
    }
    return signing_key.sign(claims)


def authorization_header(token):
    return f'{SCHEME} {token}'


def _token_from(authorization):
    scheme, _, token = (authorization or '').strip().partition(' ')
    token = token.strip()
    if scheme != SCHEME or not token:
        raise VerificationFailed('missing')
    if len(token) > MAX_TOKEN_LENGTH:
        raise VerificationFailed('signature')
    return token


def _replay_cache():
    from django.core.cache import cache
    return cache


def _is_uuid4(text):
    """Whether `text` is a uuid4 in its canonical form (lowercase, hyphenated)."""
    try:
        value = uuid.UUID(text)
    except (ValueError, TypeError, AttributeError):
        return False
    return value.version == 4 and str(value) == text


class Claims(dict):
    """A verified token's claims; `kid` is the key id from its header."""

    def __init__(self, claims, kid):
        super().__init__(claims)
        self.kid = kid


def verify_request(authorization, method, target, body, *, keyring, audience=None,
                   now=None, cache=None):
    """The verified Claims of a signed request (`claims.kid` the key that signed it), or
    VerificationFailed(code)."""
    token = _token_from(authorization)
    try:
        header = jwt.get_unverified_header(token)
        unverified = jwt.decode(token, options={'verify_signature': False})
    except jwt.PyJWTError:
        raise VerificationFailed('signature') from None
    kid = header.get('kid')
    iss = unverified.get('iss')
    kid = kid if isinstance(kid, str) else ''
    iss = iss if isinstance(iss, str) else ''
    if header.get('alg') != ALGORITHM:
        raise VerificationFailed('signature', iss, kid)
    public_key = keyring.get(iss, kid) if iss and kid else None
    if public_key is None:
        raise VerificationFailed('unknown_key', iss, kid)
    try:
        claims = jwt.decode(token, public_key, algorithms=[ALGORITHM], options={
            'verify_exp': False, 'verify_iat': False, 'verify_nbf': False,
            'verify_aud': False, 'verify_iss': False, 'verify_sub': False,
            'verify_jti': False})
    except jwt.PyJWTError:
        raise VerificationFailed('signature', iss, kid) from None
    if not (all(isinstance(claims.get(name), str) for name in ('iss', 'aud', 'jti', 'req'))
            and all(type(claims.get(name)) is int for name in ('iat', 'exp'))
            and _is_uuid4(claims['jti'])):
        raise VerificationFailed('signature', iss, kid)
    if claims['aud'] != (settings.SITE if audience is None else audience):
        raise VerificationFailed('audience', iss, kid)
    current = int(time.time() if now is None else now)
    if (claims['exp'] <= current or claims['exp'] > claims['iat'] + MAX_LIFETIME
            or claims['iat'] > current + CLOCK_SKEW):
        raise VerificationFailed('expired', iss, kid)
    if not (_REQ_RE.fullmatch(claims['req'])
            and hmac.compare_digest(claims['req'], request_hash(method, target, body))):
        raise VerificationFailed('request_hash', iss, kid)
    cache = cache if cache is not None else _replay_cache()
    timeout = claims['exp'] - current + CLOCK_SKEW
    if not cache.add(f'{JTI_CACHE_PREFIX}:{iss}:{claims["jti"]}', 1, timeout=timeout):
        raise VerificationFailed('replayed', iss, kid)
    return Claims(claims, kid=kid)


def verify_django_request(request, keyring, audience=None, now=None):
    """`verify_request` for a Django request (its method, canonical path and query, and
    body; `request_target`)."""
    target = request_target(request.path, request.META.get('QUERY_STRING', ''), decoded=True)
    return verify_request(request.META.get('HTTP_AUTHORIZATION', ''), request.method,
                          target, request.body, keyring=keyring, audience=audience, now=now)


# --- Outbound ---------------------------------------------------------------------------

@dataclass(frozen=True)
class PeerResponse:
    status: int
    data: dict


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """Follows no redirect: urllib would resend the Authorization header (a live, unused
    token) to the new address. A 3xx then fails as an HTTPError (`HTTP 302`)."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _open(request, timeout):
    """The HTTP call, following no redirect (tests replace it)."""
    return urllib.request.build_opener(_NoRedirect).open(request, timeout=timeout)


def _network_reason(reason):
    if isinstance(reason, (socket.timeout, TimeoutError)):
        return 'timed out'
    if isinstance(reason, socket.gaierror):
        return 'could not resolve the host'
    if isinstance(reason, ssl.SSLError):
        return f'TLS error {kms.safe_text(getattr(reason, "reason", None) or "")}'
    if isinstance(reason, ConnectionRefusedError):
        return 'connection refused'
    if isinstance(reason, BaseException):
        return type(reason).__name__
    return kms.safe_text(reason)


def _json_object(raw):
    try:
        data = json.loads(raw)
    except ValueError:
        return None
    return data if isinstance(data, dict) else None


def _error_code(raw):
    data = _json_object(raw) or {}
    error = data.get('error')
    code = error.get('code') if isinstance(error, dict) else None
    return kms.safe_text(code) if isinstance(code, str) and code else ''


def _check_keys(data):
    stack = [data]
    seen = set()
    while stack:
        value = stack.pop()
        if isinstance(value, (dict, list, tuple)):
            if id(value) in seen:
                continue  # json.dumps reports a cycle itself
            seen.add(id(value))
        if isinstance(value, dict):
            if not all(isinstance(key, str) for key in value):
                raise TypeError('a JSON body has string keys only')
            stack.extend(value.values())
        elif isinstance(value, (list, tuple)):
            stack.extend(value)


def json_body(data):
    """The bytes `signed_post` sends for `data` (a JSON-ready object): compact UTF-8 JSON.
    The signature covers these exact bytes. TypeError for a key that is not a string
    (json would turn 1 and "1" into the same key twice)."""
    _check_keys(data)
    return json.dumps(data, ensure_ascii=False, separators=(',', ':'),
                      allow_nan=False).encode('utf-8')


def _signed_call(method, url, body, *, audience, signing_key, timeout, max_bytes):
    parts = urlsplit(url)
    if parts.scheme not in ('https', 'http') or not parts.hostname:
        raise PeerCallFailed('the peer URL must be https://host/...')
    if parts.scheme == 'http' and not settings.DEBUG:
        raise PeerCallFailed('the peer URL must be https:// (http only with DEBUG on: the '
                             'token would travel in clear text)')
    token = sign_request(method, request_target(parts.path, parts.query), body,
                         audience=audience, signing_key=signing_key)
    headers = {
        'Authorization': authorization_header(token),
        'Accept': 'application/json',
        'User-Agent': getattr(settings, 'EXTERNAL_CHECK_USER_AGENT', 'mytp-core'),
    }
    if method == 'POST':
        headers['Content-Type'] = 'application/json'
    request = urllib.request.Request(url, method=method, headers=headers,
                                     data=body if method == 'POST' else None)
    timeout = settings.EXTERNAL_CHECK_TIMEOUT if timeout is None else timeout
    try:
        with _open(request, timeout) as response:
            status = response.status
            raw = response.read(max_bytes + 1)
    except urllib.error.HTTPError as exc:
        status = exc.code
        try:
            raw = exc.read(4096)
        except Exception:  # noqa: BLE001 - the error body is optional
            raw = b''
        exc.close()
        code = _error_code(raw)
        raise PeerCallFailed(f'HTTP {status}' + (f' ({code})' if code else ''),
                             status, code) from None
    except urllib.error.URLError as exc:
        raise PeerCallFailed(f'no answer: {_network_reason(exc.reason)}') from None
    except (OSError, http.client.HTTPException) as exc:
        raise PeerCallFailed(f'no answer: {_network_reason(exc)}') from None
    if len(raw) > max_bytes:
        raise PeerCallFailed(f'the answer is larger than {max_bytes} bytes', status)
    data = _json_object(raw)
    if data is None:
        raise PeerCallFailed('the answer is not a JSON object', status)
    if not 200 <= status < 300:
        raise PeerCallFailed(f'HTTP {status}', status, _error_code(raw))
    return PeerResponse(status, data)


def signed_get(url, *, audience, signing_key=None, timeout=None,
               max_bytes=MAX_RESPONSE_BYTES):
    """GET `url` signed for `audience`; a PeerResponse with the JSON object it answered.
    PeerCallFailed (no answer, an HTTP error with the peer's error code, a body that is
    too long or not a JSON object); SigningKeyUnavailable without a signing key."""
    return _signed_call('GET', url, b'', audience=audience, signing_key=signing_key,
                        timeout=timeout, max_bytes=max_bytes)


def signed_post(url, data, *, audience, signing_key=None, timeout=None,
                max_bytes=MAX_RESPONSE_BYTES, max_body_bytes=None):
    """POST `data` (a JSON-ready object, sent as `json_body(data)` with
    ``Content-Type: application/json``) to `url`, signed for `audience` (the token's
    ``req`` covers the body); a PeerResponse with the JSON object it answered (0.8.0).
    PeerCallFailed as `signed_get`; BodyTooLarge (a ValueError, final) before any call
    when the body is larger than `max_body_bytes` (no limit when None); ValueError when
    `data` is not JSON-ready (a float NaN, a set, a key that is not a string);
    SigningKeyUnavailable without a signing key. No error text holds the body."""
    try:
        body = json_body(data)
    except (TypeError, ValueError):
        raise ValueError('the body is not JSON-ready') from None
    if max_body_bytes is not None and len(body) > max_body_bytes:
        raise BodyTooLarge(len(body), max_body_bytes)
    return _signed_call('POST', url, body, audience=audience, signing_key=signing_key,
                        timeout=timeout, max_bytes=max_bytes)

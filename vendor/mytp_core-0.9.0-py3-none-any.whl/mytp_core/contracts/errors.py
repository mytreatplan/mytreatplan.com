"""The error body every interface answer uses (0.7.0, architecture conventions "Errors"):
``{"error": {"code": "<snake_case>", "message": "<text>"}}`` with the HTTP status. No
stack trace or detail beyond the message crosses sites."""
import re

from pydantic import Field

from .base import ContractModel

CODE_PATTERN = r'^[a-z][a-z0-9_]{0,63}$'
CODE_RE = re.compile(CODE_PATTERN)

# The 401 refusals of a signed request (0.6.0, mytp_core.interface.REASONS).
MISSING = 'missing'
SIGNATURE = 'signature'
UNKNOWN_KEY = 'unknown_key'
AUDIENCE = 'audience'
EXPIRED = 'expired'
REQUEST_HASH = 'request_hash'
REPLAYED = 'replayed'
REFUSAL_CODES = (MISSING, SIGNATURE, UNKNOWN_KEY, AUDIENCE, EXPIRED, REQUEST_HASH, REPLAYED)

# The 503 of a site whose interface is not configured (no signing key, bad settings).
UNAVAILABLE = 'unavailable'


class ErrorDetail(ContractModel):
    code: str = Field(pattern=CODE_PATTERN, description='A short snake_case code.')
    message: str = Field(max_length=500, description='A short text, safe to show.')


class ErrorBody(ContractModel):
    error: ErrorDetail


def error_body(code, message):
    """The JSON-ready error body (a dict); ValidationError for a malformed code."""
    return ErrorBody(error=ErrorDetail(code=code, message=message)).model_dump(mode='json')

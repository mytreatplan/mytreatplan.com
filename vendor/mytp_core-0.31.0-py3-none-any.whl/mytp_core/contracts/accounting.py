"""The accounting feed events (0.31.0, architecture AD-18, AD-23; epic-payments entry 8): a
regional portal gives the admin site a central copy of what it invoices and collects.

- ``invoice.issued`` (`InvoiceIssued`): an invoice, a manual invoice or a credit note, as
  issued (``kind`` ``order``, ``manual`` or ``credit_note``). Aggregate ``invoice``,
  ``aggregate_id`` the invoice UUID.
- ``payment.confirmed`` (`PaymentConfirmed`): a gateway or bank-transfer payment that paid
  an order. Aggregate ``payment``, ``aggregate_id`` the payment UUID.
- ``refund.completed`` (`RefundCompleted`): a refund that settled (its credit note is an
  ``invoice.issued``). Aggregate ``refund``, ``aggregate_id`` the refund UUID.

Each record is sent once, when it is created: ``aggregate_version`` and the event version
are 1. Amounts are the closed ``{"amount": "100.00", "currency": "EUR"}`` (negative on a
credit note); percents are strings (``"21.00"``). The doctor is referenced by
``client_uid`` only (a plain UUID, left out when the record has no account), so the
erasure of an account (``client.erased``) never touches the accounting copy. The buyer is
the identity as issued (personal data the accounting copy must keep; the admin site stores
it encrypted).

No patient name: a line carries ``patient_code`` (``EU-7K3QX9MD``) only, and the key is
left out when the line has none. A staff-typed manual line ``name`` cannot be checked by
the contract: staff must not type a patient's name there. A refund's staff note, gateway
secrets and card data are never part of it.

Writers build with `build_payload` (the closed models); readers validate with the
``*Reader`` models (the same rules, unknown fields dropped; `ACCOUNTING_READERS`).
"""
from datetime import date
from typing import Annotated, Literal

from pydantic import BaseModel, Field, StrictBool, StringConstraints, model_serializer

from .amounts import Amount
from .base import ContractModel, WriterModel
from .events import CanonicalUuid, Positive, UtcTime
from .voucher_usage import OrderReference, UsageAmount

INVOICE_ISSUED = 'invoice.issued'
PAYMENT_CONFIRMED = 'payment.confirmed'
REFUND_COMPLETED = 'refund.completed'

INVOICE_KINDS = ('order', 'manual', 'credit_note')
CREDIT_NOTE_REASONS = ('cancellation', 'goodwill', 'error')

Text = Annotated[str, StringConstraints(max_length=200)]
Short = Annotated[str, StringConstraints(max_length=150)]
Code = Annotated[str, StringConstraints(max_length=64)]
TaxId = Annotated[str, StringConstraints(max_length=40)]
Number = Annotated[str, StringConstraints(min_length=1, max_length=40)]
# A VAT or discount percent as a string with two places, 0.00 to 100.00.
Percent = Annotated[str, StringConstraints(pattern=r'^(100\.00|[0-9]{1,2}\.[0-9]{2})$')]
PatientCode = Annotated[str, StringConstraints(pattern=r'^[A-Z]{2}-[0-9A-Z]{8}$')]
Country = Annotated[str, StringConstraints(max_length=2, pattern=r'^([A-Z]{2})?$')]
OptionalEmail = Annotated[str, StringConstraints(max_length=254,
                                                 pattern=r'^([\s\S]+@[^@]+)?$')]
TaxCategory = Literal['S', 'Z', 'E', 'AE']


class _SellerFields(BaseModel):
    legal_name: Text
    address: Annotated[str, StringConstraints(max_length=2000)]
    country: Country
    company_number: Code
    vat_number: Code
    tax_number: Code


class _BuyerFields(BaseModel):
    kind: Annotated[str, StringConstraints(max_length=10)]
    first_name: Short
    last_name: Short
    legal_name: Text
    tax_id: TaxId
    vat_id: TaxId
    address_line1: Text
    address_line2: Text
    city: Short
    postal_code: Annotated[str, StringConstraints(max_length=30)]
    province: Short
    country: Country
    billing_email: OptionalEmail
    entity_id: CanonicalUuid | None = None
    entity_version: Positive | None = None
    vies_status: Annotated[str, StringConstraints(max_length=14)] = ''


class _VatGroupFields(BaseModel):
    percent: Percent
    text: Annotated[str, StringConstraints(max_length=500)]


class _LineFields(BaseModel):
    position: Positive
    code: Code
    name: Short
    quantity: Positive
    discount_percent: Percent
    vat_percent: Percent
    vat_text: Annotated[str, StringConstraints(max_length=500)]
    tax_category: TaxCategory
    included_case: StrictBool


def _without_absent(data, names):
    """A dumped model without its optional keys that are None: absent stays absent."""
    if isinstance(data, dict):
        for name in names:
            if name in data and data[name] is None:
                del data[name]
    return data


class InvoiceSeller(_SellerFields, WriterModel):
    """The seller of an invoice, as issued (closed)."""


class InvoiceSellerReader(_SellerFields, ContractModel):
    """The seller, as the admin site reads it."""


class InvoiceBuyer(_BuyerFields, WriterModel):
    """The buyer of an invoice, as issued (closed)."""


class InvoiceBuyerReader(_BuyerFields, ContractModel):
    """The buyer, as the admin site reads it."""


class InvoiceVatGroup(_VatGroupFields, WriterModel):
    """One VAT group of an invoice (closed)."""

    base: UsageAmount
    vat: UsageAmount


class InvoiceVatGroupReader(_VatGroupFields, ContractModel):
    """One VAT group, as the admin site reads it."""

    base: Amount
    vat: Amount


class InvoiceLine(_LineFields, WriterModel):
    """One line of an invoice (closed). ``patient_code`` is left out when there is none;
    there is never a patient name."""

    list_amount: UsageAmount
    discount_amount: UsageAmount
    ice: UsageAmount
    voucher_share: UsageAmount
    net: UsageAmount
    patient_code: PatientCode | None = None

    @model_serializer(mode='wrap')
    def _without_absent_fields(self, handler):
        return _without_absent(handler(self), ('patient_code',))


class InvoiceLineReader(_LineFields, ContractModel):
    """One line, as the admin site reads it."""

    list_amount: Amount
    discount_amount: Amount
    ice: Amount
    voucher_share: Amount
    net: Amount
    patient_code: PatientCode | None = None

    @model_serializer(mode='wrap')
    def _without_absent_fields(self, handler):
        return _without_absent(handler(self), ('patient_code',))


_INVOICE_ABSENT = ('client_uid', 'order_id', 'order_reference', 'original_id', 'reason')


class InvoiceIssued(WriterModel):
    """The payload of ``invoice.issued`` a portal writes (closed). ``client_uid``,
    ``order_id`` (an order invoice), ``original_id`` and ``reason`` (a credit note) are
    left out when they do not apply."""

    invoice_id: CanonicalUuid
    number: Number
    kind: Literal['order', 'manual', 'credit_note']
    client_uid: CanonicalUuid | None = None
    order_id: CanonicalUuid | None = None
    order_reference: OrderReference | None = None
    original_id: CanonicalUuid | None = None
    reason: Literal['cancellation', 'goodwill', 'error'] | None = None
    company_code: Annotated[str, StringConstraints(min_length=1, max_length=16)]
    instance: Annotated[str, StringConstraints(min_length=1, max_length=8)]
    issued_at: UtcTime
    issue_date: date
    time_zone: Annotated[str, StringConstraints(max_length=64)]
    seller: InvoiceSeller
    buyer: InvoiceBuyer
    lines: Annotated[list[InvoiceLine], Field(max_length=500)]
    vat_groups: Annotated[list[InvoiceVatGroup], Field(max_length=50)]
    net_total: UsageAmount
    discount_total: UsageAmount
    ice_total: UsageAmount
    voucher_taken: UsageAmount
    vat_total: UsageAmount
    total: UsageAmount

    @model_serializer(mode='wrap')
    def _without_absent_fields(self, handler):
        return _without_absent(handler(self), _INVOICE_ABSENT)


class InvoiceIssuedReader(ContractModel):
    """An invoice, as the admin site reads it (unknown fields dropped)."""

    invoice_id: CanonicalUuid
    number: Number
    kind: Literal['order', 'manual', 'credit_note']
    client_uid: CanonicalUuid | None = None
    order_id: CanonicalUuid | None = None
    order_reference: OrderReference | None = None
    original_id: CanonicalUuid | None = None
    reason: Literal['cancellation', 'goodwill', 'error'] | None = None
    company_code: Annotated[str, StringConstraints(min_length=1, max_length=16)]
    instance: Annotated[str, StringConstraints(min_length=1, max_length=8)]
    issued_at: UtcTime
    issue_date: date
    time_zone: Annotated[str, StringConstraints(max_length=64)]
    seller: InvoiceSellerReader
    buyer: InvoiceBuyerReader
    lines: Annotated[list[InvoiceLineReader], Field(max_length=500)]
    vat_groups: Annotated[list[InvoiceVatGroupReader], Field(max_length=50)]
    net_total: Amount
    discount_total: Amount
    ice_total: Amount
    voucher_taken: Amount
    vat_total: Amount
    total: Amount


class PaymentConfirmed(WriterModel):
    """The payload of ``payment.confirmed`` a portal writes (closed). No card data and no
    gateway secret: ``gateway_payment_id`` is the gateway's own reference."""

    payment_id: CanonicalUuid
    order_id: CanonicalUuid
    order_reference: OrderReference
    client_uid: CanonicalUuid | None = None
    invoice_id: CanonicalUuid | None = None
    gateway: Annotated[str, StringConstraints(min_length=1, max_length=20)]
    gateway_payment_id: Annotated[str, StringConstraints(max_length=100)]
    amount: UsageAmount
    confirmed_at: UtcTime

    @model_serializer(mode='wrap')
    def _without_absent_fields(self, handler):
        return _without_absent(handler(self), ('client_uid', 'invoice_id'))


class PaymentConfirmedReader(ContractModel):
    """A confirmed payment, as the admin site reads it."""

    payment_id: CanonicalUuid
    order_id: CanonicalUuid
    order_reference: OrderReference
    client_uid: CanonicalUuid | None = None
    invoice_id: CanonicalUuid | None = None
    gateway: Annotated[str, StringConstraints(min_length=1, max_length=20)]
    gateway_payment_id: Annotated[str, StringConstraints(max_length=100)]
    amount: Amount
    confirmed_at: UtcTime


class RefundCompleted(WriterModel):
    """The payload of ``refund.completed`` a portal writes (closed). The staff note is
    never sent."""

    refund_id: CanonicalUuid
    order_id: CanonicalUuid
    order_reference: OrderReference
    client_uid: CanonicalUuid | None = None
    payment_id: CanonicalUuid | None = None
    invoice_id: CanonicalUuid
    credit_note_id: CanonicalUuid
    amount: UsageAmount
    manual: StrictBool
    reason: Literal['cancellation', 'goodwill', 'error']
    gateway_refund_id: Annotated[str, StringConstraints(max_length=100)]
    completed_at: UtcTime

    @model_serializer(mode='wrap')
    def _without_absent_fields(self, handler):
        return _without_absent(handler(self), ('client_uid', 'payment_id'))


class RefundCompletedReader(ContractModel):
    """A completed refund, as the admin site reads it."""

    refund_id: CanonicalUuid
    order_id: CanonicalUuid
    order_reference: OrderReference
    client_uid: CanonicalUuid | None = None
    payment_id: CanonicalUuid | None = None
    invoice_id: CanonicalUuid
    credit_note_id: CanonicalUuid
    amount: Amount
    manual: StrictBool
    reason: Literal['cancellation', 'goodwill', 'error']
    gateway_refund_id: Annotated[str, StringConstraints(max_length=100)]
    completed_at: UtcTime


# The reader model of each accounting event type.
ACCOUNTING_READERS = {INVOICE_ISSUED: InvoiceIssuedReader,
                      PAYMENT_CONFIRMED: PaymentConfirmedReader,
                      REFUND_COMPLETED: RefundCompletedReader}

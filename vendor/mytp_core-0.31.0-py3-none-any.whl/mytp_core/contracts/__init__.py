"""The interface contracts between the sites (0.7.0, architecture AD-12, AD-23,
interface I3): pydantic 2 models of the shapes the admin site and the portals exchange,
the version policy and the checks that keep patient data, files and floats out of central
payloads.

- `errors`: ``{"error": {"code", "message"}}`` (`ErrorBody`, `error_body`) and the named
  codes (the 401 refusals, ``unavailable``).
- `amounts`: ``{"amount": "123.45", "currency": "EUR"}`` (`Amount`).
- `events`: the event envelope (`EventEnvelope`), the answer to an event POST
  (`EventResult`, `event_result`; 0.8.0), `MAX_EVENT_BYTES` and `utc_text` (0.8.0).
- `payloads` (0.8.0): the closed payload model of every event type
  (`register_payload`, `payload_model_for`, `build_payload`).
- `clients` (0.11.0): the client record events ``client.updated`` (`ClientUpdated`,
  read with `ClientUpdatedReader`) and ``client.erased`` (`ClientErased`,
  `ClientErasedReader`); the staging-only ``sample.recorded`` is gone.
- `contact_messages` (0.14.0): the contact message events ``contact_message.updated``
  (`ContactMessageUpdated`, read with `ContactMessageUpdatedReader`) and
  ``contact_message.deleted`` (`ContactMessageDeleted`, `ContactMessageDeletedReader`).
- `voucher_usage` (0.30.0): the voucher usage events ``voucher.redeemed``
  (`VoucherRedeemed`, read with `VoucherRedeemedReader`) and ``voucher.released``
  (`VoucherReleased`, `VoucherReleasedReader`).
- `accounting` (0.31.0): the accounting feed ``invoice.issued`` (`InvoiceIssued`, read
  with `InvoiceIssuedReader`), ``payment.confirmed`` (`PaymentConfirmed`) and
  ``refund.completed`` (`RefundCompleted`).
- `config` (0.10.0): the configuration snapshot (`ConfigSnapshot`, `AdminDirectoryEntry`),
  the answer to ``GET /api/v1/config`` (`ConfigResponse`), `SNAPSHOT_READER` and
  `snapshot_sha` (signed and verified by `mytp_core.snapshots`).
- `catalogue` (0.12.0): the snapshot's optional catalogue section (`CatalogueSection`:
  `CatalogueCountryGroup`, `CatalogueProduct`, `CatalogueSubscription`). 0.20.0: a
  product's optional texts per language (`ProductText`), code and validity dates, and a
  subscription's optional in-house TPS discount. 0.21.0: the section's optional add-ons
  (`CatalogueAddOn`), a product's optional size, per-unit quantity range (`PerUnit`),
  calls (`ProductCalls`) and cost links (`CostLink`), and the helpers that price a line
  (`line_price`, `check_quantity`, `add_on_applies`; `QuantityRefused`, `AddOnRefused`)
  and sum a product's cost on a date (`sum_costs`, `link_labels`, `ProductCost`,
  `MonthlyCost`). 0.22.0: a subscription's optional code, texts, linked products,
  discounts per product category, own price (`SubscriptionPrice`) and call extras
  (`CallExtras`), the section's optional manual subscriptions, and the helpers
  `subscription_discount`, `subscription_offers` and `calls_under`. 0.23.0: the section's
  optional billing companies (`CatalogueBillingCompany`) and billing rules
  (`CatalogueBillingRule`), the gateway codes (`BILLING_GATEWAYS`, `known_gateways`) and
  the helper `billing_offers`. 0.27.0: a subscription's optional included cases per
  product category (`MAX_INCLUDED_CASES`) and the helper `included_cases`. 0.29.0: a
  billing company's optional bank details (holder, IBAN, BIC, bank name) and SEPA creditor
  id, a billing rule's optional country limit per gateway (`gateway_countries`,
  `CatalogueBillingRule.gateways_in`) and the helpers `normalise_iban`, `valid_iban`,
  `valid_bic`, `valid_creditor_id`.
- `country_map` (0.15.0): the snapshot's optional country map section
  (`CountryMapSection`: `CountryMapEntry`).
- `provider_costs` (0.19.0): the snapshot's optional provider costs section
  (`ProviderCostsSection`: `ProviderCostProduct`, `ProviderCost`), without provider
  details.
- `vouchers` (0.24.0): the snapshot's optional top-level vouchers list (`Voucher`), the
  types (`VOUCHER_TYPES`), the code helpers (`new_voucher_code`, `normalize_voucher_code`,
  `display_voucher_code`, `VOUCHER_CODE_ALPHABET`) and the per-region filter of a
  snapshot body (`vouchers_for_region`).
- `regions` (0.25.0): the per-region filter of a whole snapshot body
  (`snapshot_for_region`: the region's vouchers, country groups, products, billing
  companies and what hangs from its groups; `catalogue_for_region` for the catalogue
  section alone). 0.25.0 also gives the catalogue's country groups, products and billing
  companies an optional `region`, and makes the rules across groups per region.
- `remote` (0.13.0): the answer to a remote read (`RemoteRecord`, `remote_record`) and
  each resource's data reader (`RESOURCE_READERS`: `SampleRecordData`); the remote read
  refusal codes are in `errors` (`forbidden`, `not_found`, `access_log_unavailable`).
  0.16.0: remote writes: the request (`RemoteWriteRequest`, `remote_write_request`), each
  resource's closed changes model (`RESOURCE_WRITERS`: `SampleRecordChanges`;
  `changes_for`), the record's `version` in `RemoteRecord` and the 409 body
  (`StaleVersion`, `stale_version_body`); the write codes are in `errors`
  (`remote_write_error`: `invalid_body`, `stale_version`, `idempotency_key_reused`).
- `hub` (0.17.0): hub lookups, a portal reading admin-owned live data (interface I10):
  each lookup's closed answer (`LOOKUP_READERS`: the staging-only `SampleAvailability`,
  `sample_availability`) and `MAX_LOOKUP_BYTES`; the lookup refusal and outcome codes
  are in `errors` (`hub_lookup_error`: `invalid_request`, `region_mismatch`,
  `not_found`).
- `versions`: `API_VERSION`, `served_versions()`, `api_url_patterns()`.
- `checks`: `check_central_payload()`, `ContractViolation`.

The shapes exchanged are readers' models (`ContractModel`: unknown fields dropped);
event payloads are writers' models (`WriterModel`, 0.8.0: unknown fields refused).
Writers produce JSON with ``model_dump(mode='json')``. Each model's JSON Schema is
committed in ``mytp_core/schemas/`` (`SCHEMA_MODELS`), shipped in the wheel and rewritten
by ``manage.py export_contract_schemas``.
"""
import json
from pathlib import Path

from .amounts import Amount
from .base import ContractModel, WriterModel
from .catalogue import (BILLING_GATEWAYS, MAX_INCLUDED_CASES, AddOnRefused, CallExtras,
                        CatalogueAddOn, CatalogueBillingCompany, CatalogueBillingRule,
                        CatalogueCountryGroup, CatalogueProduct, CatalogueSection,
                        CatalogueSubscription, CostLink, MonthlyCost, PerUnit, ProductCalls,
                        ProductCost, ProductText, QuantityRefused, SubscriptionPrice,
                        add_on_applies, billing_offers, calls_under, check_quantity,
                        included_cases, known_gateways, line_price, link_labels,
                        normalise_iban, subscription_discount, subscription_offers, sum_costs, valid_bic, valid_creditor_id,
                        valid_iban)
from .checks import ContractViolation, check_central_payload, find_violations
from .clients import (CLIENT_ERASED, CLIENT_READERS, CLIENT_UPDATED, ClientErased,
                      ClientErasedReader, ClientUpdated, ClientUpdatedReader,
                      FiscalEntityItem, FiscalEntityItemReader, MAX_ACTIVE_SENT,
                      MAX_ARCHIVED_SENT, ShippingAddressItem, ShippingAddressItemReader)
from .contact_messages import (CONTACT_MESSAGE_DELETED, CONTACT_MESSAGE_READERS,
                               CONTACT_MESSAGE_UPDATED, ContactMessageDeleted,
                               ContactMessageDeletedReader, ContactMessageUpdated,
                               ContactMessageUpdatedReader)
from .config import (SNAPSHOT_READER, AdminDirectoryEntry, ConfigResponse, ConfigSnapshot,
                     canonical_json, snapshot_sha)
from .country_map import CountryMapEntry, CountryMapSection
from .errors import ErrorBody, ErrorDetail, error_body
from .events import (DELIVERED_RESULTS, EVENT_RESULTS, MAX_EVENT_BYTES, EventEnvelope,
                     EventResult, event_result, utc_text)
from .hub import (LOOKUP_READERS, MAX_LOOKUP_BYTES, SampleAvailability, SampleSlot,
                  sample_availability)
from .payloads import (InvalidPayload, UnknownEventType, build_payload, payload_model_for,
                       register_payload, registered_types)
from .provider_costs import ProviderCost, ProviderCostProduct, ProviderCostsSection
from .regions import catalogue_for_region
from .regions import for_region as snapshot_for_region
from .remote import (RESOURCE_READERS, RESOURCE_WRITERS, RemoteRecord, RemoteWriteRequest,
                     SampleRecordChanges, SampleRecordData, StaleVersion, changes_for,
                     remote_record, remote_write_request, stale_version_body)
from .versions import API_VERSION, api_url_patterns, served_versions
from .accounting import (ACCOUNTING_READERS, CREDIT_NOTE_REASONS, INVOICE_ISSUED,
                         INVOICE_KINDS, PAYMENT_CONFIRMED, REFUND_COMPLETED, InvoiceBuyer,
                         InvoiceBuyerReader, InvoiceIssued, InvoiceIssuedReader,
                         InvoiceLine, InvoiceLineReader, InvoiceSeller,
                         InvoiceSellerReader, InvoiceVatGroup, InvoiceVatGroupReader,
                         PaymentConfirmed, PaymentConfirmedReader, RefundCompleted,
                         RefundCompletedReader)
from .voucher_usage import (VOUCHER_REDEEMED, VOUCHER_RELEASED, VOUCHER_USAGE_READERS,
                            VoucherRedeemed, VoucherRedeemedReader, VoucherReleased,
                            VoucherReleasedReader)
from .vouchers import CODE_ALPHABET as VOUCHER_CODE_ALPHABET
from .vouchers import VOUCHER_TYPES, Voucher
from .vouchers import display_code as display_voucher_code
from .vouchers import for_region as vouchers_for_region
from .vouchers import new_code as new_voucher_code
from .vouchers import normalize_code as normalize_voucher_code

SCHEMA_DIR = Path(__file__).resolve().parent.parent / 'schemas'

# One JSON Schema file per model, by file name.
SCHEMA_MODELS = {
    'amount.json': Amount,
    'config_response.json': ConfigResponse,
    'config_snapshot.json': ConfigSnapshot,
    'error_body.json': ErrorBody,
    'event_envelope.json': EventEnvelope,
    'event_result.json': EventResult,
    'payload_client_erased.json': ClientErased,
    'payload_client_updated.json': ClientUpdated,
    'payload_contact_message_deleted.json': ContactMessageDeleted,
    'payload_contact_message_updated.json': ContactMessageUpdated,
    'payload_voucher_redeemed.json': VoucherRedeemed,
    'payload_voucher_released.json': VoucherReleased,
    'payload_invoice_issued.json': InvoiceIssued,
    'payload_payment_confirmed.json': PaymentConfirmed,
    'payload_refund_completed.json': RefundCompleted,
    'hub_sample_availability.json': SampleAvailability,
    'remote_record.json': RemoteRecord,
    'remote_sample_record.json': SampleRecordData,
    'remote_sample_record_changes.json': SampleRecordChanges,
    'remote_stale_version.json': StaleVersion,
    'remote_write_request.json': RemoteWriteRequest,
}


def schema_text(model):
    """The committed text of a model's JSON Schema (stable: sorted keys, 2-space indent)."""
    return json.dumps(model.model_json_schema(), indent=2, sort_keys=True) + '\n'


__all__ = [
    'API_VERSION', 'AddOnRefused', 'AdminDirectoryEntry', 'Amount', 'CLIENT_ERASED',
    'CallExtras', 'SubscriptionPrice', 'calls_under', 'subscription_discount',
    'subscription_offers', 'MAX_INCLUDED_CASES', 'included_cases',
    'BILLING_GATEWAYS', 'CatalogueBillingCompany', 'CatalogueBillingRule', 'billing_offers',
    'known_gateways', 'normalise_iban', 'valid_iban', 'valid_bic', 'valid_creditor_id',
    'CLIENT_READERS', 'CatalogueAddOn',
    'CatalogueCountryGroup', 'CatalogueProduct', 'CatalogueSection', 'CatalogueSubscription',
    'CLIENT_UPDATED', 'ClientErased', 'ClientErasedReader', 'ClientUpdated',
    'ClientUpdatedReader', 'FiscalEntityItem', 'FiscalEntityItemReader',
    'MAX_ACTIVE_SENT', 'MAX_ARCHIVED_SENT', 'ShippingAddressItem',
    'ShippingAddressItemReader', 'CONTACT_MESSAGE_DELETED', 'CONTACT_MESSAGE_READERS',
    'CONTACT_MESSAGE_UPDATED', 'ContactMessageDeleted', 'ContactMessageDeletedReader',
    'ContactMessageUpdated', 'ContactMessageUpdatedReader', 'ConfigResponse',
    'ACCOUNTING_READERS', 'CREDIT_NOTE_REASONS', 'INVOICE_ISSUED', 'INVOICE_KINDS',
    'PAYMENT_CONFIRMED', 'REFUND_COMPLETED', 'InvoiceBuyer', 'InvoiceBuyerReader',
    'InvoiceIssued', 'InvoiceIssuedReader', 'InvoiceLine', 'InvoiceLineReader',
    'InvoiceSeller', 'InvoiceSellerReader', 'InvoiceVatGroup', 'InvoiceVatGroupReader',
    'PaymentConfirmed', 'PaymentConfirmedReader', 'RefundCompleted', 'RefundCompletedReader',
    'VOUCHER_REDEEMED', 'VOUCHER_RELEASED', 'VOUCHER_USAGE_READERS', 'VoucherRedeemed',
    'VoucherRedeemedReader', 'VoucherReleased', 'VoucherReleasedReader',
    'ConfigSnapshot', 'CostLink', 'CountryMapEntry', 'CountryMapSection',
    'PerUnit', 'ProductCalls', 'ProductCost', 'ProductText', 'ProviderCost', 'ProviderCostProduct', 'ProviderCostsSection',
    'ContractModel', 'ContractViolation', 'DELIVERED_RESULTS',
    'EVENT_RESULTS', 'ErrorBody', 'ErrorDetail', 'EventEnvelope', 'EventResult',
    'InvalidPayload', 'LOOKUP_READERS', 'MAX_EVENT_BYTES', 'MAX_LOOKUP_BYTES',
    'MonthlyCost', 'QuantityRefused', 'RESOURCE_READERS', 'RESOURCE_WRITERS',
    'RemoteRecord', 'RemoteWriteRequest', 'SCHEMA_DIR', 'SCHEMA_MODELS', 'SNAPSHOT_READER',
    'SampleAvailability', 'SampleRecordChanges', 'SampleRecordData', 'SampleSlot',
    'StaleVersion',
    'UnknownEventType', 'WriterModel', 'add_on_applies', 'api_url_patterns',
    'build_payload', 'canonical_json', 'changes_for', 'check_central_payload',
    'check_quantity', 'error_body',
    'event_result',
    'find_violations', 'line_price', 'link_labels', 'payload_model_for', 'register_payload', 'registered_types',
    'remote_record', 'remote_write_request', 'sample_availability', 'schema_text', 'served_versions',
    'snapshot_sha', 'stale_version_body', 'sum_costs', 'utc_text',
    'VOUCHER_CODE_ALPHABET', 'VOUCHER_TYPES', 'Voucher', 'display_voucher_code',
    'new_voucher_code', 'normalize_voucher_code', 'vouchers_for_region',
    'catalogue_for_region', 'snapshot_for_region',
]

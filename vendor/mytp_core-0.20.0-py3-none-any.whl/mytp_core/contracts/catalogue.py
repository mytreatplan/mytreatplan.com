"""The catalogue section of the configuration snapshot (0.12.0, architecture AD-3, AD-6,
AD-16, AD-22; epic-catalogue entry 2): the products, country groups and subscriptions the
admin site's Commercial Manager defines, which every regional portal prices from.

    {"country_groups": [{"id": "<uuid>", "name": "Iberia", "countries": ["ES", "PT"],
                         "catch_all": false, "active": true}],
     "products": [{"id": "<uuid>", "name": "TPS", "category": "tps",
                   "net_price": {"amount": "100.00", "currency": "EUR"}, "active": true}],
     "subscriptions": [{"id": "<uuid>", "tier": "basic", "country_group": "<uuid>",
                        "tps_discount_percent": "10.00", "active": true}]}

- Every row is listed, inactive ones too (``active: false``); ids are UUID strings, each
  once per list.
- A country group lists ISO 3166-1 alpha-2 codes (uppercase), each once; ``catch_all``
  marks the group of every country in no other active group ("Rest of world"). Among the
  active groups a country is in at most one, and at most one is the catch-all.
- A product's ``category`` and a subscription's ``tier`` are lowercase codes (``tps`` /
  ``other`` until 0.20.0, whose codes are listed below; ``basic`` / ``advanced`` /
  ``premium``), not a closed list: a later release adds codes, and a reader skips what it
  does not know.
- ``net_price`` is a net amount (the `Amount` contract; VAT is added at checkout), never
  negative. The admin site writes only the currencies of `mytp_core.money.CURRENCIES`
  (EUR, AED, USD); the contract takes any ISO 4217 form, and a reader skips a product in a
  currency it does not know (a later release may add one). ``tps_discount_percent`` is a
  decimal string with exactly 2 places from ``"0.00"`` to ``"100.00"``.
- A subscription's ``country_group`` is the id of a listed group; at most one active
  subscription per (tier, country group).

Since 0.20.0 (epic-catalogue entry 5) a product may also carry, each optional:

    {"texts": {"en": {"name": "TPS", "description": "A plan.\\nIn two lines."},
               "es": {"name": "TPS", "description": ""}},
     "code": "TPS-BR-01", "valid_from": "2026-01-01", "valid_to": "2026-12-31"}

- ``texts``: the public texts per language (a lowercase language tag: two or three
  letters, then optional ``-`` subtags of letters or digits, as ``es``, ``pt-br``; a
  reader falls back to English for a language it does not show): a ``name`` (at
  most 150 characters) and a short ``description`` (at most 1000; plain text, line breaks
  as ``\\n``; may be empty). English (``en``) is always there with a name that is not
  blank and equals the product's ``name``; any other
  language, or an empty text of one, falls back to English (`CatalogueProduct.name_in`,
  `description_in`). ``name`` stays the English public name, for readers before 0.20.0.
- ``code``: the internal code, unique among the products that have one (a section where
  two products share a code is refused): 1 to 64 uppercase letters,
  digits and ``. _ / -``. Readers identify a product by its id, never by its code.
- ``valid_from`` / ``valid_to``: ISO dates (``YYYY-MM-DD``), each optional, both
  inclusive, in Madrid time; ``valid_to`` never before ``valid_from``. Outside them the
  product is not offered for new orders (`CatalogueProduct.offered_on`) but stays listed.
- The internal notes of a product never leave the admin site: they are not in the contract.
- The category codes of 0.20.0's admin site are ``tps_branded``, ``tps_in_house``,
  ``initial_case_evaluation``, ``virtuaortho_one``, ``virtuaortho_digitaltwin``, ``odb``,
  ``retainers``, ``spark_on_demand``, ``subscription``, ``education`` and
  ``uncategorised`` (a product not yet given one of them); ``tps`` and ``other`` are the
  codes of an admin site before it, which a reader takes as ``tps_branded`` and
  ``uncategorised``. The list stays open, as above.

and a subscription ``tps_in_house_discount_percent`` (optional; a percentage as
``tps_discount_percent``): the discount on ``tps_in_house`` products, while
``tps_discount_percent`` is the discount on ``tps_branded`` ones. Absent (an admin site
before 0.20.0) it reads as 0 (`CatalogueSubscription.in_house_discount_percent`). No
other category is discounted.

A field of these that is absent (or null) stays absent when the row is dumped, so a row
without them dumps, and a snapshot of an older admin site signs, exactly as in 0.19.0.

The rules across rows (a subscription's group is listed; at most one active subscription
per tier and group; a country in at most one active group; at most one active catch-all)
are part of the reader contract: a snapshot that breaks one is refused whole
(`invalid_body`), and the reader keeps its last good snapshot, which is the safe failure.
Relaxing any of them is a breaking change: it needs a `min_reader` bump, so readers that
still enforce it keep their snapshot instead of refusing every new one.

The section is optional in the snapshot (`ConfigSnapshot.catalogue`): an admin site older
than 0.12.0 sends none, and a portal then holds an empty catalogue.
"""
from decimal import Decimal
from typing import Annotated

from pydantic import (BeforeValidator, Field, PlainSerializer, StrictBool,
                      StringConstraints, WithJsonSchema, model_serializer, model_validator)

from .amounts import Amount, _decimal_amount
from .base import ContractModel
from .events import CanonicalUuid
from .provider_costs import IsoDate

Name = Annotated[str, StringConstraints(min_length=1, max_length=150)]
# A choice code: lowercase letters, digits and "_", starting with a letter.
Code = Annotated[str, StringConstraints(min_length=1, max_length=32,
                                        pattern=r'^[a-z][a-z0-9_]*$')]
CountryCode = Annotated[str, StringConstraints(pattern=r'^[A-Z]{2}$')]

PERCENT_PATTERN = r'^(100\.00|[1-9]?[0-9]\.[0-9]{2})$'
HUNDRED = Decimal('100')


def _decimal_percent(value):
    try:
        value = _decimal_amount(value)
    except ValueError:
        raise ValueError('a percentage is a decimal string with exactly 2 places, '
                         'e.g. "10.00"') from None
    if not Decimal(0) <= value <= HUNDRED:
        raise ValueError('a percentage is from "0.00" to "100.00"')
    return value


Percent = Annotated[
    Decimal,
    BeforeValidator(_decimal_percent),
    PlainSerializer(lambda value: format(value, 'f'), return_type=str, when_used='json'),
    WithJsonSchema({'type': 'string', 'pattern': PERCENT_PATTERN,
                    'description': 'A percentage with exactly 2 places, "0.00" to "100.00".'}),
]


class CatalogueCountryGroup(ContractModel):
    """A group of countries a subscription applies to."""

    id: CanonicalUuid
    name: Name
    countries: list[CountryCode]
    catch_all: StrictBool = Field(
        description='The group of every country in no other active group.')
    active: StrictBool

    @model_validator(mode='after')
    def _unique_countries(self):
        if len(self.countries) != len(set(self.countries)):
            raise ValueError('a country group lists a country twice')
        return self


def _without_absent(data, names):
    """A dumped row without its optional fields that are None: an absent field stays
    absent (never ``"code": null``), so a row without them dumps as before they existed."""
    if isinstance(data, dict):
        for name in names:
            if name in data and data[name] is None:
                del data[name]
    return data


# 0.20.0: a product's public texts, per language.
ENGLISH = 'en'
# A lowercase language tag: two or three letters, then optional "-" subtags of letters or
# digits ("es", "pt-br", "zh-hans"). Wide on purpose: a reader falls back to English for
# a language it does not show, and a reader rule cannot be relaxed later.
LanguageCode = Annotated[str, StringConstraints(
    max_length=35, pattern=r'^[a-z]{2,3}(-[a-z0-9]{1,8})*$')]
PRODUCT_CODE_PATTERN = r'^[A-Z0-9._/-]{1,64}$'
ProductCode = Annotated[str, StringConstraints(pattern=PRODUCT_CODE_PATTERN)]


class ProductText(ContractModel):
    """A product's public texts in one language (0.20.0): plain text, the description
    with line breaks. An empty one falls back to English."""

    name: str = Field(default='', max_length=150)
    description: str = Field(default='', max_length=1000)


# A product's optional fields (0.20.0): left out of a dump when None.
PRODUCT_OPTIONAL = ('texts', 'code', 'valid_from', 'valid_to')


class CatalogueProduct(ContractModel):
    """A product, at its net price; since 0.20.0 with its optional public texts per
    language, internal code and validity dates."""

    id: CanonicalUuid
    name: Name
    category: Code
    net_price: Amount
    active: StrictBool
    texts: dict[LanguageCode, ProductText] | None = None
    code: ProductCode | None = None
    valid_from: IsoDate | None = None
    valid_to: IsoDate | None = None

    @model_serializer(mode='wrap')
    def _without_absent_fields(self, handler):
        return _without_absent(handler(self), PRODUCT_OPTIONAL)

    @model_validator(mode='after')
    def _consistent(self):
        if self.net_price.amount < 0:
            raise ValueError('a net price is never negative')
        if self.texts is not None:
            if not (ENGLISH in self.texts and self.texts[ENGLISH].name.strip()):
                raise ValueError("a product's texts have an English name")
            if self.texts[ENGLISH].name != self.name:
                raise ValueError("a product's name is the English name of its texts")
        if (self.valid_from is not None and self.valid_to is not None
                and self.valid_to < self.valid_from):
            raise ValueError("a product's validity ends before it starts")
        return self

    def _text(self, language, field):
        texts = self.texts or {}
        for code in (language, ENGLISH):
            value = getattr(texts.get(code), field, '')
            if value:
                return value
        return ''

    def name_in(self, language):
        """The public name in `language` ("es"), else in English, else ``name`` (a row
        without texts)."""
        return self._text(language, 'name') or self.name

    def description_in(self, language):
        """The short description in `language`, else in English, else ''."""
        return self._text(language, 'description')

    def offered_on(self, day):
        """Whether `day` (a date, in Madrid time) is within the validity dates, both
        inclusive; an absent date does not limit. It says nothing of ``active``."""
        return ((self.valid_from is None or self.valid_from <= day)
                and (self.valid_to is None or day <= self.valid_to))


class CatalogueSubscription(ContractModel):
    """A subscription tier in one country group, with its discounts: on TPS branded
    products (``tps_discount_percent``) and, since 0.20.0, on TPS in-house ones."""

    id: CanonicalUuid
    tier: Code
    country_group: CanonicalUuid
    tps_discount_percent: Percent
    # 0.20.0: optional, so the snapshot of an older admin site stays valid.
    tps_in_house_discount_percent: Percent | None = None
    active: StrictBool

    @model_serializer(mode='wrap')
    def _without_absent_fields(self, handler):
        return _without_absent(handler(self), ('tps_in_house_discount_percent',))

    @property
    def in_house_discount_percent(self):
        """The discount on TPS in-house products: 0 when the snapshot has none."""
        if self.tps_in_house_discount_percent is None:
            return Decimal('0.00')
        return self.tps_in_house_discount_percent


def _unique(rows, label):
    ids = [row.id for row in rows]
    if len(ids) != len(set(ids)):
        raise ValueError(f'{label} lists an id twice')


class CatalogueSection(ContractModel):
    """The snapshot's ``catalogue``: see the module docstring."""

    country_groups: list[CatalogueCountryGroup]
    products: list[CatalogueProduct]
    subscriptions: list[CatalogueSubscription]

    @model_validator(mode='after')
    def _consistent(self):
        _unique(self.country_groups, 'country_groups')
        _unique(self.products, 'products')
        _unique(self.subscriptions, 'subscriptions')
        # 0.20.0: a code is unique among the products that have one.
        codes = [product.code for product in self.products if product.code is not None]
        if len(codes) != len(set(codes)):
            raise ValueError('two products have the same code')
        active_groups = [group for group in self.country_groups if group.active]
        seen = set()
        for group in active_groups:
            if seen & set(group.countries):
                raise ValueError('a country is in two active country groups')
            seen |= set(group.countries)
        if sum(1 for group in active_groups if group.catch_all) > 1:
            raise ValueError('two active country groups are the catch-all')
        groups = {group.id for group in self.country_groups}
        pairs = set()
        for subscription in self.subscriptions:
            if subscription.country_group not in groups:
                raise ValueError('a subscription names a country group not listed')
            if subscription.active:
                pair = (subscription.tier, subscription.country_group)
                if pair in pairs:
                    raise ValueError('two active subscriptions of one tier and country group')
                pairs.add(pair)
        return self

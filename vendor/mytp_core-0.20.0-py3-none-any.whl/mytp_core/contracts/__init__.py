"""The interface contracts between the sites (0.7.0, architecture AD-12, AD-23,
interface I3): pydantic 2 models of the shapes the admin site and the portals exchange,
the version policy and the checks that keep patient data, files and floats out of central
payloads.

- `errors`: ``{"error": {"code", "message"}}`` (`ErrorBody`, `error_body`) and the named
  codes (the 401 refusals, ``unavailable``).
- `amounts`: ``{"amount": "123.45", "currency": "EUR"}`` (`Amount`).
- `events`: the event envelope (`EventEnvelope`), the answer to an event POST
  (`EventResult`, `event_result`; 0.8.0), `MAX_EVENT_BYTES` and `utc_text` (0.8.0).
- `payloads` (0.8.0): the closed payload model of every event type
  (`register_payload`, `payload_model_for`, `build_payload`).
- `clients` (0.11.0): the client record events ``client.updated`` (`ClientUpdated`,
  read with `ClientUpdatedReader`) and ``client.erased`` (`ClientErased`,
  `ClientErasedReader`); the staging-only ``sample.recorded`` is gone.
- `contact_messages` (0.14.0): the contact message events ``contact_message.updated``
  (`ContactMessageUpdated`, read with `ContactMessageUpdatedReader`) and
  ``contact_message.deleted`` (`ContactMessageDeleted`, `ContactMessageDeletedReader`).
- `config` (0.10.0): the configuration snapshot (`ConfigSnapshot`, `AdminDirectoryEntry`),
  the answer to ``GET /api/v1/config`` (`ConfigResponse`), `SNAPSHOT_READER` and
  `snapshot_sha` (signed and verified by `mytp_core.snapshots`).
- `catalogue` (0.12.0): the snapshot's optional catalogue section (`CatalogueSection`:
  `CatalogueCountryGroup`, `CatalogueProduct`, `CatalogueSubscription`). 0.20.0: a
  product's optional texts per language (`ProductText`), code and validity dates, and a
  subscription's optional in-house TPS discount.
- `country_map` (0.15.0): the snapshot's optional country map section
  (`CountryMapSection`: `CountryMapEntry`).
- `provider_costs` (0.19.0): the snapshot's optional provider costs section
  (`ProviderCostsSection`: `ProviderCostProduct`, `ProviderCost`), without provider
  details.
- `remote` (0.13.0): the answer to a remote read (`RemoteRecord`, `remote_record`) and
  each resource's data reader (`RESOURCE_READERS`: `SampleRecordData`); the remote read
  refusal codes are in `errors` (`forbidden`, `not_found`, `access_log_unavailable`).
  0.16.0: remote writes: the request (`RemoteWriteRequest`, `remote_write_request`), each
  resource's closed changes model (`RESOURCE_WRITERS`: `SampleRecordChanges`;
  `changes_for`), the record's `version` in `RemoteRecord` and the 409 body
  (`StaleVersion`, `stale_version_body`); the write codes are in `errors`
  (`remote_write_error`: `invalid_body`, `stale_version`, `idempotency_key_reused`).
- `hub` (0.17.0): hub lookups, a portal reading admin-owned live data (interface I10):
  each lookup's closed answer (`LOOKUP_READERS`: the staging-only `SampleAvailability`,
  `sample_availability`) and `MAX_LOOKUP_BYTES`; the lookup refusal and outcome codes
  are in `errors` (`hub_lookup_error`: `invalid_request`, `region_mismatch`,
  `not_found`).
- `versions`: `API_VERSION`, `served_versions()`, `api_url_patterns()`.
- `checks`: `check_central_payload()`, `ContractViolation`.

The shapes exchanged are readers' models (`ContractModel`: unknown fields dropped);
event payloads are writers' models (`WriterModel`, 0.8.0: unknown fields refused).
Writers produce JSON with ``model_dump(mode='json')``. Each model's JSON Schema is
committed in ``mytp_core/schemas/`` (`SCHEMA_MODELS`), shipped in the wheel and rewritten
by ``manage.py export_contract_schemas``.
"""
import json
from pathlib import Path

from .amounts import Amount
from .base import ContractModel, WriterModel
from .catalogue import (CatalogueCountryGroup, CatalogueProduct, CatalogueSection,
                        CatalogueSubscription, ProductText)
from .checks import ContractViolation, check_central_payload, find_violations
from .clients import (CLIENT_ERASED, CLIENT_READERS, CLIENT_UPDATED, ClientErased,
                      ClientErasedReader, ClientUpdated, ClientUpdatedReader)
from .contact_messages import (CONTACT_MESSAGE_DELETED, CONTACT_MESSAGE_READERS,
                               CONTACT_MESSAGE_UPDATED, ContactMessageDeleted,
                               ContactMessageDeletedReader, ContactMessageUpdated,
                               ContactMessageUpdatedReader)
from .config import (SNAPSHOT_READER, AdminDirectoryEntry, ConfigResponse, ConfigSnapshot,
                     canonical_json, snapshot_sha)
from .country_map import CountryMapEntry, CountryMapSection
from .errors import ErrorBody, ErrorDetail, error_body
from .events import (DELIVERED_RESULTS, EVENT_RESULTS, MAX_EVENT_BYTES, EventEnvelope,
                     EventResult, event_result, utc_text)
from .hub import (LOOKUP_READERS, MAX_LOOKUP_BYTES, SampleAvailability, SampleSlot,
                  sample_availability)
from .payloads import (InvalidPayload, UnknownEventType, build_payload, payload_model_for,
                       register_payload, registered_types)
from .provider_costs import ProviderCost, ProviderCostProduct, ProviderCostsSection
from .remote import (RESOURCE_READERS, RESOURCE_WRITERS, RemoteRecord, RemoteWriteRequest,
                     SampleRecordChanges, SampleRecordData, StaleVersion, changes_for,
                     remote_record, remote_write_request, stale_version_body)
from .versions import API_VERSION, api_url_patterns, served_versions

SCHEMA_DIR = Path(__file__).resolve().parent.parent / 'schemas'

# One JSON Schema file per model, by file name.
SCHEMA_MODELS = {
    'amount.json': Amount,
    'config_response.json': ConfigResponse,
    'config_snapshot.json': ConfigSnapshot,
    'error_body.json': ErrorBody,
    'event_envelope.json': EventEnvelope,
    'event_result.json': EventResult,
    'payload_client_erased.json': ClientErased,
    'payload_client_updated.json': ClientUpdated,
    'payload_contact_message_deleted.json': ContactMessageDeleted,
    'payload_contact_message_updated.json': ContactMessageUpdated,
    'hub_sample_availability.json': SampleAvailability,
    'remote_record.json': RemoteRecord,
    'remote_sample_record.json': SampleRecordData,
    'remote_sample_record_changes.json': SampleRecordChanges,
    'remote_stale_version.json': StaleVersion,
    'remote_write_request.json': RemoteWriteRequest,
}


def schema_text(model):
    """The committed text of a model's JSON Schema (stable: sorted keys, 2-space indent)."""
    return json.dumps(model.model_json_schema(), indent=2, sort_keys=True) + '\n'


__all__ = [
    'API_VERSION', 'AdminDirectoryEntry', 'Amount', 'CLIENT_ERASED', 'CLIENT_READERS',
    'CatalogueCountryGroup', 'CatalogueProduct', 'CatalogueSection', 'CatalogueSubscription',
    'CLIENT_UPDATED', 'ClientErased', 'ClientErasedReader', 'ClientUpdated',
    'ClientUpdatedReader', 'CONTACT_MESSAGE_DELETED', 'CONTACT_MESSAGE_READERS',
    'CONTACT_MESSAGE_UPDATED', 'ContactMessageDeleted', 'ContactMessageDeletedReader',
    'ContactMessageUpdated', 'ContactMessageUpdatedReader', 'ConfigResponse',
    'ConfigSnapshot', 'CountryMapEntry', 'CountryMapSection',
    'ProductText', 'ProviderCost', 'ProviderCostProduct', 'ProviderCostsSection',
    'ContractModel', 'ContractViolation', 'DELIVERED_RESULTS',
    'EVENT_RESULTS', 'ErrorBody', 'ErrorDetail', 'EventEnvelope', 'EventResult',
    'InvalidPayload', 'LOOKUP_READERS', 'MAX_EVENT_BYTES', 'MAX_LOOKUP_BYTES',
    'RESOURCE_READERS', 'RESOURCE_WRITERS',
    'RemoteRecord', 'RemoteWriteRequest', 'SCHEMA_DIR', 'SCHEMA_MODELS', 'SNAPSHOT_READER',
    'SampleAvailability', 'SampleRecordChanges', 'SampleRecordData', 'SampleSlot',
    'StaleVersion',
    'UnknownEventType', 'WriterModel', 'api_url_patterns',
    'build_payload', 'canonical_json', 'changes_for', 'check_central_payload', 'error_body',
    'event_result',
    'find_violations', 'payload_model_for', 'register_payload', 'registered_types',
    'remote_record', 'remote_write_request', 'sample_availability', 'schema_text', 'served_versions',
    'snapshot_sha', 'stale_version_body', 'utc_text',
]

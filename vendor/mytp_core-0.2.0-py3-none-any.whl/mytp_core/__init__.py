"""Code shared by the MyTreatPlan sites (portal, admin site): field encryption, the blind
index, the OVHcloud KMS client, and the operations code (Sentry with its scrubber,
scheduled jobs with Sentry cron monitors, the /healthz view, database backups), with
their management commands (architecture AD-10).

Add ``'mytp_core'`` to INSTALLED_APPS: that registers the field key system checks
(mytp_core.E001, mytp_core.E002) and the commands ``generate_field_keys``,
``generate_kms_field_key``, ``kmscheck``, ``runjob`` and ``backupdb``.
"""
__version__ = '0.2.0'

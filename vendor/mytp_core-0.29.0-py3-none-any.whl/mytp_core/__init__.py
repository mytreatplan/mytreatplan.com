"""Code shared by the MyTreatPlan sites (portal, admin site): field encryption, the blind
index, the OVHcloud KMS client, the operations code (Sentry with its scrubber,
scheduled jobs with Sentry cron monitors, the /healthz view, database backups), the
background task helpers (enqueue after commit, idempotent effects, the worker
heartbeat) and the verification codes (the provider interface, the fake and
Twilio Verify providers, `send_code` with a site's hooks; 0.4.0) and the sign-in rules
(remembered devices, the failure lockout, one session per account, each with a site's
policy; 0.5.0) and the signed calls between the sites (Ed25519 request tokens, the peers'
keyring, the replay cache and a signed GET; 0.6.0; a signed POST, 0.8.0) and the interface
contracts (pydantic models of the error body, the amount and the event envelope, the
version policy, the central payload checks and their JSON Schema files; 0.7.0; the event
payload registry and the event POST answer, 0.8.0) and the money type (`Money`, an
exact Decimal amount of EUR, AED or USD; 0.9.0) and the signed configuration snapshot
(`contracts.config`, `snapshots`; 0.10.0) and the client record events
(`contracts.clients`; 0.11.0) and the snapshot's catalogue section
(`contracts.catalogue`; 0.12.0) and remote reads (the token's extra claims,
`access`, `contracts.remote`; 0.13.0) and the contact message events
(`contracts.contact_messages`; 0.14.0) and the snapshot's country map section
(`contracts.country_map`; 0.15.0) and remote writes (writable fields in `access`,
the write request, versions and codes in `contracts.remote`; 0.16.0) and hub lookups
(the closed answer of the staging-only sample lookup in `contracts.hub`, the lookup
codes in `contracts.errors`; 0.17.0) and the weekly restore test (the restore-only
`age` identity wrapped by the KMS, `restore_identity`, per-site jobs.conf lines; 0.18.0)
and the snapshot's provider costs section (`contracts.provider_costs`; 0.19.0) and the
catalogue section's product texts per language, code and validity dates and the in-house
TPS discount of a subscription (`contracts.catalogue`; 0.20.0) and the catalogue
section's add-ons, a product's size, per-unit quantities, calls and cost links, with the
line price and the cost at a date (`contracts.catalogue`; 0.21.0) and a subscription's
code, texts, linked products, discounts per product category, own price and call extras,
with the manual subscriptions (`contracts.catalogue`; 0.22.0) and the catalogue section's
billing companies and billing rules (`contracts.catalogue`; 0.23.0) and the snapshot's voucher
definitions with their code helpers and per-region filter (`contracts.vouchers`; 0.24.0)
and the region of the catalogue's country groups, products and billing companies, with
the filter of a whole snapshot body per region (`contracts.catalogue`,
`contracts.regions`; 0.25.0)
and the client record's optional personal-data fields (`contracts.clients`; 0.26.0)
and a subscription's included cases per product category (`contracts.catalogue`;
0.27.0)
and the client record's fiscal entities and shipping addresses (`contracts.clients`;
0.28.0)
and a billing company's bank details and SEPA creditor id and a billing rule's country
limit per gateway (`contracts.catalogue`; 0.29.0),
with their
management commands
(architecture AD-4, AD-8, AD-10, AD-12).

Add ``'mytp_core'`` to INSTALLED_APPS: that registers the field key system checks
(mytp_core.E001, mytp_core.E002), the table of done task effects (0.3.0, `migrate`) and
the commands ``generate_field_keys``, ``generate_kms_field_key``, ``kmscheck``,
``runjob``, ``backupdb``, ``enqueue_worker_heartbeat``, ``requeue_interrupted_tasks`` and
``generate_interface_signing_key`` and ``export_contract_schemas`` and
``generate_restore_identity`` and ``restoretest`` (0.18.0).
"""
__version__ = '0.29.0'

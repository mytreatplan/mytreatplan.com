"""The interface contracts between the sites (0.7.0, architecture AD-12, AD-23,
interface I3): pydantic 2 models of the shapes the admin site and the portals exchange,
the version policy and the checks that keep patient data, files and floats out of central
payloads.

- `errors`: ``{"error": {"code", "message"}}`` (`ErrorBody`, `error_body`) and the named
  codes (the 401 refusals, ``unavailable``).
- `amounts`: ``{"amount": "123.45", "currency": "EUR"}`` (`Amount`).
- `events`: the event envelope (`EventEnvelope`), the answer to an event POST
  (`EventResult`, `event_result`; 0.8.0), `MAX_EVENT_BYTES` and `utc_text` (0.8.0).
- `payloads` (0.8.0): the closed payload model of every event type
  (`register_payload`, `payload_model_for`, `build_payload`), with ``sample.recorded``.
- `config` (0.10.0): the configuration snapshot (`ConfigSnapshot`, `AdminDirectoryEntry`),
  the answer to ``GET /api/v1/config`` (`ConfigResponse`), `SNAPSHOT_READER` and
  `snapshot_sha` (signed and verified by `mytp_core.snapshots`).
- `versions`: `API_VERSION`, `served_versions()`, `api_url_patterns()`.
- `checks`: `check_central_payload()`, `ContractViolation`.

The shapes exchanged are readers' models (`ContractModel`: unknown fields dropped);
event payloads are writers' models (`WriterModel`, 0.8.0: unknown fields refused).
Writers produce JSON with ``model_dump(mode='json')``. Each model's JSON Schema is
committed in ``mytp_core/schemas/`` (`SCHEMA_MODELS`), shipped in the wheel and rewritten
by ``manage.py export_contract_schemas``.
"""
import json
from pathlib import Path

from .amounts import Amount
from .base import ContractModel, WriterModel
from .checks import ContractViolation, check_central_payload, find_violations
from .config import (SNAPSHOT_READER, AdminDirectoryEntry, ConfigResponse, ConfigSnapshot,
                     canonical_json, snapshot_sha)
from .errors import ErrorBody, ErrorDetail, error_body
from .events import (DELIVERED_RESULTS, EVENT_RESULTS, MAX_EVENT_BYTES, EventEnvelope,
                     EventResult, event_result, utc_text)
from .payloads import (SAMPLE_RECORDED, InvalidPayload, SampleRecorded, UnknownEventType,
                       build_payload, payload_model_for, register_payload,
                       registered_types)
from .versions import API_VERSION, api_url_patterns, served_versions

SCHEMA_DIR = Path(__file__).resolve().parent.parent / 'schemas'

# One JSON Schema file per model, by file name.
SCHEMA_MODELS = {
    'amount.json': Amount,
    'config_response.json': ConfigResponse,
    'config_snapshot.json': ConfigSnapshot,
    'error_body.json': ErrorBody,
    'event_envelope.json': EventEnvelope,
    'event_result.json': EventResult,
    'payload_sample_recorded.json': SampleRecorded,
}


def schema_text(model):
    """The committed text of a model's JSON Schema (stable: sorted keys, 2-space indent)."""
    return json.dumps(model.model_json_schema(), indent=2, sort_keys=True) + '\n'


__all__ = [
    'API_VERSION', 'AdminDirectoryEntry', 'Amount', 'ConfigResponse', 'ConfigSnapshot',
    'ContractModel', 'ContractViolation', 'DELIVERED_RESULTS',
    'EVENT_RESULTS', 'ErrorBody', 'ErrorDetail', 'EventEnvelope', 'EventResult',
    'InvalidPayload', 'MAX_EVENT_BYTES', 'SAMPLE_RECORDED', 'SCHEMA_DIR', 'SCHEMA_MODELS',
    'SNAPSHOT_READER',
    'SampleRecorded', 'UnknownEventType', 'WriterModel', 'api_url_patterns',
    'build_payload', 'canonical_json', 'check_central_payload', 'error_body', 'event_result',
    'find_violations', 'payload_model_for', 'register_payload', 'registered_types',
    'schema_text', 'served_versions', 'snapshot_sha', 'utc_text',
]

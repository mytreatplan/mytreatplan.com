"""mytp-core's only table (0.3.0): the effects background tasks have done (AD-8).

The package shares code, never data (AD-10): each site has its own table, in its own
database, created by `manage.py migrate`.
"""
from django.db import models


class TaskEffect(models.Model):
    """One effect done once: `effect` for the record `record` (a UUID) in `period` ('' for
    an effect done once per record). Written by mytp_core.tasks.run_once in the same
    transaction as the effect's database writes."""

    effect = models.CharField(max_length=100)
    record = models.UUIDField()
    period = models.CharField(max_length=32, blank=True, default='')
    done_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['effect', 'record', 'period'],
                                    name='mytp_core_taskeffect_once'),
        ]

    def __str__(self):
        period = f' ({self.period})' if self.period else ''
        return f'{self.effect} {self.record}{period}'

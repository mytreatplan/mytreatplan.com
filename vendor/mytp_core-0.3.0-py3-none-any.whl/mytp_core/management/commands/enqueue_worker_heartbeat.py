"""Enqueue the worker heartbeat (mytp_core.tasks.worker_heartbeat).

    python manage.py enqueue_worker_heartbeat

Run by the site's scheduled job (a jobs.conf line with this command, e.g. every 5
minutes). The worker runs the task, which checks in on the Sentry cron monitor
`mytp-<SITE>-worker` with the schedule of that jobs.conf line, so the monitor expects a
check-in as often as the job enqueues one.
"""
from django.core.management.base import BaseCommand

from mytp_core.jobs import load_jobs
from mytp_core.tasks import HEARTBEAT_SCHEDULE, worker_heartbeat

COMMAND = 'enqueue_worker_heartbeat'


def heartbeat_schedule():
    """The crontab of the jobs.conf line running this command (else the default)."""
    try:
        jobs = load_jobs()
    except (OSError, ValueError):
        return HEARTBEAT_SCHEDULE
    for job in jobs.values():
        if job.command == COMMAND:
            return job.crontab
    return HEARTBEAT_SCHEDULE


class Command(BaseCommand):
    help = 'Enqueue the worker heartbeat task (Sentry monitor mytp-<SITE>-worker).'

    def handle(self, **options):
        result = worker_heartbeat.enqueue(schedule=heartbeat_schedule())
        self.stdout.write(f'worker heartbeat enqueued: {result.id}')

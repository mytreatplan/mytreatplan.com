"""Put tasks a stopped worker left running back in the queue (django-tasks-db).

    python manage.py requeue_interrupted_tasks [--backend default]

django-tasks-db marks a task RUNNING when a worker claims it. A worker killed mid-task
(SIGKILL, out of memory, host restart) leaves it RUNNING for ever: the backend never
runs it again. Each site runs exactly one worker (systemd `mytp-<site>-worker`), and
this command runs as that unit's ExecStartPre, before the new worker starts: no worker
of the site is running then, so every RUNNING task of the backend was interrupted. They
go back to READY and run again; their effects are idempotent (mytp_core.tasks.run_once),
so none happens twice.

Never run it while a worker of the site is running: it would requeue that worker's
current task. It needs django-tasks-db (`mytp-core[tasks]`); task code never imports it.
"""
from django.core.management.base import BaseCommand, CommandError
from django.tasks import DEFAULT_TASK_BACKEND_ALIAS, TaskResultStatus, task_backends
from django.tasks.exceptions import InvalidTaskBackend


class Command(BaseCommand):
    help = 'Requeue the tasks a stopped worker left RUNNING (run before the worker starts).'

    def add_arguments(self, parser):
        parser.add_argument('--backend', default=DEFAULT_TASK_BACKEND_ALIAS,
                            help='the TASKS backend alias (default: %(default)s)')

    def handle(self, *, backend, **options):
        try:
            from django_tasks_db.backend import DatabaseBackend
            from django_tasks_db.models import DBTaskResult
        except ImportError as exc:
            raise CommandError('django-tasks-db is not installed') from exc
        try:
            configured = task_backends[backend]
        except InvalidTaskBackend as exc:
            raise CommandError(str(exc)) from exc
        if not isinstance(configured, DatabaseBackend):
            raise CommandError(f"backend {backend!r} is not django-tasks-db's DatabaseBackend")

        count = DBTaskResult.objects.filter(
            backend_name=backend, status=TaskResultStatus.RUNNING,
        ).update(status=TaskResultStatus.READY, started_at=None)
        self.stdout.write(f'requeued {count} interrupted task(s)')

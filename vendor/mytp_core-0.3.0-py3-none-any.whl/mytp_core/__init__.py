"""Code shared by the MyTreatPlan sites (portal, admin site): field encryption, the blind
index, the OVHcloud KMS client, the operations code (Sentry with its scrubber,
scheduled jobs with Sentry cron monitors, the /healthz view, database backups) and the
background task helpers (enqueue after commit, idempotent effects, the worker
heartbeat), with their management commands (architecture AD-8, AD-10).

Add ``'mytp_core'`` to INSTALLED_APPS: that registers the field key system checks
(mytp_core.E001, mytp_core.E002), the table of done task effects (0.3.0, `migrate`) and
the commands ``generate_field_keys``, ``generate_kms_field_key``, ``kmscheck``,
``runjob``, ``backupdb``, ``enqueue_worker_heartbeat`` and ``requeue_interrupted_tasks``.
"""
__version__ = '0.3.0'

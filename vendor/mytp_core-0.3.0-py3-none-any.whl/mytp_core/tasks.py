"""Background tasks (0.3.0, architecture AD-8): the helpers every site's tasks use, and
the worker heartbeat.

Tasks are written against Django's `django.tasks` API and run by one worker per site
(the site's TASKS backend; the portal uses django-tasks-db's `db_worker`). Task code
imports `django.tasks` and these helpers only, never the backend.

The conventions:

- **Enqueue after commit.** A view or service that writes a record and wants a task for
  it calls `enqueue_on_commit(task, record_uuid, ...)` inside its transaction: the task is
  enqueued only once the transaction commits, and never if it rolls back.
- **Idempotent effects.** A task may run more than once (a worker killed mid-task and
  restarted runs it again). Each effect is wrapped in `run_once(effect, record_uuid, fn)`
  (and `period=` for periodic effects such as renewals, e.g. `'2026-11'`): it records
  the effect in `TaskEffect` in the same transaction as `fn()`'s database writes, so the
  effect happens once per (effect, record, period). An effect outside the database (an
  email, a webhook) is at least once: if the worker dies after the call but before the
  commit, the rerun calls it again, so such calls also send the record's UUID as the
  provider's idempotency key where the provider has one.
- **Retries that matter live on business rows** (outbox, webhooks, messages), never in
  backend options.

The heartbeat: the scheduled job `enqueue_worker_heartbeat` (every few minutes, the
site's jobs.conf) enqueues `worker_heartbeat`, which checks in on the Sentry cron monitor
`mytp-<SITE>-worker`. When the worker is down, check-ins stop and Sentry alerts.
"""
import logging
import uuid
from datetime import timedelta
from functools import partial

import sentry_sdk
from django.db import IntegrityError, transaction
from django.tasks import task
from django.utils import timezone
from sentry_sdk.crons import capture_checkin
from sentry_sdk.crons.consts import MonitorStatus

from .jobs import monitor_slug

logger = logging.getLogger(__name__)

# The worker heartbeat: the monitor name (`mytp-<SITE>-worker`), the default schedule
# (the jobs.conf line's crontab is passed in when there is one), the minutes Sentry waits
# past a due check-in, and the age past which a queued heartbeat is skipped (a worker
# back after an outage runs the backlog at once; only a fresh one says it is alive).
WORKER_MONITOR = 'worker'
HEARTBEAT_SCHEDULE = '*/5 * * * *'
HEARTBEAT_CHECKIN_MARGIN_MINUTES = 3
HEARTBEAT_MAX_AGE = timedelta(minutes=5)


def enqueue_on_commit(task, *args, on_commit_using=None, **kwargs):
    """Enqueue `task(*args, **kwargs)` when the current transaction commits (at once
    outside a transaction); nothing is enqueued if it rolls back. `on_commit_using`
    (keyword only) is the database alias of the transaction (default: the default
    database); every other keyword, `using` included, goes to the task. Arguments must be
    JSON values: pass the record's UUID as a string, never the record."""
    transaction.on_commit(partial(task.enqueue, *args, **kwargs), using=on_commit_using)


def _key(effect, record, period):
    if not effect or len(effect) > 100:
        raise ValueError('effect must be a name of 1-100 characters')
    period = '' if period is None else str(period)
    if len(period) > 32:
        raise ValueError('period must be at most 32 characters')
    return effect, uuid.UUID(str(record)), period


def run_once(effect, record, fn, *, period=''):
    """Run `fn()` unless `effect` was already done for `record` (a UUID) in `period`.

    Returns True when `fn` ran now, False when it had been done before. The mark and
    `fn()`'s database writes commit together: if `fn` raises, neither stays, and a later
    run tries again. Two runs at the same time: the second waits for the first and then
    skips (PostgreSQL's unique index)."""
    from .models import TaskEffect

    effect, record, period = _key(effect, record, period)
    with transaction.atomic():
        try:
            with transaction.atomic():
                TaskEffect.objects.create(effect=effect, record=record, period=period)
        except IntegrityError:
            logger.info('effect %s for %s%s already done; skipped', effect, record,
                        f' ({period})' if period else '')
            return False
        fn()
    return True


def effect_done(effect, record, *, period=''):
    """Whether `effect` was done for `record` in `period`."""
    from .models import TaskEffect

    effect, record, period = _key(effect, record, period)
    return TaskEffect.objects.filter(effect=effect, record=record, period=period).exists()


def worker_monitor_slug(site=None):
    """The Sentry cron monitor of the site's worker: `mytp-<SITE>-worker`."""
    return monitor_slug(WORKER_MONITOR, site)


def heartbeat_monitor_config(schedule=HEARTBEAT_SCHEDULE):
    return {
        'schedule': {'type': 'crontab', 'value': schedule},
        'timezone': 'UTC',
        'checkin_margin': HEARTBEAT_CHECKIN_MARGIN_MINUTES,
        'max_runtime': 1,
        'failure_issue_threshold': 1,
        'recovery_threshold': 1,
    }


@task(takes_context=True)
def worker_heartbeat(context, schedule=HEARTBEAT_SCHEDULE):
    """Check in on `mytp-<SITE>-worker` (ok): the worker is running tasks. Skipped when
    the heartbeat waited in the queue longer than HEARTBEAT_MAX_AGE, or Sentry is off."""
    enqueued_at = context.task_result.enqueued_at
    if enqueued_at and timezone.now() - enqueued_at > HEARTBEAT_MAX_AGE:
        logger.info('worker heartbeat skipped: queued since %s', enqueued_at.isoformat())
        return 'stale'
    if not sentry_sdk.get_client().is_active():
        return 'sentry off'
    capture_checkin(monitor_slug=worker_monitor_slug(), status=MonitorStatus.OK,
                    monitor_config=heartbeat_monitor_config(schedule))
    sentry_sdk.flush(timeout=10)
    return 'ok'

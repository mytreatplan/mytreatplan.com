from django.apps import AppConfig
from django.core import checks


class MytpCoreConfig(AppConfig):
    name = 'mytp_core'
    verbose_name = 'MyTreatPlan core'
    # Fixed, so the migrations do not depend on the site's DEFAULT_AUTO_FIELD.
    default_auto_field = 'django.db.models.BigAutoField'

    def ready(self):
        from .crypto import check_field_keys

        # Missing or malformed field keys stop `check`, `runserver` and `migrate`
        # (mytp_core.E001, mytp_core.E002).
        checks.register(check_field_keys, checks.Tags.security)
